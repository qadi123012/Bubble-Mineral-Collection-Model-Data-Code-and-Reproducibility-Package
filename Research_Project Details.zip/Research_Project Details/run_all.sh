#!/usr/bin/env bash
# One-command reproduction of every number, table and (data-driven) figure in this package.
# Usage:  bash run_all.sh            (add  --with-regeneration  to also re-run the image pipeline from the raw frames, ~30 s)
set -euo pipefail
cd "$(dirname "$0")"
echo "[1/8] unit tests of the collection model";            python3 COMPUTATIONAL_MODELS/single_bubble_collection_model/tests/test_collection_model.py
echo "[2/8] statistics from the CSV datasets";               python3 SOURCE_CODE/calculations/compute_manuscript_statistics.py
echo "[3/8] manuscript claim verification";                  python3 SOURCE_CODE/validation/verify_manuscript_claims.py
echo "[4/8] frame-rate / scale sensitivity";                 python3 SOURCE_CODE/calculations/sensitivity_fps_scale.py > /dev/null
echo "[5/8] Savitzky-Golay parameter recovery";              python3 SOURCE_CODE/validation/recover_savgol_parameters.py
echo "[6/8] figures";                                        python3 SOURCE_CODE/plotting/make_supplementary_figures.py; python3 SOURCE_CODE/plotting/make_mass_and_gallery_figures.py
echo "[7/8] authors' legacy scripts and figures";            bash SOURCE_CODE/legacy_adapted/run_all_legacy_adapted.sh
echo "[8/8] workbooks and audit tables";                     python3 SOURCE_CODE/calculations/build_data_dictionary.py; python3 SOURCE_CODE/calculations/build_supplementary_workbook.py; python3 SOURCE_CODE/validation/build_audit_tables.py
if [[ "${1:-}" == "--with-regeneration" ]]; then echo "[extra] regenerate CSVs from raw frames"; python3 SOURCE_CODE/data_processing/regenerate_csvs_from_frames.py; fi
echo "DONE. Expected: 7 tests passed; 109 claims: 100 PASS, 1 PASS*, 8 FAIL (documented in AUDIT/CORRECTION_LOG.md)"
