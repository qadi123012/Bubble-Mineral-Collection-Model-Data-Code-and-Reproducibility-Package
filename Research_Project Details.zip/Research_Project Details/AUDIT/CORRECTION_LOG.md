# Correction and consistency log

Nothing in the manuscript file was changed. Each entry records the original statement, the problem, the proposed correction and the evidence. CL-01 and CL-02 cannot be resolved from the supplied files and need the authors' primary records.

## CL-01  [CRITICAL (unresolved)]  Abstract, S3.1, S3.3, S4.3, S4.7-4.9, Table 2, Fig. 3

- **Original:** 'Recorded at 2000 fps (0.5 ms interval)', described as the documented acquisition rate; every velocity, Re, We, Ec, Np and the 51-fold ratio use it.
- **Problem:** Author sources conflict: the imaging-procedure slides state 'We only assumed 500 fps' and the author scripts use 500 fps (Re = 11.3); the manuscript says 2000 fps from the schematic annotation. No primary record (video metadata, camera log) was supplied.
- **Correction / status:** NOT changed (authors must settle). Sensitivity table provided (ST3): at 500 fps Re = 12.1, Ec = 1.5e-3, Np = 0.61, features/Np = 96.5, V_b = 8.7 mm/s (about 17x below the rigid-sphere velocity); at 2000 fps Re = 48.6, features/Np = 51.
- **Evidence:** DATA/DERIVED_DATA/sensitivity_fps_scale.csv; slides 'Imgaging_Procedure...' slides 3 and 11; mineral_calculations.json (assumed_fps 500)
- **Affected:** Abstract, S3.3, S4.3, S4.7, S4.8, S4.9, Fig. 3, Fig. 8, Table 2, Conclusions

## CL-02  [CRITICAL (unresolved)]  S3.3, Table 2, Limitation (iii)

- **Original:** Analysis scale 0.0112 mm/px, 'two documented readings agree within +/-4%'.
- **Problem:** The burned-in '3 mm' bar in frame 73 is cut by the right image edge (187 px visible, label cut: Fig. S3). 3 mm / 187 px = 16.04 um/px if the visible part were the whole bar. The authors' own slide 11 flags this ('about 16.0 um/px and a 1.9 mm bubble, not 1.3 mm'). 11.2 um/px would need a 268 px bar, which is only possible if the bar is clipped.
- **Correction / status:** NOT changed. Must be measured on an uncropped frame/calibration image. Consequences if 16.04 is right: d_b = 1.87 mm, mass x2.94, Re x2 (at same fps).
- **Evidence:** FIGURES/PUBLICATION_READY/Fig_S3_scale_bar_evidence; ST3
- **Affected:** All mm, m/s, ug results; Re, Eo, We, Ec, Np, Cd, mass

## CL-03  [HIGH]  S3.2/S4.7 (raw pipeline SD)

- **Original:** Raw per-frame pipeline diameter '116.46 +/- 2.42 pixel'.
- **Problem:** SD of the raw diameters in bubble_kinematics_and_particles.csv is 2.004 (SD n) or 2.015 (SD n-1), range 111.48-121.62.
- **Correction / status:** Corrected to 116.46 +/- 2.00 pixel.
- **Evidence:** d_raw_sd_px = 2.0042
- **Affected:** S4.2, S4.7, Fig. 7 caption

## CL-04  [HIGH]  S4.7

- **Original:** Bubble Analyser diameter '114.95 +/- 2.1 pixel'; 'slope = 0.975 x 2.1/2.42 = 0.85'.
- **Problem:** SD of ba_eq_diam_px is 1.750. The slope statement should read 0.975 x 1.750/2.004 = 0.851, which is the reported slope; the arithmetic with the printed SDs gives 0.846.
- **Correction / status:** Corrected to 114.95 +/- 1.75 pixel; slope sentence updated.
- **Evidence:** ba_sd_px = 1.7500; slope check = 0.8511
- **Affected:** S4.7

## CL-05  [MEDIUM]  S4.2

- **Original:** Aspect ratio '1.091 +/- 0.056'.
- **Problem:** SD is 0.0592 (n) / 0.0596 (n-1); 0.056 is not obtainable from the data.
- **Correction / status:** Corrected to 1.091 +/- 0.059.
- **Evidence:** aspect_sd = 0.0592
- **Affected:** S4.2, Fig. 3 caption

## CL-06  [HIGH]  S4.2, S4.8

- **Original:** '3 peaks and 5 troughs; successive extremes 4-25 frames apart (mean 11.5)'; period 11.5 frames = 5.8 ms = 174 Hz; compared with Lamb f2.
- **Problem:** No peak-detection setting tried here (SG 5-21, raw, distance 1-8, prominence 0-0.01) reproduces 3/5 with 4-25 frame spacing. The authors' own script gives 5 peaks/7 troughs on the raw series; SG-smoothed gives 4/5 with spacing 1-18 (mean 8.6). A Hann-windowed periodogram of the detrended series gives a dominant period of 48 frames, but only two cycles fit in 96 frames.
- **Correction / status:** NOT reproducible as printed. Recommended: report the periodogram result with its limitation, or remove the quantitative oscillation-frequency comparison.
- **Evidence:** aspect_fft_dominant_period_frames = 48; legacy 5/7; SG 4/5
- **Affected:** S4.2, S4.8 (f2 comparison), Fig. 3d

## CL-07  [MEDIUM]  S4.9

- **Original:** 'The top 25% of features by mass carry about 75% of the total detected mass.'
- **Problem:** Recomputed share is 90.9% (top 1,418 of 5,673 features).
- **Correction / status:** Corrected to about 91%.
- **Evidence:** feat_mass_top25pct_share_pct = 90.9
- **Affected:** S4.9

## CL-08  [LOW]  S4.9, Fig. 8b

- **Original:** 'U(f) = 171 ug' (unique-detection estimate at frame 120).
- **Problem:** With q = 1 - 0.8524 (data) the estimate is 174.1 ug (174.5 with q rounded to 0.148).
- **Correction / status:** Corrected to about 174 ug.
- **Evidence:** unique_mass_U_ug_q_from_data = 174.1
- **Affected:** S4.9, Fig. 8b legend

## CL-09  [LOW]  S4.10, Fig. 10

- **Original:** 'Across frames 36-60 ... detection count fluctuates between 56 and 79, coverage 7.05-9.45%, mass 7.60-17.42 ug.'
- **Problem:** These ranges hold for the six annotated frames only. Over all frames 36-60 the count is 53-93 and coverage 6.24-10.31%.
- **Correction / status:** Reword: 'at the six annotated frames'.
- **Evidence:** six_stage_* vs f36_60_* statistics
- **Affected:** S4.10

## CL-10  [LOW]  S4.3, S4.9

- **Original:** '146.92 pixel = 1.646 mm' and 'mean rise per frame 17.39 um'.
- **Problem:** 146.917 px x 11.2 um = 1.6455 mm (rounds to 1.645). 17.39 um is mean SG velocity x scale; net rise / 95 intervals = 17.32 um.
- **Correction / status:** State the basis; use 1.645 mm. (Mass flux 652.8 ug/mm uses 17.39 um; 655.5 ug/mm with 17.32 um.)
- **Evidence:** net_rise_mm = 1.64547
- **Affected:** S4.3, S4.9

## CL-11  [MEDIUM]  S3.4, Limitation (vi)

- **Original:** 'The detection threshold is not recorded.'
- **Problem:** analysis_pipeline.py records the high-pass threshold: 18 gray levels (8-bit), Gaussian sigma 9 px, erosion 15 px, area 2-200 px^2.
- **Correction / status:** Insert the values (ST7). The threshold-sensitivity sweep requested in Limitation (vi) is still outstanding.
- **Evidence:** SOURCE_CODE/data_processing/analysis_pipeline.py, detect_particles
- **Affected:** S3.4, limitation (vi)

## CL-12  [MEDIUM]  S3.4 (methods)

- **Original:** Segmentation description.
- **Problem:** Also used: 5x5 Gaussian blur, 3x3 opening, convex hull of the main component, ROI = max(90 px, 2.2 R), masking of the bottom 45 px / left 230 px / right 270 px overlay.
- **Correction / status:** Add to the methods or SI.
- **Evidence:** ST7_Pipeline
- **Affected:** S3.4

## CL-13  [MEDIUM]  S3.4, Data availability

- **Original:** 'Exact software versions ... could not be re-established.'
- **Problem:** The supplied code was executed here (Python 3.12.3, OpenCV 4.13.0, OpenPIV 0.26.1, NumPy 2.4.4, pandas 3.0.2, SciPy 1.17.1, Bubble Analyser commit 63b22f3) and reproduced the four CSV files to <= 6e-14. Original versions remain unknown.
- **Correction / status:** State tested versions as 'verified environment' (ENVIRONMENT/software_versions.txt).
- **Evidence:** AUDIT/TEST_LOG.md
- **Affected:** S3.4

## CL-14  [MEDIUM]  S3.5, Data availability

- **Original:** 'RGB of IMG_9433 was not present; IMG_9431's mask was absent and regenerated from its RGB.'
- **Problem:** Supplied files: IMG_9433 RGB IS present; IMG_9431 is absent entirely (RGB and mask); IMG_9434 is present but is not cited. The statement does not match the supplied package.
- **Correction / status:** Reconcile the file list before deposit.
- **Evidence:** DATA/RAW_DATA/system_C_high_resolution_micrographs
- **Affected:** S3.5, Table 1

## CL-15  [HIGH (supplied files)]  legacy JSON files

- **Original:** mineral_calculations.json, deep_single_bubble_stats.json, multi_bubble_stats.json.
- **Problem:** These were produced at 500 fps (Re 11.3, Ec 1.50e-3, Np 0.596, ratio 99) and are inconsistent with the manuscript (2000 fps); 'mineral_mass_flux.per_mm_ug' = 652,842 is a unit error (652.8 ug/mm); E_a is attributed to Batjargal et al. [13] while the manuscript presents it as a system A measurement; multi_bubble_stats.json uses an unverified 3 um/px although the manuscript claims no physical scale for the micrographs.
- **Correction / status:** Kept only in DATA/DERIVED_DATA/legacy_supplied_stale/ with a warning. Do not deposit as results.
- **Evidence:** DATA/DERIVED_DATA/legacy_supplied_stale
- **Affected:** Data availability

## CL-16  [LOW]  recomputed_stats.json

- **Original:** 'bubble_straightness' = 0.8645; 'rise_velocity_raw_*' = NaN.
- **Problem:** 0.8645 is the verticality ratio (net rise/path); straightness (net displacement/path) is 0.994. Raw velocity is NaN because of the first-row NaN (nanmean = 1.5476).
- **Correction / status:** Renamed in manuscript_statistics.json (verticality_ratio, straightness_index).
- **Evidence:** 
- **Affected:** none (manuscript already distinguishes them)

## CL-17  [LOW]  S4.5

- **Original:** PIV TKE proxy 0.0218.
- **Problem:** Reproduces as 0.5(<RMSu>^2 + <RMSv>^2) = 0.02176; the authors' script gives 0.02268 (mean of per-pair values).
- **Correction / status:** State the definition used.
- **Evidence:** piv_tke_from_mean_rms = 0.02176
- **Affected:** S4.5

## CL-18  [LOW]  all +/- values

- **Original:** Standard-deviation convention not stated.
- **Problem:** Population SD (n) is used (e.g. feature count 9.68; sample SD 9.73).
- **Correction / status:** State 'SD (n)' or switch to sample SD.
- **Evidence:** compute_manuscript_statistics.py
- **Affected:** all

## CL-19  [LOW]  S3.1

- **Original:** 'Compiled 1920 x 1080 recording'.
- **Problem:** Supplied frames are 864 x 496 px. The relation between the original recording and the exported frames (resampling would change the scale by 2.2x) is not documented.
- **Correction / status:** Document the export step and whether 11.2 um/px refers to the 864 x 496 frames.
- **Evidence:** frame image size
- **Affected:** S3.1, S3.3

## CL-20  [LOW]  Eq. (2)

- **Original:** Coefficients extracted from the .docx as '32 + 4Re^0.7215'.
- **Problem:** Likely a text-extraction artefact of a fraction typeset in OMML. Implemented as 3/2 + (4/15) Re^0.7215, which reproduces Ec = 2.9e-3. Please verify the equation renders correctly in Word.
- **Correction / status:** Verify in Word.
- **Evidence:** unit test test_collection_chain_matches_manuscript
- **Affected:** S2.2

