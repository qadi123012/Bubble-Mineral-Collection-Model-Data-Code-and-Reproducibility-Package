# Manuscript-to-data traceability

| Manuscript item | Supporting data | Code | Worksheet / table | Status |
|---|---|---|---|---|
| Figure 1 | Author schematic (not data) | Imgaging_Procedure / Bubble_Mineral_Collection_Model pptx | - | Illustration; annotations 11.2 um/px, 2000 fps cannot be verified (CL-01, CL-02) |
| Figure 2 | Pipeline schematic | SOURCE_CODE/data_processing/analysis_pipeline.py | ST7_Pipeline | Parameters verified against code |
| Figure 3a-d | per_frame_processed.csv | legacy_adapted/generate_figures.py (fig01); compute_manuscript_statistics.py | ST5_Per_frame | Regenerated: FIGURES/.../regenerated_from_authors_scripts/fig01 |
| Figure 3e | Literature reference points | - | - | Re-Eo reference plot; literature values not re-derived |
| Figure 4 | piv_summary.csv + frames | legacy_adapted/generate_figures.py (fig06) | - | Regenerated (fig06) |
| Figure 5 | individual_particles.csv, bubble_kinematics...csv | generate_figures.py (fig02, fig04) | ST5, ST6 | Regenerated (fig02, fig04) |
| Figure 6 | individual_particles.csv | generate_figures.py (fig03) | ST6 | Regenerated (fig03) |
| Figure 7 | bubble_analyser_crosscheck.csv | generate_figures.py (fig05); regenerate_csvs_from_frames.py --with-bubble-analyser | - | CSV regenerated from frames to 1e-14 |
| Figure 8 | per_frame_processed.csv, model inputs | make_mass_and_gallery_figures.py | ST2, ST5 | Functionally reproduced; original script not supplied |
| Figures 9-10 | frames + features | make_mass_and_gallery_figures.py | - | Functionally reproduced; original script not supplied |
| Figure 11 | per_frame_processed.csv | make_mass_and_gallery_figures.py | ST5 | Functionally reproduced |
| Table 1 | Provenance | - | - | Systems A and B: no data supplied |
| Table 2 | Parameters | parameters.json | ST1_Inputs | System C rows verified; A/B rows unverifiable |
| Table 3 | Literature comparison | - | - | d_b/d_p ratios arithmetic only; literature values not re-derived |
| Equation (1) | - | collection_model.total_efficiency | ST2 row 'Ecoll' | Unit-tested |
| Equation (2) | - | collection_model.collision_efficiency_yoon_luttrell | ST2 row 'Ec' | Unit-tested, Ec = 2.91e-3 |
| Equation (3) | - | collection_model.surface_area_weights | - | Unit-tested (weights sum to 1); no size-class data supplied |
| Equation (4) | - | collection_model.attachment_efficiency / implied_induction_time | ST8_Induction | Round-trip tested; BPATE raw data absent |
| Equations (5)-(7) | - | induction_time_surrogate (Eq. 7 only) | - | DLVO energy W_B not implemented: required inputs undocumented (Missing information M-04) |
| Equation (8) | - | capillary_adhesion_force, detachment_force, stability_efficiency | - | Implemented; Es = 0.85 is a scenario value |
| Equation (9) | - | collection_model.particles_per_bubble | ST2 rows Np_max, Np | Unit-tested, Np_max = 599.7, Np = 1.158 |
| Equations (10)-(12) | - | rate_constant_single_size, rate_constant_total, recovery | - | Unit-tested for self-consistency; no measured K or recovery to compare |
| S4.2 diameter/shape | bubble_kinematics_and_particles.csv | compute_manuscript_statistics.py | ST4 C01-C45 | 6 of 45 differ (CL-03, -04, -05, -06, -10) |
| S4.3 kinematics | same | same | ST4 C22-C34 | Reproduce (C27 rounding, CL-10) |
| S4.4 features | individual_particles.csv | same | ST4 C61-C77, C81-C82 | All reproduce |
| S4.5 PIV | piv_summary.csv | same | ST4 C54-C60 | Reproduce (TKE definition-dependent) |
| S4.6 leading/trailing | individual_particles.csv | same | ST4 C78-C80 | Reproduce (smoothed direction) |
| S4.7 Bubble Analyser | bubble_analyser_crosscheck.csv | same + regenerate script | ST4 C15-C21 | Reproduce except printed SDs (CL-04) |
| S4.7 dimensionless groups | - | collection_model + parameters.json | ST2, ST3 | Reproduce at 2000 fps and 11.2 um/px only |
| S4.8 drag / Lamb | - | collection_model | ST2 | Reproduce |
| S4.9 mass and Np | individual_particles.csv | same | ST4 C83-C101 | Reproduce except CL-07, CL-08 |
| S4.10 | frames, per-frame table | same | ST4 C102-C109 | Reproduce (CL-09 wording) |
