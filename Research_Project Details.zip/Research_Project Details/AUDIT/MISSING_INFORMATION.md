# Missing information (nothing below was invented or assumed in the package)

| ID | Missing item | Needed for | Consequence |
|---|---|---|---|
| M-01 | Primary record of the **frame rate** (video metadata, camera log, original file) | Every velocity, Re, We, Ec, Np, Cd, oscillation frequency | Cannot choose between 500 and 2000 fps; sensitivity table provided (CL-01) |
| M-02 | Primary record of the **spatial scale** (uncropped calibration frame with a measurable bar or ruling in the analysis field of view) | All lengths, masses, Eo, Re | 11.2 vs 16.04 um/px unresolved (CL-02) |
| M-03 | Original video (1920 x 1080 'compiled recording') and the export step to 864 x 496 frames | Frame rate, scale, frames 0-24 | Cannot verify the export |
| M-04 | Raw **zeta-potential**, **BPATE** (per-observation) data, and the exact W_B(zeta_p) form used in the alpha fit | Eqs. (4)-(7), Table 2, Figs. of Section 4.1 | Eq. (7) constants (t_i0 = 8.2 ms, alpha = 0.48, R2 = 0.94) and Ea = 0.22/0.78/0.95 cannot be re-derived |
| M-05 | Bubble-size distributions (BubbleSEdit), Denver-cell flotation kinetics (triplicates) of system B | Eq. (3), (10)-(12), Section 3.2 | Manuscript itself says results are not reported; no measured K or recovery |
| M-06 | Composition of the system C suspension (liquid, solids concentration, reagents) | Fluid properties, C_p, Section 4.9 | Pure-water properties and the system B slurry (10 kg/m3) are assumptions |
| M-07 | IMG_9431 RGB and mask; physical scale of the micrographs | Section 3.5 | Not analysable; manuscript claims no physical conversion |
| M-08 | Script for manuscript Figs. 8-11 (generate_figures_part4.py) | Figs. 8-11 | Functionally reproduced from data (not pixel-identical) |
| M-09 | Authors' original software versions | Exact environment | Tested versions reproduce the CSVs to 6e-14, so low risk |
| M-10 | Detection-threshold / mask-erosion sensitivity sweep | Limitation (vi) | Not performed by the authors; not performed here (would be a new analysis) |
| M-11 | Author list, affiliations, ORCID, funding, licence choice | CITATION.cff, LICENSE, README contact | Files not created (no information supplied) |
| M-12 | Free-rise (terminal velocity) measurement in the same cell; particle-free controls | Section 4.8 anomaly, imaging controls | Anomaly (V_b about 8x below clean-bubble expectation) cannot be explained |
