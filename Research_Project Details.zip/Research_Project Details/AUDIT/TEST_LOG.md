# Test log

Environment: Ubuntu 24.04.4, Python 3.12.3, packages as in ENVIRONMENT/requirements.txt, installed into a fresh virtual environment from a copy of this repository.

| # | Test | Result |
|---|---|---|
| 1 | `bash run_all.sh --with-regeneration` in the clean venv (58 s, exit 0) | PASSED |
| 2 | Collection model unit tests (7) | PASSED |
| 3 | Claim verification (109 claims) | 100 PASS, 1 PASS (definition-dependent), 8 FAIL; the failures are manuscript discrepancies (AUDIT/CORRECTION_LOG.md), not code errors |
| 4 | Authors' pipeline re-run from raw frames 25-120 vs supplied CSVs | kinematics, particles, PIV identical (max diff 5.7e-14) |
| 5 | Bubble Analyser cross-check regeneration (git clone, commit 63b22f3, run outside the venv during the audit) | identical (1.4e-14); NOT part of the clean-venv run because it needs internet and git |
| 6 | Authors' legacy scripts (recompute, deep single bubble, mineral calculations, multi-bubble, figures) | executed; JSON outputs equal the supplied ones (float noise); multi-bubble skips IMG_9431 (not supplied) |
| 7 | Savitzky-Golay parameter search | window 11, order 3, interp (error 4.7e-14) |
| 8 | Supplementary_Tables.xlsx recalculation (LibreOffice) | 11,830 formulas, 0 errors; spot-checked ST2, ST3, ST4 against the Python results |
| 9 | Word/PDF build of SI and audit report (pandoc + LibreOffice) | built; SI 7 pages, audit 3 pages; table layout checked visually on one page |

**Not performed:** `run_bubmask.py` (needs BubMask weights; its output is not used in the manuscript); Windows/macOS runs; a test with other package versions; opening the .docx/.xlsx files in Microsoft Office (LibreOffice only); visual comparison of every regenerated figure against the manuscript images (only Figs. S3 and 10 and the legacy Fig. 1 were inspected).
