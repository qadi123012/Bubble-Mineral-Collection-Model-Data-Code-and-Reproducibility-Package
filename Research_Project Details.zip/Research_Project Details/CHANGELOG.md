# Changelog
## 1.0.0 (audit package)
- Added: unmodified author code, raw frames, supplied CSV/JSON, consolidated statistics, claim verification (109 claims), executable collection model with unit tests, sensitivity and induction-time analyses, supplementary figures S1-S3, reproduced Figs. 8-11, Supplementary Tables workbook (live formulas), data dictionary, correction log (20 entries), missing-information list, audit report.
- Not changed: the manuscript text (corrections are proposed in AUDIT/CORRECTION_LOG.md).
