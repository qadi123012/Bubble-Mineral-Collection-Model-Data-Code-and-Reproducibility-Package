"""
Supplementary analysis code for: Single-Bubble PIV/PTV Analysis of Rise
Kinematics and Mineral-Particle Attachment.

Pipeline (run in order):
  1. track_bubble()       -- per-frame bubble segmentation + PTV centroid tracking
  2. compute_kinematics() -- trajectory, displacement, velocity, shape from (1)
  3. detect_particles()   -- attached mineral-particle speckle detection on the bubble surface
  4. run_piv()             -- OpenPIV cross-correlation of the seeded liquid-phase field

Inputs : a directory of consecutively numbered frames, frame_XXXXXXXX.jpg
Outputs: bubble_kinematics_and_particles.csv, piv_summary.csv

Dependencies: opencv-python, numpy, pandas, scipy, openpiv (pip install openpiv)
"""
import cv2
import numpy as np
import pandas as pd
import glob
import os
import sys
from scipy import stats as sstats
from openpiv import pyprocess

FRAMES_DIR = "./frames"          # <-- set to your frame directory
OUT_DIR = "./analysis_out"
TEXT_OVERLAY_BOX = (45, 0, 230)   # (row-band height from bottom, left width, right width) burned-in
SCALEBAR_BOX_W = 270
WIN, OVERLAP, SEARCH, S2N_THRESH = 32, 16, 32, 1.25


def mask_overlay(gray):
    """Blank out burned-in readout text / scale bar so they are never mistaken for
    bubble or tracer signal. Adjust the slice coordinates to match your own overlay."""
    h, w = gray.shape
    g = gray.copy()
    g[h - 45:h, 0:230] = 0
    g[h - 45:h, w - 270:w] = 0
    return g


def segment_in_roi(gray_full, roi_box):
    """Segment the bubble within roi_box=(x0,y0,x1,y1) of gray_full (full-frame coords).
    Returns dict with contour/area/centroid/ellipse in FULL-FRAME coordinates, or None."""
    x0, y0, x1, y1 = roi_box
    h, w = gray_full.shape
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(w, x1), min(h, y1)
    sub = mask_overlay(gray_full)[y0:y1, x0:x1]
    if sub.size == 0:
        return None

    blur = cv2.GaussianBlur(sub, (5, 5), 0)
    _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    closed = cv2.morphologyEx(th, cv2.MORPH_CLOSE, kernel, iterations=1)
    closed = cv2.morphologyEx(closed, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))

    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    c_raw = max(contours, key=cv2.contourArea)
    if cv2.contourArea(c_raw) < 200:
        return None

    # Sever any thin trailing ligament / satellite droplet so it cannot bias the
    # main bubble's diameter and aspect-ratio measurement.
    filled = np.zeros_like(closed)
    cv2.drawContours(filled, [c_raw], -1, 255, thickness=-1)
    sever_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))
    eroded = cv2.erode(filled, sever_k)
    n_comp, labels, stats, _ = cv2.connectedComponentsWithStats(eroded)
    clean = filled if n_comp <= 1 else cv2.dilate(
        (labels == 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))).astype(np.uint8) * 255, sever_k)

    contours2, _ = cv2.findContours(clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours2:
        return None
    c_clean = max(contours2, key=cv2.contourArea)
    c = cv2.convexHull(c_clean)
    if len(c) < 5:
        return None

    ellipse = cv2.fitEllipse(c)
    M = cv2.moments(c)
    if M['m00'] == 0:
        return None
    lcx, lcy = M['m10'] / M['m00'], M['m01'] / M['m00']
    c_full = c.copy(); c_full[:, 0, 0] += x0; c_full[:, 0, 1] += y0
    return {
        'contour': c_full,
        'area_px': cv2.contourArea(c),
        'centroid': (lcx + x0, lcy + y0),
        'ellipse': ((ellipse[0][0] + x0, ellipse[0][1] + y0), ellipse[1], ellipse[2]),
        'tail_severed_px': max(0.0, cv2.contourArea(c_raw) - cv2.contourArea(c_clean)),
    }


def track_bubble(frames_dir=FRAMES_DIR, out_dir=OUT_DIR):
    """Step 1: ROI-constrained bubble segmentation + centroid tracking across all frames."""
    os.makedirs(f"{out_dir}/contours", exist_ok=True)
    files = sorted(glob.glob(f"{frames_dir}/*.jpg"),
                    key=lambda p: int(os.path.basename(p).split('_')[1].split('.')[0]))
    frame_nums = [int(os.path.basename(p).split('_')[1].split('.')[0]) for p in files]

    img0 = cv2.imread(files[0]); gray0 = cv2.cvtColor(img0, cv2.COLOR_BGR2GRAY)
    h, w = gray0.shape
    res0 = segment_in_roi(gray0, (0, 0, w, h))
    assert res0 is not None, "Could not find bubble in first frame"

    results = []
    prev_centroid = res0['centroid']
    prev_radius = np.sqrt(res0['area_px'] / np.pi)

    for fpath, fnum in zip(files, frame_nums):
        img = cv2.imread(fpath); gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape
        margin = max(90, int(prev_radius * 2.2))
        cx0, cy0 = prev_centroid
        roi = (int(cx0 - margin), int(cy0 - margin), int(cx0 + margin), int(cy0 + margin))
        res = segment_in_roi(gray, roi) or segment_in_roi(gray, (0, 0, w, h))
        if res is None:
            results.append({'frame': fnum, 'found': False}); continue

        (ecx, ecy), (MA, ma), angle = res['ellipse']
        results.append({
            'frame': fnum, 'found': True, 'area_px': res['area_px'],
            'eq_diam_px': 2 * np.sqrt(res['area_px'] / np.pi),
            'ellipse_major_px': max(MA, ma), 'ellipse_minor_px': min(MA, ma),
            'ellipse_angle_deg': angle, 'centroid_x': res['centroid'][0],
            'centroid_y': res['centroid'][1], 'tail_severed_px': res['tail_severed_px'],
        })
        prev_centroid = res['centroid']; prev_radius = np.sqrt(res['area_px'] / np.pi)
        np.save(f"{out_dir}/contours/contour_{fnum:08d}.npy", res['contour'])

    return pd.DataFrame(results)


def compute_kinematics(df):
    """Step 2: trajectory, displacement, velocity, shape (all in px, per-frame units)."""
    df = df[df['found']].reset_index(drop=True).copy()
    df['t_frame'] = df['frame'] - df['frame'].min()
    dx, dy = df['centroid_x'].diff(), df['centroid_y'].diff()
    df['vx_px_per_frame'], df['vy_px_per_frame'] = dx, dy
    df['v_rise_px_per_frame'] = -dy
    df['speed_px_per_frame'] = np.sqrt(dx**2 + dy**2)
    df['path_length_px'] = df['speed_px_per_frame'].fillna(0).cumsum()
    df['net_rise_px'] = df['centroid_y'].iloc[0] - df['centroid_y']
    df['net_horiz_px'] = df['centroid_x'] - df['centroid_x'].iloc[0]
    df['aspect_ratio'] = df['ellipse_major_px'] / df['ellipse_minor_px']
    return df


def detect_particles(df, frames_dir=FRAMES_DIR, out_dir=OUT_DIR,
                      erode_px=15, blur_sigma=9, hp_thresh=18.0, blob_size=(2, 200)):
    """Step 3: attached mineral-particle speckle detection within the bubble mask."""
    records = []
    for _, row in df.iterrows():
        fnum = int(row['frame'])
        img = cv2.imread(f"{frames_dir}/frame_{fnum:08d}.jpg")
        gray = mask_overlay(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)).astype(np.float32)
        contour = np.load(f"{out_dir}/contours/contour_{fnum:08d}.npy")

        mask = np.zeros(gray.shape, np.uint8)
        cv2.drawContours(mask, [contour], -1, 255, thickness=-1)
        inner = cv2.erode(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (erode_px, erode_px)))
        highpass = gray - cv2.GaussianBlur(gray, (0, 0), sigmaX=blur_sigma)
        blobmask = ((highpass > hp_thresh) & (inner > 0)).astype(np.uint8) * 255

        n, labels, stats, _ = cv2.connectedComponentsWithStats(blobmask)
        areas = stats[1:, cv2.CC_STAT_AREA]
        valid = areas[(areas >= blob_size[0]) & (areas <= blob_size[1])]
        inner_area = int(np.sum(inner > 0))
        records.append({
            'frame': fnum, 'n_particles_visible': len(valid),
            'particle_area_px': int(valid.sum()), 'bubble_inner_area_px': inner_area,
            'particle_coverage_pct': 100 * valid.sum() / inner_area if inner_area else np.nan,
        })
    return df.merge(pd.DataFrame(records), on='frame')


def run_piv(frame_nums, frames_dir=FRAMES_DIR, out_dir=OUT_DIR):
    """Step 4: PIV cross-correlation of the seeded liquid phase, bubble region excluded."""
    def load(fnum):
        img = cv2.imread(f"{frames_dir}/frame_{fnum:08d}.jpg")
        return mask_overlay(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)).astype(np.int32)

    x, y = pyprocess.get_coordinates(image_size=(496, 864), search_area_size=SEARCH, overlap=OVERLAP)
    records = []
    for i in range(len(frame_nums) - 1):
        f_a, f_b = frame_nums[i], frame_nums[i + 1]
        u, v, s2n = pyprocess.extended_search_area_piv(
            load(f_a), load(f_b), window_size=WIN, overlap=OVERLAP, dt=1,
            search_area_size=SEARCH, sig2noise_method='peak2peak')

        mask = np.zeros((496, 864), np.uint8)
        for fn in (f_a, f_b):
            c = np.load(f"{out_dir}/contours/contour_{fn:08d}.npy")
            cv2.drawContours(mask, [c], -1, 255, thickness=-1)
        mask = cv2.dilate(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (41, 41)))
        near_bubble = mask[np.clip(y.astype(int), 0, 495), np.clip(x.astype(int), 0, 863)] > 0
        valid = (~near_bubble) & (s2n > S2N_THRESH) & (~np.isnan(u)) & (~np.isnan(v))

        rec = {'frame_a': f_a, 'frame_b': f_b, 'n_valid_vectors': int(valid.sum()), 'n_total_vectors': int(u.size)}
        if valid.sum() > 0:
            speed = np.sqrt(u**2 + v**2)
            rec.update(mean_u_px=float(np.mean(u[valid])), mean_v_px=float(np.mean(v[valid])),
                       std_u_px=float(np.std(u[valid])), std_v_px=float(np.std(v[valid])),
                       mean_speed_px=float(np.mean(speed[valid])), max_speed_px=float(np.max(speed[valid])))
        records.append(rec)
    return pd.DataFrame(records)


def compute_bubble_particle_ratio(df, frames_dir=FRAMES_DIR, out_dir=OUT_DIR,
                                   erode_px=15, blur_sigma=9, hp_thresh=18.0, blob_size=(2, 200)):
    """Step 5: individual particle diameters + positions, calibration-independent
    bubble-to-particle size ratio (mean and SMD basis), and leading/trailing-edge
    attachment classification (Step 6), directly comparable to the BPR theory and
    the wake-attachment finding reported in the reference literature."""
    records = []
    for _, row in df.iterrows():
        fnum = int(row['frame'])
        img = cv2.imread(f"{frames_dir}/frame_{fnum:08d}.jpg")
        gray = mask_overlay(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)).astype(np.float32)
        contour = np.load(f"{out_dir}/contours/contour_{fnum:08d}.npy")
        mask = np.zeros(gray.shape, np.uint8)
        cv2.drawContours(mask, [contour], -1, 255, thickness=-1)
        inner = cv2.erode(mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (erode_px, erode_px)))
        highpass = gray - cv2.GaussianBlur(gray, (0, 0), sigmaX=blur_sigma)
        blobmask = ((highpass > hp_thresh) & (inner > 0)).astype(np.uint8) * 255
        n, labels, stats, cents = cv2.connectedComponentsWithStats(blobmask)
        for i in range(1, n):
            area = stats[i, cv2.CC_STAT_AREA]
            if blob_size[0] <= area <= blob_size[1]:
                px, py = cents[i]
                records.append({'frame': fnum, 'particle_x': px, 'particle_y': py,
                                 'particle_area_px': area, 'particle_eq_diam_px': 2 * np.sqrt(area / np.pi)})
    pdf = pd.DataFrame(records)

    def smd(d):
        d = np.asarray(d)
        return np.sum(d**3) / np.sum(d**2) if len(d) else np.nan

    per_frame = pdf.groupby('frame')['particle_eq_diam_px'].agg(
        particle_mean_diam_px='mean', particle_smd_px=smd, particle_n='count').reset_index()
    merged = df.merge(per_frame, on='frame', how='left')
    merged['bubble_to_particle_ratio_mean'] = merged['eq_diam_px'] / merged['particle_mean_diam_px']
    merged['bubble_to_particle_ratio_smd'] = merged['eq_diam_px'] / merged['particle_smd_px']
    return pdf, merged


def classify_leading_trailing(pdf, df):
    """Step 6: classify each detected particle as leading-side (direction of travel)
    or trailing-side (wake), following Sommer et al.'s [6] wake-attachment comparison,
    adapted to a single 2D projection axis (this study's mean travel direction) rather
    than their full 3D radial/tangential decomposition."""
    mean_vx, mean_vy = df['vx_px_per_frame'].mean(), df['vy_px_per_frame'].mean()
    norm = np.hypot(mean_vx, mean_vy)
    dir_x, dir_y = mean_vx / norm, mean_vy / norm

    merged = pdf.merge(df[['frame', 'centroid_x', 'centroid_y']], on='frame')
    rel_x = merged['particle_x'] - merged['centroid_x']
    rel_y = merged['particle_y'] - merged['centroid_y']
    pdf = pdf.copy()
    pdf['leading_trailing_proj_px'] = (rel_x * dir_x + rel_y * dir_y).values
    pdf['is_leading'] = pdf['leading_trailing_proj_px'] > 0
    return pdf


def crossvalidate_with_bubble_analyser(df, frames_dir=FRAMES_DIR, out_dir=OUT_DIR,
                                        bubble_analyser_repo="./bubble_analyser"):
    """Step 7 (optional, external dependency): independent cross-check of Section 3.2's
    bubble diameter against the real, unmodified NormalWatershed algorithm from
    Bubble Analyser 2.0 (Mesa, Quintanilla & Reyes, 2022, Minerals Eng. 180:107497;
    Mesa & Guan, github.com/dmesap/bubble_analyser).

    Prerequisite (not vendored here -- clone the real repo yourself):
        git clone https://github.com/dmesap/bubble_analyser.git
        pip install opencv-python numpy scipy scikit-image --break-system-packages

    This function loads ONLY the five source files the classical watershed method
    needs (bypassing the package's PySide6 GUI layer and TensorFlow/Mask-R-CNN deep
    learning dependencies, neither of which the classical method uses), so the exact,
    real algorithm runs -- nothing here reimplements or approximates it.
    """
    import importlib.util
    import types

    def _load(modname, path):
        spec = importlib.util.spec_from_file_location(modname, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[modname] = mod
        spec.loader.exec_module(mod)
        return mod

    for pkg in ["bubble_analyser", "bubble_analyser.processing", "bubble_analyser.methods"]:
        if pkg not in sys.modules:
            m = types.ModuleType(pkg)
            m.__path__ = []
            sys.modules[pkg] = m

    R = bubble_analyser_repo
    _load("bubble_analyser.processing.threshold_methods", f"{R}/bubble_analyser/processing/threshold_methods.py")
    _load("bubble_analyser.processing.morphological_process", f"{R}/bubble_analyser/processing/morphological_process.py")
    _load("bubble_analyser.processing.image_postprocess", f"{R}/bubble_analyser/processing/image_postprocess.py")
    _load("bubble_analyser.processing.watershed_parent_class", f"{R}/bubble_analyser/processing/watershed_parent_class.py")
    wm = _load("bubble_analyser.methods.watershed_methods", f"{R}/bubble_analyser/methods/watershed_methods.py")
    NormalWatershed = wm.NormalWatershed

    params = {"resample": 1.0, "high_thresh": 0.95, "mid_thresh": 0.7, "low_thresh": 0.05,
              "element_size": 5, "connectivity": 4}  # the tool's own published defaults, unmodified
    records = []
    for _, row in df.iterrows():
        fnum = int(row['frame'])
        cx, cy = int(round(row['centroid_x'])), int(round(row['centroid_y']))
        img = cv2.imread(f"{frames_dir}/frame_{fnum:08d}.jpg")
        gray = mask_overlay(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
        # Bubble Analyser's default threshold expects dark bubbles on a light background;
        # this dataset is the opposite polarity (bright bubble, dark background), so invert.
        gray_inv = 255 - gray
        rgb_inv = cv2.cvtColor(gray_inv, cv2.COLOR_GRAY2BGR)

        ws = NormalWatershed(params)
        ws.initialize_processing(params, gray_inv, rgb_inv, if_bknd_img=False, px2mm=1.0)
        try:
            _, labels_watershed, _ = ws.get_results_img()
        except Exception as e:
            records.append({'frame': fnum, 'ba_found': False, 'error': str(e)})
            continue

        label = labels_watershed[cy, cx]
        if label < 2:  # centroid landed on a boundary/background pixel; search nearby
            found = False
            for r in range(1, 8):
                window = labels_watershed[max(0, cy-r):cy+r+1, max(0, cx-r):cx+r+1]
                cand = window[window >= 2]
                if len(cand) > 0:
                    label = np.bincount(cand).argmax()
                    found = True
                    break
            if not found:
                records.append({'frame': fnum, 'ba_found': False})
                continue

        area = int(np.sum(labels_watershed == label))
        records.append({'frame': fnum, 'ba_found': True, 'ba_area_px': area,
                         'ba_eq_diam_px': 2 * np.sqrt(area / np.pi), 'my_eq_diam_px': row['eq_diam_px']})

    return pd.DataFrame(records)


if __name__ == "__main__":
    os.makedirs(OUT_DIR, exist_ok=True)
    raw = track_bubble()
    kin = compute_kinematics(raw)
    full = detect_particles(kin)
    full.to_csv(f"{OUT_DIR}/bubble_kinematics_and_particles.csv", index=False)

    piv_df = run_piv(full['frame'].tolist())
    piv_df.to_csv(f"{OUT_DIR}/piv_summary.csv", index=False)

    individual_particles, full_v2 = compute_bubble_particle_ratio(full)
    individual_particles = classify_leading_trailing(individual_particles, full_v2)
    individual_particles.to_csv(f"{OUT_DIR}/individual_particles.csv", index=False)
    full_v2.to_csv(f"{OUT_DIR}/bubble_kinematics_and_particles_v2.csv", index=False)

    n_leading = individual_particles['is_leading'].sum()
    print(f"Leading-side fraction: {100*n_leading/len(individual_particles):.1f}%")
    print(full_v2[['bubble_to_particle_ratio_mean', 'bubble_to_particle_ratio_smd']].describe())
    print(piv_df.describe())

    if os.path.isdir("./bubble_analyser"):
        ba_df = crossvalidate_with_bubble_analyser(full_v2)
        ba_df.to_csv(f"{OUT_DIR}/bubble_analyser_crosscheck.csv", index=False)
        valid = ba_df[ba_df['ba_found']]
        print(f"\nBubble Analyser cross-check: found {len(valid)}/{len(ba_df)} frames, "
              f"r={valid['ba_eq_diam_px'].corr(valid['my_eq_diam_px']):.3f}")
    else:
        print("\n(Skipping Bubble Analyser cross-check: clone github.com/dmesap/bubble_analyser "
              "into ./bubble_analyser first -- see crossvalidate_with_bubble_analyser docstring.)")
