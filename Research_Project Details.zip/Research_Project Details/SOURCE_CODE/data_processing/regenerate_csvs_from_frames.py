#!/usr/bin/env python3
"""
regenerate_csvs_from_frames.py
==============================
Re-runs the ORIGINAL, unmodified analysis_pipeline.py on the raw frames (frames 25-120) and compares the result
with the CSV files supplied by the authors. TESTED RESULT (see AUDIT): all columns identical (max|diff| <= 6e-14
for kinematics, particles and PIV; 1.4e-14 for the Bubble Analyser cross-check).

Usage (from the repository root):
    pip install -r ENVIRONMENT/requirements.txt
    python SOURCE_CODE/data_processing/regenerate_csvs_from_frames.py            # steps 1-6 (about 25 s)
    python SOURCE_CODE/data_processing/regenerate_csvs_from_frames.py --with-bubble-analyser
         # also clones github.com/dmesap/bubble_analyser (needs git + internet) and repeats the cross-check
"""
import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).resolve().parent))
import analysis_pipeline as ap  # noqa: E402  (original authors' code, unmodified)

RAW = ROOT / "DATA" / "RAW_DATA" / "system_C_single_bubble_frames"
SUP = ROOT / "DATA" / "PROCESSED_DATA" / "supplied_csv"
OUT = ROOT / "DATA" / "PROCESSED_DATA" / "regenerated_from_frames"
FIRST, LAST = 25, 120


def compare(name, new, ref):
    cols = [c for c in ref.columns if c in new.columns]
    worst = 0.0
    for c in cols:
        a, b = new[c], ref[c]
        if a.dtype == object or a.dtype == bool or b.dtype == bool:
            if not (a.astype(str) == b.astype(str)).all():
                worst = float("inf")
        else:
            worst = max(worst, float(np.nanmax(np.abs(a.values.astype(float) - b.values.astype(float)))))
    print(f"{name:34s} rows {len(new)}/{len(ref)}  columns {len(cols)}/{len(ref.columns)}  max|diff| = {worst:.3g}  ->",
          "IDENTICAL" if worst < 1e-9 else "DIFFERENT")
    return worst < 1e-9


def main():
    ap_ = argparse.ArgumentParser()
    ap_.add_argument("--with-bubble-analyser", action="store_true")
    args = ap_.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        frames = Path(tmp) / "frames"; frames.mkdir()
        for i in range(FIRST, LAST + 1):
            shutil.copy(RAW / f"frame_{i:08d}.jpg", frames / f"frame_{i:08d}.jpg")
        work = Path(tmp) / "out"
        raw = ap.track_bubble(str(frames), str(work))
        kin = ap.compute_kinematics(raw)
        full = ap.detect_particles(kin, str(frames), str(work))
        piv = ap.run_piv(full["frame"].tolist(), str(frames), str(work))
        parts, full2 = ap.compute_bubble_particle_ratio(full, str(frames), str(work))
        parts = ap.classify_leading_trailing(parts, full2)
        full2.to_csv(OUT / "bubble_kinematics_and_particles.csv", index=False)
        parts.to_csv(OUT / "individual_particles.csv", index=False)
        piv.to_csv(OUT / "piv_summary.csv", index=False)
        ok = [compare("bubble_kinematics_and_particles", full2, pd.read_csv(SUP / "bubble_kinematics_and_particles.csv")),
              compare("individual_particles", parts, pd.read_csv(SUP / "individual_particles.csv")),
              compare("piv_summary", piv, pd.read_csv(SUP / "piv_summary.csv"))]
        if args.with_bubble_analyser:
            repo = Path(tmp) / "bubble_analyser"
            subprocess.run(["git", "clone", "--depth", "1", "https://github.com/dmesap/bubble_analyser.git", str(repo)], check=True)
            print("Bubble Analyser commit:", subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip())
            ba = ap.crossvalidate_with_bubble_analyser(full2, str(frames), str(work), str(repo))
            ba.to_csv(OUT / "bubble_analyser_crosscheck.csv", index=False)
            ok.append(compare("bubble_analyser_crosscheck", ba, pd.read_csv(SUP / "bubble_analyser_crosscheck.csv")))
    print("ALL IDENTICAL" if all(ok) else "SOME DIFFER - see above")
    return 0 if all(ok) else 1


if __name__ == "__main__":
    sys.exit(main())
