#!/usr/bin/env python3
"""
recover_savgol_parameters.py
============================
The smoothed ('_sg') columns used by the manuscript are absent from the supplied CSV files and no script states
the Savitzky-Golay parameters. This script searches window length (5-39, odd), polynomial order (1-5) and boundary
mode for the combination that reproduces the manuscript's smoothed-diameter statistics (mean, SD, min, max,
noise floor) taken from the authors' recomputed_stats.json. RESULT: window 11, order 3, mode 'interp'
matches to 5e-14; the next-best candidate misses by 1e-2. Nothing else in this repository is tuned to the target.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.signal import savgol_filter

ROOT = Path(__file__).resolve().parents[2]
d = pd.read_csv(ROOT / "DATA/PROCESSED_DATA/supplied_csv/bubble_kinematics_and_particles.csv").eq_diam_px.values
T = json.load(open(ROOT / "DATA/DERIVED_DATA/legacy_supplied_stale/recomputed_stats.json"))
res = []
for w in range(5, 40, 2):
    for o in range(1, 6):
        if o >= w:
            continue
        for mode in ("interp", "mirror", "nearest", "constant"):
            s = savgol_filter(d, w, o, mode=mode)
            e = abs(s.std() - T["bubble_diameter_std_px"]) + abs(s.min() - T["bubble_diameter_min_px"]) + abs(s.max() - T["bubble_diameter_max_px"])
            res.append((e, w, o, mode))
res.sort()
print("best candidates (error, window, order, mode):")
for r in res[:4]:
    print(f"  {r[0]:.3e}  window={r[1]} order={r[2]} mode={r[3]}")
