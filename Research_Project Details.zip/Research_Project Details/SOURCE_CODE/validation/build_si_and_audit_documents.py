#!/usr/bin/env python3
"""Builds Supplementary_Information.(md|docx|pdf) and FINAL_SCIENTIFIC_DATA_AND_REPRODUCIBILITY_AUDIT.(md|docx|pdf).
Numbers are read from the derived JSON/CSV files; requires pandoc and LibreOffice (soffice) for the Word/PDF conversion."""
import csv
import json
import subprocess
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
S = json.load(open(ROOT / "DATA/DERIVED_DATA/manuscript_statistics.json"))
sens = pd.read_csv(ROOT / "DATA/DERIVED_DATA/sensitivity_fps_scale.csv")
imp = pd.read_csv(ROOT / "DATA/DERIVED_DATA/implied_induction_times.csv")
claims = list(csv.DictReader(open(ROOT / "AUDIT/claim_verification.csv")))
fails = [c for c in claims if c["status"] == "FAIL"]
npass = sum(c["status"] == "PASS" for c in claims)
nstar = sum(c["status"] == "PASS*" for c in claims)


def md_table(header, rows):
    out = "| " + " | ".join(header) + " |\n|" + "---|" * len(header) + "\n"
    for r in rows:
        out += "| " + " | ".join(str(x) for x in r) + " |\n"
    return out


# ---------------------------------------------------------------- Supplementary Information
si = f"""---
title: "Supplementary Information"
subtitle: "Single-bubble mineral collection model: data, calculations and reproducibility material"
---

# 1. Scope and provenance

This document accompanies *Final_Manuscript_Cl.docx*. It documents the data, calculations and code behind the single-bubble (system C) results and the collection model. Systems A (zeta potential, BPATE) and B (bubble size distributions, flotation kinetics) are described in the manuscript but **no data for them were supplied**; nothing about them has been re-derived here (Section 6). All values below were recomputed from the supplied files by the code in the repository; the commands are in DOCUMENTATION/MODEL_EXECUTION_GUIDE.md.

**Two inputs are unverified and control every SI-unit result:** the frame rate (manuscript: 2000 fps; author slides and scripts: 500 fps, "only assumed") and the spatial scale (manuscript: 11.2 um/px; the burned-in 3 mm bar is clipped by the image edge, 187 px visible = 16.04 um/px if unclipped). Sensitivity results are given in Table S5 and Fig. S1.

# 2. Supplementary tables

## Table S1. System C datasets

{md_table(["Dataset", "Rows", "Origin", "Role"], [
    ["frame_00000000-00000120.jpg", "121", "Raw, 864 x 496, 8-bit", "Source images; frames 25-120 analysed"],
    ["bubble_kinematics_and_particles.csv", "96", "Author CSV, regenerated from frames (max diff 6e-14)", "Bubble size, position, shape, feature counts"],
    ["individual_particles.csv", "5,673", "Author CSV, regenerated", "Position and diameter of each detected feature"],
    ["piv_summary.csv", "95", "Author CSV, regenerated", "Far-field PIV statistics per frame pair"],
    ["bubble_analyser_crosscheck.csv", "96", "Author CSV, regenerated with Bubble Analyser commit 63b22f3 (max diff 1.4e-14)", "Independent diameter"],
    ["IMG_9423, 9432, 9433, 9434 (RGB, 2400 x 1600)", "4", "Raw micrographs", "No physical scale; not used for any reported number"]])}

## Table S2. Image-analysis parameters (read from the code)

{md_table(["Stage", "Parameter", "Value"], [
    ["Segmentation", "Blur / threshold / morphology", "Gaussian 5x5 / Otsu / close 5x5 ellipse, open 3x3"],
    ["Segmentation", "Tail severing; contour", "13x13 ellipse erode-keep-largest-dilate; convex hull; ellipse fit"],
    ["Segmentation", "ROI margin", "max(90 px, 2.2 x previous radius)"],
    ["Feature detection", "Mask erosion; high-pass sigma", "15 px; 9 px"],
    ["Feature detection", "High-pass threshold", "**18 gray levels** (the manuscript states 'not recorded')"],
    ["Feature detection", "Accepted area", "2-200 px^2 (d = 1.60-15.96 px)"],
    ["PIV", "Window / overlap / search / S-N", "32 / 16 / 32 px / peak2peak > 1.25; bubble contours dilated 41 px excluded"],
    ["Smoothing", "Savitzky-Golay", "window 11, order 3 (recovered; matches published statistics to 5e-14)"]])}

## Table S3. Model inputs and verification status

{md_table(["Input", "Value", "Unit", "Status"], [
    ["Spatial scale", "11.2", "um/px", "UNVERIFIED (clipped bar)"], ["Frame rate", "2000", "fps", "CONFLICTING (500 vs 2000)"],
    ["rho_L, mu_L, sigma", "997.5; 0.932e-3; 0.072", "kg/m3; Pa s; N/m", "Assumed pure water 23 C"],
    ["d_p", "29", "um", "From systems A/B; not measured in system C"], ["rho_p", "3000", "kg/m3", "Magnesite"],
    ["Ea", "0.78", "-", "System A BPATE; raw data missing"], ["Es", "0.85 (0.80-0.95)", "-", "Assumed scenario"],
    ["Solids concentration", "10", "kg/m3", "System B slurry, not system C"]])}

## Table S4. Model chain at the manuscript's scenario (2000 fps, 11.2 um/px)

{md_table(["Quantity", "Recomputed", "Manuscript"], [
    ["d_b (mm)", f"{S['d_mean_mm']:.3f}", "1.304"], ["V_b (mm/s)", f"{S['v_mm_s_mean']:.1f}", "34.8"], ["Re", f"{S['model_Re']:.1f}", "48.6"],
    ["Eo", f"{S['model_Eo']:.3f}", "0.231"], ["We", f"{S['model_We']:.4f}", "0.0219"], ["Mo", f"{S['model_Mo']:.2e}", "2.0e-11"],
    ["Ec", f"{S['model_Ec']:.2e}", "2.9e-3"], ["Ecoll", f"{S['model_Ecoll']:.2e}", "1.92e-3"], ["Np max", f"{S['model_Np_max']:.1f}", "599.6"],
    ["Np (model)", f"{S['model_Np']:.3f}", "1.15"], ["Mean detected features / Np", f"{S['count_to_Np_ratio']:.1f}", "about 51"],
    ["Implied Cd / rigid-sphere Cd", f"{S['Cd_implied']:.1f} / {S['Cd_rigid_at_Re']:.2f}", "14 / 1.6"]])}

## Table S5. Sensitivity to the unverified frame rate and scale (new analysis)

{md_table(["um/px", "fps", "d_b (mm)", "V_b (mm/s)", "Re", "Ec (x1e-3)", "Np model", "Features / Np", "V_b / V_rigid"],
          [[f"{r.um_per_px:.2f}", int(r.fps), f"{r.d_b_mm:.3f}", f"{r.v_b_mm_s:.1f}", f"{r.Re:.1f}", f"{r.Ec*1e3:.2f}", f"{r.Np_model:.2f}", f"{r.feature_count_over_Np:.1f}", f"{r.v_over_v_rigid:.3f}"] for r in sens.itertuples()])}

The qualitative conclusion that the feature count greatly exceeds the model estimate holds in all six scenarios (24 to 97 times). The quantitative factor (51) and the rise-velocity anomaly (V_b about 4 to 17 times below the rigid-sphere velocity) depend on the two unverified inputs.

## Table S6. Manuscript claims that do not reproduce ({len(fails)} of {len(claims)}; {npass} pass, {nstar} definition-dependent)

{md_table(["ID", "Location", "Quantity", "Printed", "Recomputed", "Note"], [[c["id"], c["manuscript_location"], c["quantity"], c["claimed"], c["recomputed"], c["note"]] for c in fails])}

Full list: AUDIT/claim_verification.csv and Supplementary_Tables.xlsx (ST4). Proposed corrections: AUDIT/CORRECTION_LOG.md.

## Table S7. Induction times implied by Eq. (4) (new analysis)

{md_table(["Ea", "t_c (ms)", "Implied t_i (ms)"], [[f"{r.Ea:.2f}", f"{r.contact_time_ms:.0f}", f"{r.implied_t_i_ms:.1f}"] for r in imp.itertuples()])}

At saturation (Ea = 0.95) the implied t_i of 22.7 ms exceeds t_i0 = 8.2 ms, so the fitted surrogate requires a non-zero barrier term even above the hemimicelle concentration.

# 3. Supplementary figures

![Fig. S1. Sensitivity of Re, Ec and the feature-to-model ratio to the assumed frame rate and scale.](../FIGURES/PUBLICATION_READY/Fig_S1_sensitivity_fps_scale.png){{width=100%}}

![Fig. S2. Robustness of the headline kinematic statistics to the Savitzky-Golay window and order.](../FIGURES/PUBLICATION_READY/Fig_S2_savgol_robustness.png){{width=100%}}

![Fig. S3. The burned-in 3 mm scale bar is cut by the image edge (frame 73).](../FIGURES/PUBLICATION_READY/Fig_S3_scale_bar_evidence.png){{width=100%}}

Functional reproductions of manuscript Figs. 3 to 11 are in FIGURES/PUBLICATION_READY/ (regenerated_from_authors_scripts and reproduced_from_data). Figs. 8 to 11 were rebuilt because the authors' plotting script for them was not supplied.

# 4. Supplementary equations, derivations and variables

**Eq. (4) inverted.** From Ea = sin^2[2 arctan(exp(-t_i/t_c))]: theta = arcsin(sqrt(Ea)), t_i = -t_c ln tan(theta/2). Used for Table S7.

**Eq. (10) and (11).** K = (3/2) Ecoll Jg/d_b = (1/4) Ecoll S_b with S_b = 6 Jg/d_b. For one size class Eq. (11) reduces to Eq. (10) (unit-tested).

**Feature mass.** m = (pi/6) d^3 rho_p, d = d_px x scale. Mass scales with scale cubed (x2.94 for 16.04 vs 11.2 um/px).

**Uncertainty propagation.** A relative scale uncertainty u gives 2u on Re and Eo (both scale squared at fixed fps) and 3u on We; arithmetic only.

**Implied drag coefficient.** Cd = (4/3)(rho_L - rho_g) g d / (rho_L V^2) = {S['Cd_implied']:.1f}; Schiller-Naumann rigid sphere: V = {S['v_rigid_sphere_m_s']:.3f} m/s, Cd = {S['Cd_rigid_at_Re']:.2f} at the measured Re.

**Lamb frequency (n = 2, bubble in liquid).** f2 = (1/2pi) sqrt(12 sigma/(rho_L R^3)) = {S['lamb_f2_Hz']:.0f} Hz for R = d_b/2 = 0.652 mm. A Hann-windowed periodogram of the detrended aspect ratio gives a dominant period of {S['aspect_fft_dominant_period_frames']:.0f} frames (two cycles in 96 frames; low confidence).

{md_table(["Symbol", "Meaning", "SI unit"], [
    ["d_b, d_p", "bubble, particle diameter", "m"], ["V_b", "bubble rise velocity", "m/s"], ["Re, Eo, We, Mo", "Reynolds, Eotvos, Weber, Morton numbers", "-"],
    ["Ec, Ea, Es, Ecoll", "collision, attachment, stability, total efficiency", "-"], ["t_i, t_c", "induction, contact time", "s"], ["C_p", "particle number concentration", "m^-3"],
    ["h_c", "collection-zone height (observed net rise)", "m"], ["N_p", "particles collected per bubble", "-"], ["K, K_total", "flotation rate constant", "s^-1"],
    ["J_g, S_b", "superficial gas velocity; bubble surface area flux", "m/s; s^-1"], ["rho, mu, sigma", "density, viscosity, surface tension", "kg/m3; Pa s; N/m"]])}

# 5. Limits of verification

The collection model is **verified** (implementation reproduces the printed numbers) but **not validated** (no measured K, recovery, collection efficiency or particle count independent of the image proxy exists). Ea comes from a calibration whose raw records are not available. See DOCUMENTATION/VALIDATION_GUIDE.md.

# 6. Not available

The missing-information list is in AUDIT/MISSING_INFORMATION.md (M-01 to M-12): frame-rate and scale primary records, original video, systems A and B raw data, suspension composition, IMG_9431, the Fig. 8-11 plotting script, controls and a free-rise measurement.
"""
(ROOT / "SUPPLEMENTARY_INFORMATION").mkdir(exist_ok=True)
(ROOT / "SUPPLEMENTARY_INFORMATION/Supplementary_Information.md").write_text(si)

# ---------------------------------------------------------------- Audit report
au = f"""---
title: "FINAL SCIENTIFIC DATA AND REPRODUCIBILITY AUDIT"
subtitle: "Single-bubble mineral collection model: supplementary package for Final_Manuscript_Cl.docx"
---

# Verdict

The computational package is complete for what the supplied data allow and every system C number can be regenerated from the raw frames. **The package is not submission-ready as a scientific claim set**: two inputs that every SI-unit result depends on (frame rate, spatial scale) are contradicted by the authors' own materials, {len(fails)} printed numbers do not reproduce, and the model is not validated. These are fixable in the manuscript; the first two need the authors' primary records.

# 1. What was prepared

Raw frames and micrographs, the four author CSVs, a consolidated statistics script (216 statistics), a 109-claim verification, an executable collection model (Eqs. 1-12) with 7 unit tests, a frame-rate and scale sensitivity analysis, an induction-time inversion, supplementary figures S1-S3, reproduced Figs. 8-11, a formula-driven workbook (11,830 formulas, 0 errors after recalculation), a data dictionary, a correction log (20 entries), a missing-information list (12 items), five guides, environment files and a one-command workflow (`run_all.sh`).

# 2. What was independently checked

{md_table(["Check", "Result"], [
    ["Authors' pipeline re-run on frames 25-120 (OpenCV, OpenPIV 0.26.1)", "kinematics (96 x 28), particles (5,673 x 7), PIV (95 x 10): identical, max difference 6e-14"],
    ["Bubble Analyser 2.0 cross-check re-run (commit 63b22f3)", "96/96 frames, identical to 1.4e-14"],
    ["Authors' JSON files re-generated by their scripts", "recomputed_stats and deep_single_bubble_stats identical; mineral_calculations identical to float noise"],
    ["Savitzky-Golay parameters", "window 11, order 3 reproduces published smoothed statistics to 5e-14; next best candidate misses by 1e-2"],
    ["109 manuscript claims", f"{npass} pass, {nstar} pass only under a stated definition, {len(fails)} fail"],
    ["Collection model (Ec, Ecoll, Cp, Np, Np range, Cd, rigid-sphere velocity, Lamb f2)", "all reproduce the printed values at 2000 fps and 11.2 um/px (7 tests)"],
    ["Scale bar in frame 73", "187 px visible, clipped by the image edge, label cut (Fig. S3)"]])}

# 3. Codes executed and tested

All scripts in SOURCE_CODE/ and the model tests were executed. The whole workflow was run in a clean virtual environment created from ENVIRONMENT/requirements.txt (AUDIT/TEST_LOG.md). The authors' legacy scripts ran with only path constants changed; `multi_bubble_analysis.py` skips IMG_9431 (not supplied). `run_bubmask.py` (deep-learning bubble sizing) was **not** executed: it needs the BubMask weights and repository, and none of its output is used in the manuscript.

# 4. What can be reproduced

All system C quantities in Sections 4.2 to 4.10, Figs. 3 to 7 (via the authors' scripts), Figs. 8 to 11 (functional reproduction), and the model chain of Section 4.9 **given** the scale and frame rate. Not reproducible: anything from systems A and B (zeta potential, BPATE, Ea, t_i0 and alpha, bubble size distributions, flotation kinetics), the Figure 1 schematic, literature values.

# 5. Manuscript results fully supported by the data

Bubble diameter statistics (116.45 +/- 1.98 px), noise floor, rise velocity (1.553 +/- 0.300 px/frame), net rise, verticality ratio 0.865, PIV statistics, feature counts and size statistics, BPR, leading/trailing split (3,352 vs 2,321), Bubble Analyser agreement (r = 0.975, slope 0.851, intercept 15.83 px), per-frame mass statistics and the Section 4.9 arithmetic, in pixel units.

# 6. Claims requiring correction or additional evidence

{md_table(["ID", "Item", "Action"], [
    ["CL-01", "Frame rate 2000 fps stated as documented; author slides say 500 fps was assumed", "Provide primary record or restate all velocities as px/frame plus a scenario"],
    ["CL-02", "Scale 11.2 um/px; bar clipped (16.04 um/px if unclipped)", "Measure on an uncropped calibration image"],
    ["CL-03 to CL-05", "SDs printed as 2.42, 2.1 and 0.056; data give 2.00, 1.75, 0.059", "Replace"],
    ["CL-06", "Oscillation count and 11.5-frame period not reproducible; feeds the f2 comparison", "Replace with periodogram result or delete"],
    ["CL-07, CL-08", "Top-25% mass share 75% (data 91%); U(f) 171 ug (data 174 ug)", "Replace"],
    ["CL-09, CL-10", "Range wording for frames 36-60; rise-per-frame basis", "Reword"],
    ["CL-11, CL-12", "High-pass threshold 'not recorded' (code: 18); further segmentation steps omitted", "Insert"],
    ["CL-14", "Micrograph inventory differs from supplied files", "Reconcile"],
    ["CL-15", "Author JSON files stale or wrong (500 fps; unit error; provenance)", "Do not deposit"]])}

Evidence still missing for the conclusions: systems A and B raw data (M-04, M-05), suspension composition (M-06), controls and a free-rise measurement (M-12), a detection-threshold sweep (M-10). The collection model is verified, not validated; Section 4.9 is an illustration and should stay worded as such.

# 7. Remaining limitations and submission risks

1. **One bubble, 47.5 ms (if 2000 fps), unknown suspension.** The effective sample size is one. This is the dominant risk with reviewers of any Q1 journal, and it is already stated by the authors.
2. **Unverified frame rate and scale.** At 500 fps the bubble rises at 8.7 mm/s, Re = 12 and the feature-to-model ratio is 97; at a 16.04 um/px scale the bubble is 1.87 mm. The headline numbers move by a factor of 2 to 3.
3. **Features are an image proxy** (no particle-free, tracer-only or hydrophilic controls).
4. **No validation** of the collection model; Ea rests on a calibration whose data are absent; E_a is attributed to a literature source in one author file and to system A in the manuscript.
5. **Deposit and licence.** Data are promised "upon acceptance"; most Nature-family journals expect access at review. A licence and citation file need the authors' decision.
6. **Fit for journal.** The material suits a specialist Q1 mineral-processing or chemical-engineering journal as a methods-and-reproducibility paper; it does not meet the evidential bar of Nature itself.

# 8. Files that were not created and why

LICENSE and CITATION.cff (no author, affiliation or licence information supplied); a corrected manuscript (the authors must decide CL-01 and CL-02 first); detection-threshold sweep and DLVO energy code (required inputs undocumented); BubMask re-run (weights not supplied).
"""
(ROOT / "AUDIT/FINAL_SCIENTIFIC_DATA_AND_REPRODUCIBILITY_AUDIT.md").write_text(au)

for src, outdir in ((ROOT / "SUPPLEMENTARY_INFORMATION/Supplementary_Information.md", ROOT / "SUPPLEMENTARY_INFORMATION"),
                    (ROOT / "AUDIT/FINAL_SCIENTIFIC_DATA_AND_REPRODUCIBILITY_AUDIT.md", ROOT / "AUDIT")):
    docx = outdir / (src.stem + ".docx")
    subprocess.run(["pandoc", str(src), "-o", str(docx), "--resource-path", str(src.parent)], check=True)
    subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", str(outdir), str(docx)], check=True, capture_output=True)
    print("built", docx.name)
