#!/usr/bin/env python3
"""Generates AUDIT/CORRECTION_LOG.(md|csv) and AUDIT/MANUSCRIPT_TO_DATA_TRACEABILITY.(md|csv).
The entries are curated text; every numeric 'evidence' value is recomputed in DATA/DERIVED_DATA/manuscript_statistics.json."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
S = json.load(open(ROOT / "DATA/DERIVED_DATA/manuscript_statistics.json"))
A = ROOT / "AUDIT"; A.mkdir(exist_ok=True)

# id, severity, manuscript location, original, problem, correction / status, evidence, affected
CL = [
 ("CL-01", "CRITICAL (unresolved)", "Abstract, S3.1, S3.3, S4.3, S4.7-4.9, Table 2, Fig. 3",
  "'Recorded at 2000 fps (0.5 ms interval)', described as the documented acquisition rate; every velocity, Re, We, Ec, Np and the 51-fold ratio use it.",
  "Author sources conflict: the imaging-procedure slides state 'We only assumed 500 fps' and the author scripts use 500 fps (Re = 11.3); the manuscript says 2000 fps from the schematic annotation. No primary record (video metadata, camera log) was supplied.",
  "NOT changed (authors must settle). Sensitivity table provided (ST3): at 500 fps Re = 12.1, Ec = 1.5e-3, Np = 0.61, features/Np = 96.5, V_b = 8.7 mm/s (about 17x below the rigid-sphere velocity); at 2000 fps Re = 48.6, features/Np = 51.",
  "DATA/DERIVED_DATA/sensitivity_fps_scale.csv; slides 'Imgaging_Procedure...' slides 3 and 11; mineral_calculations.json (assumed_fps 500)",
  "Abstract, S3.3, S4.3, S4.7, S4.8, S4.9, Fig. 3, Fig. 8, Table 2, Conclusions"),
 ("CL-02", "CRITICAL (unresolved)", "S3.3, Table 2, Limitation (iii)",
  "Analysis scale 0.0112 mm/px, 'two documented readings agree within +/-4%'.",
  "The burned-in '3 mm' bar in frame 73 is cut by the right image edge (187 px visible, label cut: Fig. S3). 3 mm / 187 px = 16.04 um/px if the visible part were the whole bar. The authors' own slide 11 flags this ('about 16.0 um/px and a 1.9 mm bubble, not 1.3 mm'). 11.2 um/px would need a 268 px bar, which is only possible if the bar is clipped.",
  "NOT changed. Must be measured on an uncropped frame/calibration image. Consequences if 16.04 is right: d_b = 1.87 mm, mass x2.94, Re x2 (at same fps).",
  "FIGURES/PUBLICATION_READY/Fig_S3_scale_bar_evidence; ST3",
  "All mm, m/s, ug results; Re, Eo, We, Ec, Np, Cd, mass"),
 ("CL-03", "HIGH", "S3.2/S4.7 (raw pipeline SD)",
  "Raw per-frame pipeline diameter '116.46 +/- 2.42 pixel'.",
  "SD of the raw diameters in bubble_kinematics_and_particles.csv is 2.004 (SD n) or 2.015 (SD n-1), range 111.48-121.62.",
  "Corrected to 116.46 +/- 2.00 pixel.", f"d_raw_sd_px = {S['d_raw_sd_px']:.4f}", "S4.2, S4.7, Fig. 7 caption"),
 ("CL-04", "HIGH", "S4.7",
  "Bubble Analyser diameter '114.95 +/- 2.1 pixel'; 'slope = 0.975 x 2.1/2.42 = 0.85'.",
  "SD of ba_eq_diam_px is 1.750. The slope statement should read 0.975 x 1.750/2.004 = 0.851, which is the reported slope; the arithmetic with the printed SDs gives 0.846.",
  "Corrected to 114.95 +/- 1.75 pixel; slope sentence updated.", f"ba_sd_px = {S['ba_sd_px']:.4f}; slope check = {S['ba_slope_from_summary_stats']:.4f}", "S4.7"),
 ("CL-05", "MEDIUM", "S4.2",
  "Aspect ratio '1.091 +/- 0.056'.", "SD is 0.0592 (n) / 0.0596 (n-1); 0.056 is not obtainable from the data.", "Corrected to 1.091 +/- 0.059.", f"aspect_sd = {S['aspect_sd']:.4f}", "S4.2, Fig. 3 caption"),
 ("CL-06", "HIGH", "S4.2, S4.8",
  "'3 peaks and 5 troughs; successive extremes 4-25 frames apart (mean 11.5)'; period 11.5 frames = 5.8 ms = 174 Hz; compared with Lamb f2.",
  "No peak-detection setting tried here (SG 5-21, raw, distance 1-8, prominence 0-0.01) reproduces 3/5 with 4-25 frame spacing. The authors' own script gives 5 peaks/7 troughs on the raw series; SG-smoothed gives 4/5 with spacing 1-18 (mean 8.6). A Hann-windowed periodogram of the detrended series gives a dominant period of 48 frames, but only two cycles fit in 96 frames.",
  "NOT reproducible as printed. Recommended: report the periodogram result with its limitation, or remove the quantitative oscillation-frequency comparison.",
  f"aspect_fft_dominant_period_frames = {S['aspect_fft_dominant_period_frames']:.0f}; legacy 5/7; SG 4/5", "S4.2, S4.8 (f2 comparison), Fig. 3d"),
 ("CL-07", "MEDIUM", "S4.9",
  "'The top 25% of features by mass carry about 75% of the total detected mass.'", "Recomputed share is 90.9% (top 1,418 of 5,673 features).", "Corrected to about 91%.", f"feat_mass_top25pct_share_pct = {S['feat_mass_top25pct_share_pct']:.1f}", "S4.9"),
 ("CL-08", "LOW", "S4.9, Fig. 8b",
  "'U(f) = 171 ug' (unique-detection estimate at frame 120).", "With q = 1 - 0.8524 (data) the estimate is 174.1 ug (174.5 with q rounded to 0.148).", "Corrected to about 174 ug.", f"unique_mass_U_ug_q_from_data = {S['unique_mass_U_ug_q_from_data']:.1f}", "S4.9, Fig. 8b legend"),
 ("CL-09", "LOW", "S4.10, Fig. 10",
  "'Across frames 36-60 ... detection count fluctuates between 56 and 79, coverage 7.05-9.45%, mass 7.60-17.42 ug.'",
  f"These ranges hold for the six annotated frames only. Over all frames 36-60 the count is {S['f36_60_count_min']:.0f}-{S['f36_60_count_max']:.0f} and coverage {S['f36_60_cov_min']:.2f}-{S['f36_60_cov_max']:.2f}%.",
  "Reword: 'at the six annotated frames'.", "six_stage_* vs f36_60_* statistics", "S4.10"),
 ("CL-10", "LOW", "S4.3, S4.9",
  "'146.92 pixel = 1.646 mm' and 'mean rise per frame 17.39 um'.", "146.917 px x 11.2 um = 1.6455 mm (rounds to 1.645). 17.39 um is mean SG velocity x scale; net rise / 95 intervals = 17.32 um.", "State the basis; use 1.645 mm. (Mass flux 652.8 ug/mm uses 17.39 um; 655.5 ug/mm with 17.32 um.)", f"net_rise_mm = {S['net_rise_mm']:.5f}", "S4.3, S4.9"),
 ("CL-11", "MEDIUM", "S3.4, Limitation (vi)",
  "'The detection threshold is not recorded.'", "analysis_pipeline.py records the high-pass threshold: 18 gray levels (8-bit), Gaussian sigma 9 px, erosion 15 px, area 2-200 px^2.", "Insert the values (ST7). The threshold-sensitivity sweep requested in Limitation (vi) is still outstanding.", "SOURCE_CODE/data_processing/analysis_pipeline.py, detect_particles", "S3.4, limitation (vi)"),
 ("CL-12", "MEDIUM", "S3.4 (methods)",
  "Segmentation description.", "Also used: 5x5 Gaussian blur, 3x3 opening, convex hull of the main component, ROI = max(90 px, 2.2 R), masking of the bottom 45 px / left 230 px / right 270 px overlay.", "Add to the methods or SI.", "ST7_Pipeline", "S3.4"),
 ("CL-13", "MEDIUM", "S3.4, Data availability",
  "'Exact software versions ... could not be re-established.'", "The supplied code was executed here (Python 3.12.3, OpenCV 4.13.0, OpenPIV 0.26.1, NumPy 2.4.4, pandas 3.0.2, SciPy 1.17.1, Bubble Analyser commit 63b22f3) and reproduced the four CSV files to <= 6e-14. Original versions remain unknown.", "State tested versions as 'verified environment' (ENVIRONMENT/software_versions.txt).", "AUDIT/TEST_LOG.md", "S3.4"),
 ("CL-14", "MEDIUM", "S3.5, Data availability",
  "'RGB of IMG_9433 was not present; IMG_9431's mask was absent and regenerated from its RGB.'",
  "Supplied files: IMG_9433 RGB IS present; IMG_9431 is absent entirely (RGB and mask); IMG_9434 is present but is not cited. The statement does not match the supplied package.", "Reconcile the file list before deposit.", "DATA/RAW_DATA/system_C_high_resolution_micrographs", "S3.5, Table 1"),
 ("CL-15", "HIGH (supplied files)", "legacy JSON files",
  "mineral_calculations.json, deep_single_bubble_stats.json, multi_bubble_stats.json.",
  "These were produced at 500 fps (Re 11.3, Ec 1.50e-3, Np 0.596, ratio 99) and are inconsistent with the manuscript (2000 fps); 'mineral_mass_flux.per_mm_ug' = 652,842 is a unit error (652.8 ug/mm); E_a is attributed to Batjargal et al. [13] while the manuscript presents it as a system A measurement; multi_bubble_stats.json uses an unverified 3 um/px although the manuscript claims no physical scale for the micrographs.",
  "Kept only in DATA/DERIVED_DATA/legacy_supplied_stale/ with a warning. Do not deposit as results.", "DATA/DERIVED_DATA/legacy_supplied_stale", "Data availability"),
 ("CL-16", "LOW", "recomputed_stats.json",
  "'bubble_straightness' = 0.8645; 'rise_velocity_raw_*' = NaN.", "0.8645 is the verticality ratio (net rise/path); straightness (net displacement/path) is 0.994. Raw velocity is NaN because of the first-row NaN (nanmean = 1.5476).", "Renamed in manuscript_statistics.json (verticality_ratio, straightness_index).", "", "none (manuscript already distinguishes them)"),
 ("CL-17", "LOW", "S4.5",
  "PIV TKE proxy 0.0218.", "Reproduces as 0.5(<RMSu>^2 + <RMSv>^2) = 0.02176; the authors' script gives 0.02268 (mean of per-pair values).", "State the definition used.", f"piv_tke_from_mean_rms = {S['piv_tke_from_mean_rms']:.5f}", "S4.5"),
 ("CL-18", "LOW", "all +/- values",
  "Standard-deviation convention not stated.", "Population SD (n) is used (e.g. feature count 9.68; sample SD 9.73).", "State 'SD (n)' or switch to sample SD.", "compute_manuscript_statistics.py", "all"),
 ("CL-19", "LOW", "S3.1",
  "'Compiled 1920 x 1080 recording'.", "Supplied frames are 864 x 496 px. The relation between the original recording and the exported frames (resampling would change the scale by 2.2x) is not documented.", "Document the export step and whether 11.2 um/px refers to the 864 x 496 frames.", "frame image size", "S3.1, S3.3"),
 ("CL-20", "LOW", "Eq. (2)",
  "Coefficients extracted from the .docx as '32 + 4Re^0.7215'.", "Likely a text-extraction artefact of a fraction typeset in OMML. Implemented as 3/2 + (4/15) Re^0.7215, which reproduces Ec = 2.9e-3. Please verify the equation renders correctly in Word.", "Verify in Word.", "unit test test_collection_chain_matches_manuscript", "S2.2"),
]
hdr = ["ID", "Severity", "Manuscript location", "Original value / statement", "Identified problem", "Correction or status", "Supporting evidence", "Affected sections"]
with open(A / "CORRECTION_LOG.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(hdr); w.writerows(CL)
with open(A / "CORRECTION_LOG.md", "w") as f:
    f.write("# Correction and consistency log\n\nNothing in the manuscript file was changed. Each entry records the original statement, the problem, the proposed correction and the evidence. "
            "CL-01 and CL-02 cannot be resolved from the supplied files and need the authors' primary records.\n\n")
    for r in CL:
        f.write(f"## {r[0]}  [{r[1]}]  {r[2]}\n\n- **Original:** {r[3]}\n- **Problem:** {r[4]}\n- **Correction / status:** {r[5]}\n- **Evidence:** {r[6]}\n- **Affected:** {r[7]}\n\n")

# ------------------------------------------------------------------ traceability
TR = [
 ("Figure 1", "Author schematic (not data)", "Imgaging_Procedure / Bubble_Mineral_Collection_Model pptx", "-", "Illustration; annotations 11.2 um/px, 2000 fps cannot be verified (CL-01, CL-02)"),
 ("Figure 2", "Pipeline schematic", "SOURCE_CODE/data_processing/analysis_pipeline.py", "ST7_Pipeline", "Parameters verified against code"),
 ("Figure 3a-d", "per_frame_processed.csv", "legacy_adapted/generate_figures.py (fig01); compute_manuscript_statistics.py", "ST5_Per_frame", "Regenerated: FIGURES/.../regenerated_from_authors_scripts/fig01"),
 ("Figure 3e", "Literature reference points", "-", "-", "Re-Eo reference plot; literature values not re-derived"),
 ("Figure 4", "piv_summary.csv + frames", "legacy_adapted/generate_figures.py (fig06)", "-", "Regenerated (fig06)"),
 ("Figure 5", "individual_particles.csv, bubble_kinematics...csv", "generate_figures.py (fig02, fig04)", "ST5, ST6", "Regenerated (fig02, fig04)"),
 ("Figure 6", "individual_particles.csv", "generate_figures.py (fig03)", "ST6", "Regenerated (fig03)"),
 ("Figure 7", "bubble_analyser_crosscheck.csv", "generate_figures.py (fig05); regenerate_csvs_from_frames.py --with-bubble-analyser", "-", "CSV regenerated from frames to 1e-14"),
 ("Figure 8", "per_frame_processed.csv, model inputs", "make_mass_and_gallery_figures.py", "ST2, ST5", "Functionally reproduced; original script not supplied"),
 ("Figures 9-10", "frames + features", "make_mass_and_gallery_figures.py", "-", "Functionally reproduced; original script not supplied"),
 ("Figure 11", "per_frame_processed.csv", "make_mass_and_gallery_figures.py", "ST5", "Functionally reproduced"),
 ("Table 1", "Provenance", "-", "-", "Systems A and B: no data supplied"),
 ("Table 2", "Parameters", "parameters.json", "ST1_Inputs", "System C rows verified; A/B rows unverifiable"),
 ("Table 3", "Literature comparison", "-", "-", "d_b/d_p ratios arithmetic only; literature values not re-derived"),
 ("Equation (1)", "-", "collection_model.total_efficiency", "ST2 row 'Ecoll'", "Unit-tested"),
 ("Equation (2)", "-", "collection_model.collision_efficiency_yoon_luttrell", "ST2 row 'Ec'", "Unit-tested, Ec = 2.91e-3"),
 ("Equation (3)", "-", "collection_model.surface_area_weights", "-", "Unit-tested (weights sum to 1); no size-class data supplied"),
 ("Equation (4)", "-", "collection_model.attachment_efficiency / implied_induction_time", "ST8_Induction", "Round-trip tested; BPATE raw data absent"),
 ("Equations (5)-(7)", "-", "induction_time_surrogate (Eq. 7 only)", "-", "DLVO energy W_B not implemented: required inputs undocumented (Missing information M-04)"),
 ("Equation (8)", "-", "capillary_adhesion_force, detachment_force, stability_efficiency", "-", "Implemented; Es = 0.85 is a scenario value"),
 ("Equation (9)", "-", "collection_model.particles_per_bubble", "ST2 rows Np_max, Np", "Unit-tested, Np_max = 599.7, Np = 1.158"),
 ("Equations (10)-(12)", "-", "rate_constant_single_size, rate_constant_total, recovery", "-", "Unit-tested for self-consistency; no measured K or recovery to compare"),
 ("S4.2 diameter/shape", "bubble_kinematics_and_particles.csv", "compute_manuscript_statistics.py", "ST4 C01-C45", "6 of 45 differ (CL-03, -04, -05, -06, -10)"),
 ("S4.3 kinematics", "same", "same", "ST4 C22-C34", "Reproduce (C27 rounding, CL-10)"),
 ("S4.4 features", "individual_particles.csv", "same", "ST4 C61-C77, C81-C82", "All reproduce"),
 ("S4.5 PIV", "piv_summary.csv", "same", "ST4 C54-C60", "Reproduce (TKE definition-dependent)"),
 ("S4.6 leading/trailing", "individual_particles.csv", "same", "ST4 C78-C80", "Reproduce (smoothed direction)"),
 ("S4.7 Bubble Analyser", "bubble_analyser_crosscheck.csv", "same + regenerate script", "ST4 C15-C21", "Reproduce except printed SDs (CL-04)"),
 ("S4.7 dimensionless groups", "-", "collection_model + parameters.json", "ST2, ST3", "Reproduce at 2000 fps and 11.2 um/px only"),
 ("S4.8 drag / Lamb", "-", "collection_model", "ST2", "Reproduce"),
 ("S4.9 mass and Np", "individual_particles.csv", "same", "ST4 C83-C101", "Reproduce except CL-07, CL-08"),
 ("S4.10", "frames, per-frame table", "same", "ST4 C102-C109", "Reproduce (CL-09 wording)"),
]
with open(A / "MANUSCRIPT_TO_DATA_TRACEABILITY.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["Manuscript item", "Supporting data", "Code", "Worksheet / table", "Status"]); w.writerows(TR)
with open(A / "MANUSCRIPT_TO_DATA_TRACEABILITY.md", "w") as f:
    f.write("# Manuscript-to-data traceability\n\n| Manuscript item | Supporting data | Code | Worksheet / table | Status |\n|---|---|---|---|---|\n")
    for r in TR:
        f.write("| " + " | ".join(r) + " |\n")
print(len(CL), "correction entries;", len(TR), "traceability rows")
