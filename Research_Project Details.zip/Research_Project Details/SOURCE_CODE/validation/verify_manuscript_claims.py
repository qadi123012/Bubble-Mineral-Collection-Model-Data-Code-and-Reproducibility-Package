#!/usr/bin/env python3
"""
verify_manuscript_claims.py
===========================
Compares each quantitative claim of Final_Manuscript_Cl.docx that can be traced to system C data against the value
recomputed by compute_manuscript_statistics.py. Writes AUDIT/claim_verification.csv.

Status codes
  PASS      recomputed value equals the claim within the stated rounding tolerance
  FAIL      recomputed value disagrees with the claim (see correction log)
  PASS*     reproduces only under an explicitly stated definition (see note)
Run: python SOURCE_CODE/validation/verify_manuscript_claims.py   (after compute_manuscript_statistics.py)
"""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
S = json.load(open(ROOT / "DATA" / "DERIVED_DATA" / "manuscript_statistics.json"))

# (id, manuscript location, description, claimed, key, abs_tol, unit, note, status_if_pass)
C = [
 ("C01","S4.2","smoothed mean diameter",116.45,"d_sg_mean_px",0.005,"px","",""),
 ("C02","S4.2","smoothed diameter SD (frame-to-frame)",1.98,"d_sg_sd_px",0.005,"px","",""),
 ("C03","S4.2","smoothed diameter min",111.54,"d_sg_min_px",0.005,"px","",""),
 ("C04","S4.2","smoothed diameter max",120.84,"d_sg_max_px",0.005,"px","",""),
 ("C05","S4.2","diameter CV",1.70,"d_sg_cv_pct",0.005,"%","",""),
 ("C06","S4.2","raw diameter mean",116.46,"d_raw_mean_px",0.005,"px","",""),
 ("C07","S4.7/S3.2","raw pipeline diameter SD (as printed)",2.42,"d_raw_sd_px",0.005,"px","Printed 2.42; data give 2.00 (SD n) / 2.01 (SD n-1).",""),
 ("C08","S4.7/S3.2","Bubble Analyser diameter SD (as printed)",2.1,"ba_sd_px",0.05,"px","Printed 2.1; data give 1.75.",""),
 ("C09","S4.2","noise floor (SD of raw - SG)",0.256,"d_noise_floor_px",0.0005,"px","",""),
 ("C10","S4.2","noise floor % of mean",0.22,"d_noise_floor_pct",0.005,"%","",""),
 ("C11","S4.2","smoothed peak-to-peak",9.3,"d_sg_peak_to_peak_px",0.05,"px","",""),
 ("C12","S4.2","peak-to-peak / noise floor",36,"d_sg_p2p_over_noise",0.5,"x","",""),
 ("C13","S4.2","mean diameter in mm (11.2 um/px)",1.304,"d_mean_mm",0.0005,"mm","scale unverified",""),
 ("C14","S4.2","combined diameter uncertainty",0.056,"d_combined_unc_mm",0.001,"mm","",""),
 ("C15","S4.7","BA mean diameter",114.95,"ba_mean_px",0.005,"px","",""),
 ("C16","S4.7","BA mean absolute difference",1.50,"ba_mean_abs_diff_px",0.005,"px","",""),
 ("C17","S4.7","BA mean absolute difference %",1.29,"ba_mean_abs_diff_pct",0.005,"%","",""),
 ("C18","S4.7","BA Pearson r",0.975,"ba_pearson_r",0.0005,"-","",""),
 ("C19","S4.7","BA R2",0.950,"ba_r2",0.0005,"-","",""),
 ("C20","S4.7","BA regression slope",0.851,"ba_slope",0.0005,"-","",""),
 ("C21","S4.7","BA regression intercept",15.83,"ba_intercept_px",0.005,"px","",""),
 ("C22","S4.3","net vertical rise",146.92,"net_rise_px",0.005,"px","",""),
 ("C23","S4.3","net horizontal drift",83.47,"net_horiz_px",0.005,"px","",""),
 ("C24","S4.3","path length",169.94,"path_px",0.005,"px","",""),
 ("C25","S4.3","verticality ratio (net rise / path)",0.865,"verticality_ratio",0.0005,"-","",""),
 ("C26","S4.3","net displacement / path",0.994,"straightness_index",0.0005,"-","",""),
 ("C27","S4.3","net vertical rise in mm",1.646,"net_rise_mm",0.0005,"mm","1.6455 mm exactly: rounds to 1.645 or 1.646 depending on input rounding.",""),
 ("C28","S3.3","field of view x",9.7,"fov_x_mm",0.05,"mm","",""),
 ("C29","S3.3","field of view y",5.6,"fov_y_mm",0.05,"mm","",""),
 ("C30","S4.3","observation window",47.5,"window_ms",0.01,"ms","assumes 2000 fps (CONFLICTING)",""),
 ("C31","S4.3","mean rise velocity",1.553,"v_px_frame_mean",0.0005,"px/frame","",""),
 ("C32","S4.3","rise velocity SD",0.300,"v_px_frame_sd",0.0005,"px/frame","",""),
 ("C33","S4.3","mean rise velocity (mm/s)",34.8,"v_mm_s_mean",0.05,"mm/s","assumes 2000 fps and 11.2 um/px",""),
 ("C34","S4.3","rise velocity SD (mm/s)",6.7,"v_mm_s_sd",0.05,"mm/s","",""),
 ("C35","S4.2","aspect ratio mean",1.091,"aspect_mean",0.0005,"-","",""),
 ("C36","S4.2","aspect ratio SD (as printed)",0.056,"aspect_sd",0.0005,"-","Printed 0.056; data give 0.0592 (n) / 0.0596 (n-1).",""),
 ("C37","S4.2","aspect ratio min",1.008,"aspect_min",0.0005,"-","",""),
 ("C38","S4.2","aspect ratio max",1.322,"aspect_max",0.0005,"-","",""),
 ("C39","S4.2","major axis mean",122.28,"major_mean_px",0.005,"px","",""),
 ("C40","S4.2","major axis SD",3.56,"major_sd_px",0.005,"px","",""),
 ("C41","S4.2","minor axis mean",112.24,"minor_mean_px",0.005,"px","",""),
 ("C42","S4.2","minor axis SD",3.97,"minor_sd_px",0.01,"px","",""),
 ("C43","S4.2","number of aspect-ratio peaks",3,"aspect_peaks_sg",0,"count","Not reproducible: legacy script gives 5, SG-smoothed gives 4.",""),
 ("C44","S4.2","number of aspect-ratio troughs",5,"aspect_troughs_sg",0,"count","Legacy script gives 7, SG-smoothed gives 5.",""),
 ("C45","S4.2/S4.7","mean spacing of successive extremes",11.5,"aspect_extreme_spacing_mean_sg",0.05,"frames","Not reproducible (SG-smoothed gives 8.6; FFT dominant period 48 frames).",""),
 ("C46","S4.7","Re",48.6,"model_Re",0.05,"-","assumes 2000 fps, 11.2 um/px, pure water",""),
 ("C47","S4.7","Eo",0.231,"model_Eo",0.0005,"-","",""),
 ("C48","S4.7","We",0.0219,"model_We",0.00005,"-","",""),
 ("C49","S4.7","Mo",2.0e-11,"model_Mo",0.02e-11,"-","",""),
 ("C50","S4.8","implied drag coefficient",14,"Cd_implied",0.2,"-","",""),
 ("C51","S4.8","rigid-sphere Cd at same Re",1.6,"Cd_rigid_at_Re",0.05,"-","",""),
 ("C52","S4.8","rigid-sphere rise velocity",0.15,"v_rigid_sphere_m_s",0.005,"m/s","",""),
 ("C53","S4.8","Lamb n=2 frequency",281,"lamb_f2_Hz",1,"Hz","",""),
 ("C54","S4.5","PIV mean u",0.0150,"piv_u_mean",0.00005,"px/frame","",""),
 ("C55","S4.5","PIV mean v",0.1286,"piv_v_mean",0.00005,"px/frame","",""),
 ("C56","S4.5","PIV RMS u",0.1517,"piv_rms_u",0.00005,"px/frame","",""),
 ("C57","S4.5","PIV RMS v",0.1433,"piv_rms_v",0.00005,"px/frame","",""),
 ("C58","S4.5","PIV TKE proxy",0.0218,"piv_tke_from_mean_rms",0.00005,"(px/frame)^2","Reproduces only as 0.5(<RMS_u>^2+<RMS_v>^2); mean of per-pair values is 0.0227.","PASS*"),
 ("C59","S4.5","PIV mean speed",0.1917,"piv_speed_mean",0.00005,"px/frame","",""),
 ("C60","S4.5","bubble / far-field speed ratio",8.1,"piv_speed_ratio",0.05,"x","",""),
 ("C61","S4.4","feature count mean",59.09,"count_mean",0.005,"-","",""),
 ("C62","S4.4","feature count SD",9.68,"count_sd",0.005,"-","SD (n); SD (n-1) = 9.73",""),
 ("C63","S4.4","feature count min",38,"count_min",0,"-","",""),
 ("C64","S4.4","feature count max",93,"count_max",0,"-","",""),
 ("C65","S4.4","count trend slope",-0.156,"count_slope",0.0005,"per frame","nominal p only; frames autocorrelated",""),
 ("C66","S4.4","persistence",85.2,"persist_pct",0.05,"%","",""),
 ("C67","S4.4","net increases in count",46,"dn_increase",0,"frames","",""),
 ("C68","S4.4","net decreases in count",44,"dn_decrease",0,"frames","",""),
 ("C69","S4.4","largest single-frame gain",20,"dn_max",0,"-","",""),
 ("C70","S4.4","largest single-frame loss",-32,"dn_min",0,"-","",""),
 ("C71","S4.4","features total",5673,"n_features",0,"-","",""),
 ("C72","S4.4","feature mean diameter",2.99,"feat_mean_px",0.005,"px","",""),
 ("C73","S4.4","feature median diameter",2.26,"feat_median_px",0.005,"px","",""),
 ("C74","S4.4","feature SMD",6.67,"feat_smd_px",0.005,"px","",""),
 ("C75","S4.4","pooled BPR (SMD basis)",17.47,"bpr_pooled_smd",0.005,"-","",""),
 ("C76","S4.4","per-frame BPR mean",18.53,"bpr_frame_mean",0.005,"-","",""),
 ("C77","S4.4","per-frame BPR SD",3.46,"bpr_frame_sd",0.005,"-","",""),
 ("C78","S4.6","leading detections",3352,"lead_n",0,"-","uses SG centroids; the CSV column gives 3349",""),
 ("C79","S4.6","trailing detections",2321,"trail_n",0,"-","",""),
 ("C80","S4.6","mean projection offset",6.62,"proj_mean_px",0.005,"px","",""),
 ("C81","S4.4","share of features with r/R > 0.8",23.5,"radial_pct_gt_0p8",0.05,"%","",""),
 ("C82","S4.4","median r/R",0.703,"radial_median",0.0005,"-","",""),
 ("C83","S4.9","per-feature mean mass",192,"feat_mass_mean_ng",0.5,"ng","assumes 11.2 um/px, 3000 kg/m3",""),
 ("C84","S4.9","per-feature median mass",25,"feat_mass_median_ng",0.5,"ng","",""),
 ("C85","S4.9","share of mass in top 25% of features (as printed)",75,"feat_mass_top25pct_share_pct",1,"%","Printed ~75%; data give 90.9%.",""),
 ("C86","S4.9","total assumed mass of all detections",1090,"feat_mass_total_ug",1,"ug","",""),
 ("C87","S4.9","mean assumed load per frame",11.35,"frame_mass_mean_ng",5,"ng","reported in ug; compared in ng (x1000)",""),
 ("C88","S4.9","frame load SD",4375,"frame_mass_sd_ng",1,"ng","",""),
 ("C89","S4.9","frame load slope",-54.2,"frame_mass_slope_ng",0.05,"ng/frame","",""),
 ("C90","S4.9","estimated unique mass U(f) at frame 120",171,"unique_mass_U_ug_q_from_data",0.5,"ug","Data give 174.1 ug.",""),
 ("C91","S4.9","frame 60 load",17.42,"frame_mass_f60_ug",0.005,"ug","",""),
 ("C92","S4.9","mass flux",652.8,"mass_flux_ug_per_mm",0.05,"ug/mm","uses mean-velocity rise per frame (17.39 um); net-rise basis gives 655.5",""),
 ("C93","S4.9","Ec",0.0029,"model_Ec",0.00005,"-","",""),
 ("C94","S4.9","Ecoll",0.00192,"model_Ecoll",0.00002,"-","",""),
 ("C95","S4.9","Np max",599.6,"model_Np_max",0.1,"-","",""),
 ("C96","S4.9","Np",1.15,"model_Np",0.01,"-","1.158 recomputed",""),
 ("C97","S4.9","measured / model Np",51,"count_to_Np_ratio",0.5,"x","",""),
 ("C98","S4.9","Ecoll lower (Es=0.80)",1.81e-3,"Ecoll_Es_80",0.01e-3,"-","",""),
 ("C99","S4.9","Ecoll upper (Es=0.95)",2.15e-3,"Ecoll_Es_95",0.01e-3,"-","",""),
 ("C100","S4.9","Np lower",1.08,"Np_Es_80",0.01,"-","",""),
 ("C101","S4.9","Np upper",1.29,"Np_Es_95",0.01,"-","",""),
 ("C102","S4.10","frame 36 diameter",115.42,"stage_f36_d_sg_px",0.005,"px","",""),
 ("C103","S4.10","frame 60 diameter",117.54,"stage_f60_d_sg_px",0.005,"px","",""),
 ("C104","S4.10","frame 36 y",216.78,"stage_f36_y_sg_px",0.005,"px","",""),
 ("C105","S4.10","frame 60 y",176.57,"stage_f60_y_sg_px",0.005,"px","",""),
 ("C106","S4.10","count over six annotated frames: min",56,"six_stage_count_min",0,"-","holds for the six annotated frames only (not all of 36-60: 53-93)",""),
 ("C107","S4.10","count over six annotated frames: max",79,"six_stage_count_max",0,"-","",""),
 ("C108","S4.10","coverage over six annotated frames: min",7.05,"six_stage_cov_min",0.005,"%","",""),
 ("C109","S4.10","coverage over six annotated frames: max",9.45,"six_stage_cov_max",0.005,"%","",""),
]
SCALE = {"C87": 1e-3}  # claim in ug, value in ng
rows, n = [], {"PASS": 0, "PASS*": 0, "FAIL": 0}
for cid, loc, desc, claim, key, tol, unit, note, ok_status in C:
    val = S[key] * SCALE.get(cid, 1.0) if cid != "C87" else S[key] * 1e-3
    claim_c = claim if cid != "C87" else claim
    tol_c = tol if cid != "C87" else tol * 1e-3
    ok = abs(val - claim_c) <= tol_c + 1e-12
    st = (ok_status or "PASS") if ok else "FAIL"
    n[st] += 1
    rows.append(dict(id=cid, manuscript_location=loc, quantity=desc, claimed=claim, recomputed=f"{val:.6g}", abs_diff=f"{abs(val-claim_c):.4g}",
                     tolerance=tol_c, unit=unit, status=st, key=key, note=note))
out = ROOT / "AUDIT" / "claim_verification.csv"
out.parent.mkdir(exist_ok=True)
with open(out, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(f"{len(rows)} claims checked: {n}")
for r in rows:
    if r["status"] != "PASS":
        print(r["id"], r["status"], r["quantity"], "claimed", r["claimed"], "recomputed", r["recomputed"])
