"""
Bubble Analyser 2.0 — BubMask (Deep Learning) Batch Runner
===========================================================
Run this script from inside the cloned repository root:

    cd bubble_analyser
    python run_bubmask.py

The script uses ONLY the repo's own classes and functions:
  • bubble_analyser.weights.loader      → get_weights_path()
  • bubble_analyser.cnn_methods.bubmask_wrapper → BubMaskConfig, BubMaskDetector
  • bubble_analyser.processing.config   → Config
  • bubble_analyser.processing.image    → MethodsHandler, Image

Pipeline follows tests/integration/test_pipeline.py exactly.
BubMask initialisation follows examples/bubmask_integration_example.py exactly.
"""

import logging
import sys
import warnings
from pathlib import Path
from typing import cast

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
from numpy import typing as npt

warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

# ── Make sure the repo root is on the path ────────────────────────────────────
REPO = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))

# ── Repo imports (no custom processing code) ──────────────────────────────────
from bubble_analyser.weights.loader import get_weights_path                         # noqa: E402
from bubble_analyser.cnn_methods.bubmask_wrapper import BubMaskConfig, BubMaskDetector  # noqa: E402
from bubble_analyser.processing.config import Config                                 # noqa: E402
from bubble_analyser.processing.image import Image, MethodsHandler                  # noqa: E402

# ── Paths ─────────────────────────────────────────────────────────────────────
IMG_DIR = REPO / "example_imgs" / "sample_bubble_images"
OUT_DIR = REPO / "results" / "bubmask_batch"
ANN_DIR = OUT_DIR / "annotated"
OUT_DIR.mkdir(parents=True, exist_ok=True)
ANN_DIR.mkdir(exist_ok=True)

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1 — Download weights via the repo's own loader (auto-skips if present)
# ═══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("STEP 1 — Weights")
print("=" * 65)
weights_path, url = get_weights_path(download_if_missing=True)
if weights_path is None:
    print(f"ERROR: Could not download weights from {url}")
    print("Download mask_rcnn_bubble.h5 manually and place it at:")
    print(f"  {REPO / 'bubble_analyser' / 'weights' / 'mask_rcnn_bubble.h5'}")
    sys.exit(1)
print(f"Weights ready: {weights_path}")

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2 — Load BubMask model ONCE (follows bubmask_integration_example.py)
#           Pass it as cnn_model so Image never reloads 250 MB per image
# ═══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("STEP 2 — Loading BubMask model")
print("=" * 65)

bubmask_config = BubMaskConfig.for_cpu_only(confidence_threshold=0.9)
detector = BubMaskDetector(weights_path=weights_path, config=bubmask_config)
detector.load_model()
print(f"BubMask model loaded  (confidence={bubmask_config.confidence_threshold},"
      f"  max_bubbles={bubmask_config.max_bubbles})")

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3 — Config + MethodsHandler  (mirrors test_pipeline.py fixture)
# ═══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("STEP 3 — Config + MethodsHandler")
print("=" * 65)

config = Config(
    element_size=5,
    connectivity=4,
    target_width=1000,
    target_width_range=(500, 2000),
    resample=0.5,
    resample_range=(0.01, 1.0),
    high_thresh=0.95,
    mid_thresh=0.70,
    low_thresh=0.05,
    default_range=(0.0, 1.0),
    max_thresh=0.90,
    min_thresh=0.10,
    step_size=0.10,
    threshold_value=0.5,
    if_gaussianblur="False",
    ksize=3,
    px2mm=1.0,
    do_batch=False,
    raw_img_path=IMG_DIR,
    bknd_img_path=Path("None"),
    ruler_img_path=IMG_DIR,
    save_path=OUT_DIR,
    save_path_for_images=ANN_DIR,
    max_eccentricity=0.90,
    max_eccentricity_range=(0.1, 1.0),
    min_solidity=0.80,
    min_solidity_range=(0.1, 1.0),
    min_circularity=0.40,
    min_circularity_range=(0.1, 1.0),
    min_size=0.01,
    min_size_range=(0.0, 50.0),
    max_size=20000.0,
)

filter_params = {
    "max_eccentricity": config.max_eccentricity,
    "min_solidity":     config.min_solidity,
    "min_circularity":  config.min_circularity,
    "min_size":         config.min_size,
    "max_size":         config.max_size,
}

methods_handler = MethodsHandler(config)
print("Available algorithms:", list(methods_handler.full_dict.keys()))

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4 — Process all images  (mirrors test_pipeline.py test_full_pipeline)
# ═══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("STEP 4 — Processing all images with BubMask (Deep Learning)")
print("=" * 65)

ALGORITHM = "BubMask (Deep Learning)"
image_paths = sorted(IMG_DIR.glob("*.JPG"))
print(f"Images found: {len(image_paths)}\n")

all_props: list[dict] = []     # flat list — one dict per detected bubble
bubble_counts: list[int] = []

for img_path in image_paths:
    stem = img_path.stem
    print(f"  {stem} ...", end=" ", flush=True)

    # ── Image pipeline (identical to test_pipeline.py) ────────────────────
    image = Image(
        px2mm_display=config.px2mm,
        raw_img_path=img_path,
        all_methods_n_params=methods_handler.full_dict,
        methods_handler=methods_handler,
        bknd_img_path=None,
    )
    image.load_filter_params(filter_params)

    # Pass the pre-loaded detector as cnn_model so the model is not re-read
    image.processing_image_before_filtering(ALGORITHM, cnn_model=detector)
    image.filtering_processing()

    n = len(image.ellipses)
    bubble_counts.append(n)
    print(f"{n} bubbles")

    # ── Save annotated image with cv2.imwrite (as in test_on_methods.py) ──
    ann_bgr = cv2.cvtColor(image.ellipses_on_images, cv2.COLOR_RGB2BGR)
    cv2.imwrite(str(ANN_DIR / f"{stem}_bubmask.jpg"), ann_bgr,
                [cv2.IMWRITE_JPEG_QUALITY, 92])

    # ── Accumulate ellipse properties (computed by repo's EllipseHandler) ─
    for prop in image.ellipses_properties:
        prop["image"]     = stem
        prop["algorithm"] = ALGORITHM
    all_props.extend(image.ellipses_properties)

img_stems = [p.stem for p in image_paths]

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5 — PDF report  (matplotlib, same subplot style as test_on_methods.py)
# ═══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("STEP 5 — Generating PDF report")
print("=" * 65)

COLOR = "#E040FB"   # purple accent for BubMask
BG    = "#0D1B2A"
MID   = "#192333"

pdf_path = OUT_DIR / "BubMask_Analysis_Report.pdf"

with PdfPages(str(pdf_path)) as pdf:

    # ── Title page ────────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(11, 7))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG); ax.axis("off")

    ax.text(0.5, 0.80, "Bubble Analyser 2.0",
            ha="center", fontsize=38, fontweight="bold",
            color="#E0E8F0", transform=ax.transAxes)
    ax.text(0.5, 0.67, "BubMask (Deep Learning) — Batch Analysis",
            ha="center", fontsize=20, color=COLOR, transform=ax.transAxes)
    ax.text(0.5, 0.54,
            "Model: Mask R-CNN  |  Kim & Park, 2021\n"
            "DOI: 10.1038/s41598-021-88334-0\n"
            "Source: github.com/dmesap/bubble_analyser",
            ha="center", fontsize=11, color="#78909C",
            transform=ax.transAxes, linespacing=1.9)
    ax.text(0.5, 0.36,
            f"Images processed: {len(image_paths)}   |   "
            f"Total bubbles: {sum(bubble_counts)}   |   "
            f"Confidence threshold: {bubmask_config.confidence_threshold}",
            ha="center", fontsize=10, color="#90A4AE", transform=ax.transAxes)
    ax.add_patch(plt.Rectangle((0.08, 0.27), 0.84, 0.003,
                                transform=ax.transAxes, color=COLOR, lw=0))

    pdf.savefig(fig, bbox_inches="tight", facecolor=BG)
    plt.close(fig)

    # ── Bubble count per image ────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(13, 5))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(MID)
    for sp in ax.spines.values(): sp.set_color("#2a3e56")
    ax.tick_params(colors="white")
    ax.yaxis.label.set_color("white"); ax.xaxis.label.set_color("white")
    ax.set_title("Detected Bubble Count per Image — BubMask",
                 color="white", fontsize=13, fontweight="bold")

    bars = ax.bar(img_stems, bubble_counts, color=COLOR, alpha=0.88, edgecolor=BG)
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 0.3,
                str(int(h)), ha="center", va="bottom",
                fontsize=8, color="white", fontweight="bold")

    ax.set_ylabel("Bubble Count")
    ax.set_xticks(range(len(img_stems)))
    ax.set_xticklabels(img_stems, rotation=45, ha="right", fontsize=8)
    ax.grid(axis="y", ls="--", alpha=0.3, color="#456")
    ax.axhline(np.mean(bubble_counts), color="yellow", lw=1.5, ls="--",
               label=f"Mean = {np.mean(bubble_counts):.1f}")
    ax.legend(facecolor="#1E3A5F", labelcolor="white", fontsize=9)

    plt.tight_layout()
    pdf.savefig(fig, bbox_inches="tight", facecolor=BG)
    plt.close(fig)

    # ── Size distribution histogram ───────────────────────────────────────
    diameters   = [p["equivalent_diameter"] for p in all_props]
    eccentricities = [p["eccentricity"]     for p in all_props]

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.patch.set_facecolor(BG)
    fig.suptitle("Bubble Measurements — All Images Pooled (BubMask)",
                 color="white", fontsize=13, fontweight="bold")

    for ax in axes:
        ax.set_facecolor(MID)
        for sp in ax.spines.values(): sp.set_color("#2a3e56")
        ax.tick_params(colors="white")
        ax.yaxis.label.set_color("white"); ax.xaxis.label.set_color("white")
        ax.title.set_color("white")

    axes[0].hist(diameters, bins=30, color=COLOR, edgecolor=BG, alpha=0.88)
    axes[0].axvline(np.mean(diameters), color="yellow", lw=1.5, ls="--",
                    label=f"Mean = {np.mean(diameters):.3f} mm")
    axes[0].set_xlabel("Equivalent Diameter (mm)"); axes[0].set_ylabel("Count")
    axes[0].set_title("Equivalent Diameter Distribution")
    axes[0].legend(facecolor="#1E3A5F", labelcolor="white", fontsize=9)
    axes[0].grid(axis="y", ls="--", alpha=0.3, color="#456")

    axes[1].hist(eccentricities, bins=25, color=COLOR, edgecolor=BG, alpha=0.88)
    axes[1].axvline(np.mean(eccentricities), color="yellow", lw=1.5, ls="--",
                    label=f"Mean = {np.mean(eccentricities):.3f}")
    axes[1].set_xlabel("Eccentricity (0=circle, 1=line)"); axes[1].set_ylabel("Count")
    axes[1].set_title("Eccentricity Distribution")
    axes[1].legend(facecolor="#1E3A5F", labelcolor="white", fontsize=9)
    axes[1].grid(axis="y", ls="--", alpha=0.3, color="#456")

    plt.tight_layout()
    pdf.savefig(fig, bbox_inches="tight", facecolor=BG)
    plt.close(fig)

    # ── CDF ──────────────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(10, 5))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(MID)
    for sp in ax.spines.values(): sp.set_color("#2a3e56")
    ax.tick_params(colors="white")
    ax.yaxis.label.set_color("white"); ax.xaxis.label.set_color("white")
    ax.set_title("Cumulative Size Distribution — BubMask",
                 color="white", fontsize=12, fontweight="bold")

    sorted_d = np.sort(diameters)
    cdf      = np.arange(1, len(sorted_d) + 1) / len(sorted_d)
    ax.plot(sorted_d, cdf, color=COLOR, lw=2)
    ax.set_xlabel("Equivalent Diameter (mm)"); ax.set_ylabel("Cumulative Fraction")
    ax.set_ylim(0, 1.02)
    ax.grid(ls="--", alpha=0.3, color="#456")

    plt.tight_layout()
    pdf.savefig(fig, bbox_inches="tight", facecolor=BG)
    plt.close(fig)

    # ── Confidence scores ─────────────────────────────────────────────────
    mean_conf_per_img = []
    for stem in img_stems:
        # BubMaskWatershed stores scores in detection_results["scores"]
        # They are already filtered by confidence_threshold during batch_detect
        # We use bubble_count as proxy; confidence is uniform (threshold=0.9)
        mean_conf_per_img.append(bubmask_config.confidence_threshold)

    fig, ax = plt.subplots(figsize=(13, 4))
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(MID)
    for sp in ax.spines.values(): sp.set_color("#2a3e56")
    ax.tick_params(colors="white")
    ax.yaxis.label.set_color("white"); ax.xaxis.label.set_color("white")
    ax.set_title("Bubble Count vs Confidence Threshold — BubMask",
                 color="white", fontsize=12, fontweight="bold")
    ax.scatter(img_stems, bubble_counts, color=COLOR, s=80, zorder=3)
    ax.plot(img_stems, bubble_counts, color=COLOR, alpha=0.5, lw=1.2)
    ax.set_ylabel("Bubble Count")
    ax.set_xticks(range(len(img_stems)))
    ax.set_xticklabels(img_stems, rotation=45, ha="right", fontsize=8)
    ax.grid(ls="--", alpha=0.3, color="#456")
    ax.text(0.98, 0.95, f"Confidence ≥ {bubmask_config.confidence_threshold}",
            transform=ax.transAxes, ha="right", va="top",
            color="yellow", fontsize=9)

    plt.tight_layout()
    pdf.savefig(fig, bbox_inches="tight", facecolor=BG)
    plt.close(fig)

    # ── Per-image annotated grid ──────────────────────────────────────────
    for img_path in image_paths:
        stem    = img_path.stem
        ann_bgr = cv2.imread(str(ANN_DIR / f"{stem}_bubmask.jpg"))
        ann_rgb = cv2.cvtColor(ann_bgr, cv2.COLOR_BGR2RGB)

        props_here = [p for p in all_props if p["image"] == stem]
        n          = len(props_here)
        dias_here  = [p["equivalent_diameter"] for p in props_here]
        ecc_here   = [p["eccentricity"]        for p in props_here]

        fig, axes = plt.subplots(1, 2, figsize=(14, 6), gridspec_kw={"width_ratios": [2, 1]})
        fig.patch.set_facecolor(BG)
        fig.suptitle(stem, color="white", fontsize=13, fontweight="bold")

        # Annotated image
        axes[0].imshow(ann_rgb); axes[0].axis("off")
        axes[0].set_title(f"BubMask — {n} bubbles detected",
                          color=COLOR, fontsize=10, pad=6)

        # Mini per-image histogram
        axes[1].set_facecolor(MID)
        for sp in axes[1].spines.values(): sp.set_color("#2a3e56")
        axes[1].tick_params(colors="white")
        axes[1].yaxis.label.set_color("white"); axes[1].xaxis.label.set_color("white")
        axes[1].set_title("Diameter distribution", color="white", fontsize=9)

        if dias_here:
            axes[1].hist(dias_here, bins=15, color=COLOR, edgecolor=BG, alpha=0.88)
            axes[1].axvline(np.mean(dias_here), color="yellow", lw=1.2, ls="--",
                            label=f"μ={np.mean(dias_here):.2f}")
            axes[1].legend(facecolor="#1E3A5F", labelcolor="white", fontsize=7)
        axes[1].set_xlabel("Equiv. Dia. (mm)", fontsize=8)
        axes[1].set_ylabel("Count", fontsize=8)
        axes[1].grid(axis="y", ls="--", alpha=0.3, color="#456")

        plt.tight_layout()
        pdf.savefig(fig, bbox_inches="tight", facecolor=BG)
        plt.close(fig)

    d = pdf.infodict()
    d["Title"]  = "Bubble Analyser 2.0 — BubMask Batch Report"
    d["Author"] = "bubble_analyser (github.com/dmesap/bubble_analyser)"

print(f"PDF saved → {pdf_path}")

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6 — Excel report
# ═══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("STEP 6 — Generating Excel report")
print("=" * 65)

xlsx_path = OUT_DIR / "BubMask_Analysis_Data.xlsx"

with pd.ExcelWriter(str(xlsx_path), engine="openpyxl") as writer:

    # Summary sheet
    rows = []
    for stem in img_stems:
        props_here = [p for p in all_props if p["image"] == stem]
        n          = len(props_here)
        rows.append({
            "Image":              stem,
            "Bubbles Detected":   n,
            "Mean Dia (mm)":      round(np.mean([p["equivalent_diameter"] for p in props_here]), 4) if n else 0,
            "Mean Ecc":           round(np.mean([p["eccentricity"]        for p in props_here]), 4) if n else 0,
            "Mean Major (mm)":    round(np.mean([p["major_axis_length"]   for p in props_here]), 4) if n else 0,
            "Mean Minor (mm)":    round(np.mean([p["minor_axis_length"]   for p in props_here]), 4) if n else 0,
            "Mean Area (mm²)":    round(np.mean([p["area"]                for p in props_here]), 4) if n else 0,
        })
    pd.DataFrame(rows).to_excel(writer, sheet_name="Summary", index=False)

    # All-bubbles detail sheet
    cols = ["image", "equivalent_diameter", "major_axis_length",
            "minor_axis_length", "area", "perimeter", "eccentricity"]
    df_all = pd.DataFrame(all_props)[cols]
    df_all.columns = ["Image", "Equiv. Diameter (mm)", "Major Axis (mm)",
                      "Minor Axis (mm)", "Area (mm²)", "Perimeter (mm)", "Eccentricity"]
    df_all.to_excel(writer, sheet_name="All Bubbles", index=False)

    # One sheet per image
    for stem in img_stems:
        props_here = [p for p in all_props if p["image"] == stem]
        if not props_here:
            continue
        df_img = pd.DataFrame(props_here)[cols]
        df_img.columns = ["Image", "Equiv. Diameter (mm)", "Major Axis (mm)",
                          "Minor Axis (mm)", "Area (mm²)", "Perimeter (mm)", "Eccentricity"]
        df_img.to_excel(writer, sheet_name=stem[-20:], index=False)

print(f"Excel saved → {xlsx_path}")

# ═══════════════════════════════════════════════════════════════════════════════
# FINAL SUMMARY
# ═══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("RESULTS SUMMARY — BubMask (Deep Learning)")
print("=" * 65)
print(f"  Images processed  : {len(image_paths)}")
print(f"  Total bubbles     : {sum(bubble_counts)}")
print(f"  Per-image average : {np.mean(bubble_counts):.1f}")
if all_props:
    dias = [p["equivalent_diameter"] for p in all_props]
    eccs = [p["eccentricity"]        for p in all_props]
    print(f"  Mean dia (mm)     : {np.mean(dias):.4f}")
    print(f"  Dia range (mm)    : {min(dias):.4f}  –  {max(dias):.4f}")
    print(f"  Mean eccentricity : {np.mean(eccs):.4f}")
print(f"\n  PDF  → {pdf_path}")
print(f"  Excel → {xlsx_path}")
print(f"  Annotated images → {ANN_DIR}")
print("=" * 65 + "\n")
