#!/usr/bin/env python3
"""
multi_bubble_analysis.py v2 — Analyze the multi-bubble high-resolution images.
Filters artifacts: ignores components > 400 px equivalent diameter (likely merged blobs)
and < 5 px (noise).
"""
import os
import json
import numpy as np
from PIL import Image
from scipy import ndimage
from scipy.spatial import KDTree
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

for f in [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf",
]:
    if os.path.exists(f):
        fm.fontManager.addfont(f)

plt.rcParams["font.family"] = "Liberation Serif"
plt.rcParams["font.serif"] = ["Liberation Serif", "DejaVu Serif"]
plt.rcParams["font.size"] = 10
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False

INK = "#000000"
GREY1 = "#444444"
GREY2 = "#888888"
GREY3 = "#BBBBBB"
ACCENT = "#1F4E79"
ACCENT_LIGHT = "#5B8DB8"
HIGHLIGHT = "#B22222"

IMG_DIR = "/home/z/my-project/upload"
OUT_DIR = "/home/z/my-project/scripts/figures"
os.makedirs(OUT_DIR, exist_ok=True)

# Per Batjargal et al. 2025: PPG600 SMD = 310 µm at J_g = 0.02 m/s
# This implies that for the high-res images (showing the same bubble population),
# we calibrate by setting: SMD(IMG_PPG600) ≈ 310 µm
# IMG_9423 (no info on which frother — but let's compute the actual scale from data)
# Tentative calibration: ~3 µm/px based on assumption that ~100 px bubbles ≈ 300 µm
CALIBRATION_UM_PER_PX = 3.0  # µm per pixel (rounded)

# Size filter: keep bubbles with equivalent diameter in [10, 400] px
MIN_DIAM_PX = 10
MAX_DIAM_PX = 400


def extract_bubbles_from_labels(label_array):
    """Extract bubbles from a labeled integer array. Each unique nonzero value = one bubble."""
    unique_labels = np.unique(label_array)
    unique_labels = unique_labels[unique_labels > 0]
    bubbles = []
    for label in unique_labels:
        binary = (label_array == label)
        area_px = int(binary.sum())
        if area_px < 5:  # noise threshold
            continue
        eq_diam_px = 2 * np.sqrt(area_px / np.pi)
        if eq_diam_px < MIN_DIAM_PX or eq_diam_px > MAX_DIAM_PX:
            continue  # filter artifacts
        ys, xs = np.where(binary)
        cx = float(np.mean(xs))
        cy = float(np.mean(ys))
        x0, x1 = xs.min(), xs.max()
        y0, y1 = ys.min(), ys.max()
        bw = x1 - x0 + 1
        bh = y1 - y0 + 1
        aspect = max(bw, bh) / max(1, min(bw, bh))
        bubbles.append({
            "id": int(label),
            "area_px": area_px,
            "eq_diam_px": float(eq_diam_px),
            "centroid_x_px": cx,
            "centroid_y_px": cy,
            "bbox": (int(x0), int(y0), int(x1), int(y1)),
            "bbox_width_px": int(bw),
            "bbox_height_px": int(bh),
            "aspect_ratio": float(aspect),
        })
    return bubbles


def compute_bsd_stats(eq_diams):
    if len(eq_diams) == 0:
        return {}
    d = np.array(eq_diams)
    smd = float(np.sum(d**3) / np.sum(d**2))
    return {
        "n_bubbles": int(len(d)),
        "mean_px": float(d.mean()),
        "std_px": float(d.std()),
        "median_px": float(np.median(d)),
        "min_px": float(d.min()),
        "max_px": float(d.max()),
        "d10_px": float(np.percentile(d, 10)),
        "d50_px": float(np.percentile(d, 50)),
        "d90_px": float(np.percentile(d, 90)),
        "smd_px": smd,
        "cv_pct": float(d.std() / d.mean() * 100),
    }


def regenerate_mask_from_rgb(rgb_path):
    """Re-segment an RGB image to produce a labeled mask, for IMG_9431 which has no mask file."""
    rgb_gray = np.array(Image.open(rgb_path).convert("L"))
    # Otsu threshold
    try:
        from skimage.filters import threshold_otsu
        thresh = threshold_otsu(rgb_gray)
    except ImportError:
        thresh = np.median(rgb_gray) * 0.9
    # Bubbles typically appear as dark regions on lighter background
    binary = rgb_gray < thresh
    # Clean with morphological opening
    struct = ndimage.generate_binary_structure(2, 2)
    binary = ndimage.binary_opening(binary, structure=struct, iterations=1)
    binary = ndimage.binary_fill_holes(binary)
    # Label
    labels, n = ndimage.label(binary)
    return labels.astype(np.uint16)


# ============================================================
# Run analysis on all multi-bubble images
# ============================================================
all_results = {}
all_bubbles_per_image = {}

for img_id in ["IMG_9423", "IMG_9431", "IMG_9432", "IMG_9433"]:
    print(f"\n{'='*70}")
    print(f"Multi-bubble analysis: {img_id}")
    print(f"{'='*70}")
    mask_path = os.path.join(IMG_DIR, f"{img_id}_mask.png")
    rgb_path = os.path.join(IMG_DIR, f"{img_id}_rgb.png")

    if os.path.exists(mask_path):
        mask = np.array(Image.open(mask_path).convert("L"))
        shape = mask.shape
        labels = mask.astype(np.int32)
        print(f"  Using existing mask file: {mask_path}")
        # Mask values are bubble IDs (1, 2, 3, ...)
        # Quick count of unique labels before filtering
        unique_labels = np.unique(labels)
        unique_labels = unique_labels[unique_labels > 0]
        print(f"  Raw labels in mask: {len(unique_labels)} (max label ID = {unique_labels.max() if len(unique_labels)>0 else 0})")
        # Total area before filter
        total_area_raw = int((labels > 0).sum())
        print(f"  Total mask area: {total_area_raw:,} px ({100*total_area_raw/labels.size:.1f}% of image)")
    else:
        # Regenerate from RGB
        labels = regenerate_mask_from_rgb(rgb_path)
        shape = labels.shape
        print(f"  Regenerated mask from RGB (no mask file provided)")
        unique_labels = np.unique(labels)
        unique_labels = unique_labels[unique_labels > 0]
        print(f"  Regenerated labels: {len(unique_labels)} (max label ID = {unique_labels.max() if len(unique_labels)>0 else 0})")

    bubbles = extract_bubbles_from_labels(labels)
    stats = compute_bsd_stats([b["eq_diam_px"] for b in bubbles])
    # Add calibration-based values
    if stats:
        for k in list(stats.keys()):
            if k.endswith("_px"):
                um_key = k.replace("_px", "_um")
                stats[um_key] = stats[k] * CALIBRATION_UM_PER_PX
    stats["image_width_px"] = shape[1]
    stats["image_height_px"] = shape[0]
    stats["image_area_px2"] = shape[0] * shape[1]
    stats["bubble_number_density_per_px2"] = stats.get("n_bubbles", 0) / stats["image_area_px2"]
    px_per_cm2 = 1e8 / (CALIBRATION_UM_PER_PX ** 2)
    stats["bubble_number_density_per_cm2"] = stats.get("n_bubbles", 0) / stats["image_area_px2"] * px_per_cm2
    stats["calibration_um_per_px"] = CALIBRATION_UM_PER_PX
    if bubbles:
        total_bubble_area_px2 = sum(b["area_px"] for b in bubbles)
        stats["total_bubble_area_px2"] = total_bubble_area_px2
        stats["bubble_area_fraction"] = total_bubble_area_px2 / stats["image_area_px2"]
        total_bubble_surface_px2 = sum(np.pi * (b["eq_diam_px"] / 2) ** 2 for b in bubbles)
        stats["total_bubble_surface_px2"] = total_bubble_surface_px2

    all_results[img_id] = stats
    all_bubbles_per_image[img_id] = bubbles

    print(f"  Image: {shape[1]} × {shape[0]} px = {stats['image_area_px2']:,} px²")
    print(f"  Bubbles after filtering ({MIN_DIAM_PX}-{MAX_DIAM_PX} px eq diam): {stats.get('n_bubbles', 0)}")
    print(f"  Bubble area fraction: {stats.get('bubble_area_fraction', 0)*100:.2f}% of image")
    print(f"  Bubble number density: {stats.get('bubble_number_density_per_cm2', 0):.1f} bubbles/cm²")
    if bubbles:
        print(f"  Equivalent diameter stats:")
        print(f"    Mean: {stats['mean_px']:.2f} ± {stats['std_px']:.2f} px = {stats['mean_um']:.1f} ± {stats['std_um']:.1f} µm")
        print(f"    SMD (Sauter): {stats['smd_px']:.2f} px = {stats['smd_um']:.1f} µm")
        print(f"    Median (d50): {stats['d50_px']:.2f} px = {stats['d50_um']:.1f} µm")
        print(f"    d10: {stats['d10_px']:.2f} px = {stats['d10_um']:.1f} µm")
        print(f"    d90: {stats['d90_px']:.2f} px = {stats['d90_um']:.1f} µm")
        print(f"    Range: {stats['min_px']:.2f} - {stats['max_px']:.2f} px = {stats['min_um']:.1f} - {stats['max_um']:.1f} µm")
        print(f"    CV: {stats['cv_pct']:.2f}%")

with open("/home/z/my-project/scripts/multi_bubble_stats.json", "w") as f:
    json.dump(all_results, f, indent=2)
print(f"\nSaved: /home/z/my-project/scripts/multi_bubble_stats.json")


# ============================================================
# CROSS-IMAGE BUBBLE VELOCITY (using bubble position matching)
# ============================================================
print(f"\n{'='*70}")
print(f"Cross-image bubble velocity estimation")
print(f"{'='*70}")
print(f"Assumption: IMG_9423 → IMG_9431 → IMG_9432 → IMG_9433 are sequential captures")
print(f"(file numbering suggests acquisition order; frame rate unknown)")


def match_bubbles(bubbles_a, bubbles_b, max_dist_px=80, max_diam_ratio=2.0):
    if not bubbles_a or not bubbles_b:
        return []
    pos_a = np.array([[b["centroid_x_px"], b["centroid_y_px"]] for b in bubbles_a])
    pos_b = np.array([[b["centroid_x_px"], b["centroid_y_px"]] for b in bubbles_b])
    diam_a = np.array([b["eq_diam_px"] for b in bubbles_a])
    diam_b = np.array([b["eq_diam_px"] for b in bubbles_b])
    tree_b = KDTree(pos_b)
    distances, indices = tree_b.query(pos_a, k=1)
    matches = []
    for i, (dist, j) in enumerate(zip(distances, indices)):
        if dist > max_dist_px:
            continue
        da = diam_a[i]
        db = diam_b[j]
        if min(da, db) == 0:
            continue
        ratio = max(da, db) / min(da, db)
        if ratio > max_diam_ratio:
            continue
        matches.append({
            "a_id": int(bubbles_a[i]["id"]),
            "b_id": int(bubbles_b[j]["id"]),
            "centroid_a": [float(pos_a[i, 0]), float(pos_a[i, 1])],
            "centroid_b": [float(pos_b[j, 0]), float(pos_b[j, 1])],
            "displacement_px": float(dist),
            "diam_a_px": float(da),
            "diam_b_px": float(db),
            "diam_ratio": float(ratio),
            "dx_px": float(pos_b[j, 0] - pos_a[i, 0]),
            "dy_px": float(pos_b[j, 1] - pos_a[i, 1]),  # image coords, positive = downward
            "rise_px": float(pos_a[i, 1] - pos_b[j, 1]),  # negative dy = rise
        })
    return matches


image_ids = list(all_bubbles_per_image.keys())
velocity_results = {}
for i in range(len(image_ids) - 1):
    a_id = image_ids[i]
    b_id = image_ids[i + 1]
    matches = match_bubbles(all_bubbles_per_image[a_id], all_bubbles_per_image[b_id])
    print(f"\n  {a_id} → {b_id}: {len(matches)} matched bubble pairs")
    if matches:
        displacements = np.array([m["displacement_px"] for m in matches])
        rises = np.array([m["rise_px"] for m in matches])
        dxs = np.array([m["dx_px"] for m in matches])
        # Filter outliers: keep matches with displacement < 80 px
        mask = displacements < 80
        if mask.sum() > 0:
            valid_disps = displacements[mask]
            valid_rises = rises[mask]
            valid_dxs = dxs[mask]
            print(f"    Displacement (n={int(mask.sum())} of {len(matches)}):")
            print(f"      Mean = {valid_disps.mean():.2f} ± {valid_disps.std():.2f} px")
            print(f"      Horizontal dx: mean = {valid_dxs.mean():+.2f} ± {valid_dxs.std():.2f} px")
            print(f"      Vertical rise: mean = {valid_rises.mean():+.2f} ± {valid_rises.std():.2f} px")
            print(f"      In µm (× {CALIBRATION_UM_PER_PX} µm/px):")
            print(f"        Displacement = {valid_disps.mean() * CALIBRATION_UM_PER_PX:.1f} µm/frame")
            print(f"        Rise = {valid_rises.mean() * CALIBRATION_UM_PER_PX:+.1f} µm/frame")
            velocity_results[f"{a_id}_to_{b_id}"] = {
                "n_matched": int(mask.sum()),
                "n_total_matches": int(len(matches)),
                "mean_displacement_px": float(valid_disps.mean()),
                "std_displacement_px": float(valid_disps.std()),
                "mean_dx_px": float(valid_dxs.mean()),
                "std_dx_px": float(valid_dxs.std()),
                "mean_rise_px": float(valid_rises.mean()),
                "std_rise_px": float(valid_rises.std()),
                "mean_displacement_um": float(valid_disps.mean() * CALIBRATION_UM_PER_PX),
                "mean_rise_um": float(valid_rises.mean() * CALIBRATION_UM_PER_PX),
            }

with open("/home/z/my-project/scripts/multi_bubble_velocity.json", "w") as f:
    json.dump(velocity_results, f, indent=2)
print(f"\nSaved: /home/z/my-project/scripts/multi_bubble_velocity.json")
