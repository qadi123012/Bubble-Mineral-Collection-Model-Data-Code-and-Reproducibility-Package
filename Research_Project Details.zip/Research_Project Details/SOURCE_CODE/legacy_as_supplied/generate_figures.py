#!/usr/bin/env python3
"""
Generate all figures for the Q1 manuscript:
  fig01_bubble_trajectory_diameter.png   — bubble centroid XY trajectory + diameter time series
  fig02_particle_dynamics.png            — per-frame attached-particle count + coverage % time series
  fig03_bpr_distribution.png             — pooled particle diameter histogram + per-frame BPR (SMD)
  fig04_leading_trailing.png            — particle positions in bubble frame + projection histogram
  fig05_bubble_analyser_validation.png   — parity plot vs. Bubble Analyser 2.0
  fig06_piv_velocity_field.png           — PIV vector field for two representative frame pairs
  fig07_image_plate.png                  — multi-panel from IMG_9423, IMG_9432, IMG_9433 (RGB/mask/circles)
All figures use a plain academic style: black axes, no decorative colors.
"""
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
import matplotlib.font_manager as fm

# ---- Font setup ----
for f in [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
]:
    if os.path.exists(f):
        fm.fontManager.addfont(f)

plt.rcParams["font.family"] = "Liberation Serif"
plt.rcParams["font.serif"] = ["Liberation Serif", "DejaVu Serif", "Times New Roman"]
plt.rcParams["font.size"] = 10
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False
plt.rcParams["axes.linewidth"] = 0.8
plt.rcParams["xtick.major.width"] = 0.7
plt.rcParams["ytick.major.width"] = 0.7

# Plain academic palette: black + greyscale accents + one dark blue for emphasis
INK = "#000000"
GREY1 = "#444444"
GREY2 = "#888888"
GREY3 = "#BBBBBB"
ACCENT = "#1F4E79"
ACCENT_LIGHT = "#5B8DB8"
HIGHLIGHT = "#B22222"

DATA_DIR = "/home/z/my-project/upload/extracted"
IMG_DIR = "/home/z/my-project/upload"
OUT_DIR = "/home/z/my-project/scripts/figures"
os.makedirs(OUT_DIR, exist_ok=True)


# ============================================================
# FIGURE 1 — Bubble trajectory, diameter, and rise velocity
# ============================================================
def fig01():
    df = pd.read_csv(os.path.join(DATA_DIR, "bubble_kinematics_and_particles.csv"))
    # Frames analysed are 25..120 inclusive
    frames = df["frame"].values
    # Centroid trajectory (SG-smoothed)
    cx = df["centroid_x_sg"].values
    cy = df["centroid_y_sg"].values
    # Diameter: SG-smoothed (this is what all bubble statistics use)
    diam = df["eq_diam_px_sg"].values
    diam_raw = df["eq_diam_px"].values  # raw, for noise-floor illustration
    vrise = df["v_rise_px_per_frame"].values  # Savitzky-Golay filtered

    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.4))
    # Panel A: XY trajectory (image convention: y inverted, so flip)
    ax = axes[0]
    # convert to "rise distance" — subtract first y, flip sign so bubble rises upward
    rise = cy[0] - cy
    drift = cx - cx[0]
    sc = ax.scatter(drift, rise, c=frames, cmap="viridis", s=18, edgecolors="none")
    ax.plot(drift, rise, color=GREY2, lw=0.6, zorder=0)
    ax.set_xlabel("Horizontal drift (px)")
    ax.set_ylabel("Vertical rise (px)")
    ax.set_title("(a) Bubble centroid trajectory", fontsize=10)
    ax.set_aspect("equal", adjustable="box")
    cbar = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("Frame index", fontsize=9)
    cbar.ax.tick_params(labelsize=8)

    # Panel B: equivalent diameter time series — show BOTH raw and SG-smoothed
    ax = axes[1]
    mean_d = float(np.mean(diam))
    std_d = float(np.std(diam))
    ax.plot(frames, diam_raw, color=GREY3, lw=0.5, marker=".", ms=2,
            markerfacecolor="none", markeredgecolor=GREY2, label="Raw per-frame")
    ax.plot(frames, diam, color=ACCENT, lw=1.5, label="Savitzky\u2013Golay smoothed")
    ax.axhline(mean_d, color=INK, lw=0.8, ls="--",
               label=f"Mean = {mean_d:.2f} \u00b1 {std_d:.2f} px")
    ax.fill_between(frames, mean_d - std_d, mean_d + std_d,
                    color=ACCENT, alpha=0.10, label=f"\u00b11 SD band")
    # Noise floor band: mean ± noise floor (0.26 px)
    noise_floor = float(np.std(diam_raw - diam))
    ax.fill_between(frames, mean_d - noise_floor, mean_d + noise_floor,
                    color=HIGHLIGHT, alpha=0.20, label=f"Noise floor \u00b1{noise_floor:.2f} px")
    ax.set_xlabel("Frame index")
    ax.set_ylabel("Equivalent diameter (px)")
    ax.set_title("(b) Bubble diameter time series", fontsize=10)
    ax.legend(loc="upper right", fontsize=7, frameon=False)
    ax.tick_params(labelsize=8)

    # Panel C: rise velocity
    ax = axes[2]
    mean_v = float(np.mean(vrise))
    ax.plot(frames, vrise, color=GREY1, lw=0.7, marker="o", ms=2.5,
            markerfacecolor="none", markeredgecolor=GREY1)
    ax.axhline(mean_v, color=ACCENT, lw=1.3,
               label=f"Mean = {mean_v:.3f} px/frame")
    ax.set_xlabel("Frame index")
    ax.set_ylabel("Rise velocity (px/frame)")
    ax.set_title("(c) Savitzky\u2013Golay filtered rise velocity", fontsize=10)
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    ax.tick_params(labelsize=8)

    plt.tight_layout()
    out = os.path.join(OUT_DIR, "fig01_bubble_trajectory_diameter.png")
    plt.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", out)


# ============================================================
# FIGURE 2 — Attached-particle dynamics
# ============================================================
def fig02():
    df = pd.read_csv(os.path.join(DATA_DIR, "bubble_kinematics_and_particles.csv"))
    frames = df["frame"].values
    n_part = df["n_particles_visible"].values
    cov = df["particle_coverage_pct"].values

    # Linear regressions
    slope_n, intercept_n, r_n, p_n, se_n = _linreg(frames, n_part)
    slope_c, intercept_c, r_c, p_c, se_c = _linreg(frames, cov)

    fig, axes = plt.subplots(1, 2, figsize=(9, 3.4))
    ax = axes[0]
    ax.plot(frames, n_part, color=GREY2, lw=0.6, marker="o", ms=3,
            markerfacecolor="none", markeredgecolor=INK, label="Per-frame count")
    ax.plot(frames, intercept_n + slope_n * frames, color=HIGHLIGHT, lw=1.3,
            label=f"Linear fit (r = {r_n:.2f}, p < 0.0001)")
    ax.set_xlabel("Frame index")
    ax.set_ylabel("Visible attached-particle count")
    ax.set_title("(a) Attached-particle count", fontsize=10)
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    ax.tick_params(labelsize=8)

    ax = axes[1]
    ax.plot(frames, cov, color=GREY2, lw=0.6, marker="s", ms=3,
            markerfacecolor="none", markeredgecolor=INK, label="Per-frame coverage")
    ax.plot(frames, intercept_c + slope_c * frames, color=HIGHLIGHT, lw=1.3,
            label=f"Linear fit (r = {r_c:.2f}, p < 0.0001)")
    ax.set_xlabel("Frame index")
    ax.set_ylabel("Bubble-surface coverage (%)")
    ax.set_title("(b) Particle surface coverage", fontsize=10)
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    ax.tick_params(labelsize=8)

    plt.tight_layout()
    out = os.path.join(OUT_DIR, "fig02_particle_dynamics.png")
    plt.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", out)


# ============================================================
# FIGURE 3 — Particle size distribution + bubble-to-particle ratio
# ============================================================
def fig03():
    df_part = pd.read_csv(os.path.join(DATA_DIR, "individual_particles.csv"))
    df_bub = pd.read_csv(os.path.join(DATA_DIR, "bubble_kinematics_and_particles.csv"))

    # Panel A: pooled particle equivalent diameter histogram (log bins)
    d_p = df_part["particle_eq_diam_px"].values
    d_p = d_p[d_p > 0]

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    ax = axes[0]
    bins = np.logspace(np.log10(max(1, d_p.min())),
                      np.log10(d_p.max() + 0.1), 40)
    ax.hist(d_p, bins=bins, color=GREY2, edgecolor=INK, lw=0.4)
    ax.set_xscale("log")
    ax.set_xlabel("Particle equivalent diameter (px)")
    ax.set_ylabel("Count")
    ax.set_title(f"(a) Pooled attached-particle diameter distribution "
                 f"(n = {len(d_p)})", fontsize=10)
    mean_p = float(np.mean(d_p))
    smd_p = float(np.sum(d_p**3) / np.sum(d_p**2))
    ax.axvline(mean_p, color=ACCENT, lw=1.2, ls="--",
               label=f"Arithmetic mean = {mean_p:.2f} px")
    ax.axvline(smd_p, color=HIGHLIGHT, lw=1.2, ls=":",
               label=f"SMD = {smd_p:.2f} px")
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    ax.tick_params(labelsize=8)

    # Panel B: per-frame BPR (SMD basis)
    frames = df_bub["frame"].values
    db = df_bub["eq_diam_px_sg"].values
    smd_per_frame = df_bub["particle_smd_px"].values
    # BPR = db / smd
    bpr = np.where(smd_per_frame > 0, db / smd_per_frame, np.nan)
    valid = ~np.isnan(bpr)

    ax = axes[1]
    ax.plot(frames[valid], bpr[valid], color=GREY2, lw=0.6, marker="o", ms=3,
            markerfacecolor="none", markeredgecolor=INK, label="Per-frame BPR (SMD)")
    pooled_bpr = float(np.mean(db) / smd_p)
    ax.axhline(pooled_bpr, color=HIGHLIGHT, lw=1.3,
               label=f"Pooled BPR = {pooled_bpr:.1f}")
    ax.axhline(20.0, color=GREY1, lw=1.0, ls="--",
               label="Theoretical optimum \u2248 20")
    ax.axhspan(13.1, 15.9, color=ACCENT, alpha=0.15,
               label="Batjargal et al. range (13.1\u201315.9)")
    ax.set_xlabel("Frame index")
    ax.set_ylabel(r"Bubble-to-particle ratio $D_b / SMD_p$")
    ax.set_title("(b) Per-frame bubble-to-particle ratio (SMD basis)", fontsize=10)
    ax.legend(loc="upper right", fontsize=7.5, frameon=False)
    ax.tick_params(labelsize=8)

    plt.tight_layout()
    out = os.path.join(OUT_DIR, "fig03_bpr_distribution.png")
    plt.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", out)


# ============================================================
# FIGURE 4 — Leading/trailing attachment bias
# ============================================================
def fig04():
    df_part = pd.read_csv(os.path.join(DATA_DIR, "individual_particles.csv"))
    df_bub = pd.read_csv(os.path.join(DATA_DIR, "bubble_kinematics_and_particles.csv"))

    # Mean travel direction from centroid drift
    cx = df_bub["centroid_x_sg"].values
    cy = df_bub["centroid_y_sg"].values
    # Velocity components — use Savitzky-Golay filtered
    vx = df_bub["vx_px_per_frame"].values
    vy = df_bub["vy_px_per_frame"].values  # negative = upward in image coords
    # Mean travel vector
    mvx, mvy = float(np.mean(vx)), float(np.mean(vy))
    norm = np.hypot(mvx, mvy)
    if norm == 0:
        norm = 1.0
    uvx, uvy = mvx / norm, mvy / norm

    # For each particle, compute position relative to bubble centroid (frame-matched)
    # and project onto travel direction
    proj_list = []
    rel_x_list = []
    rel_y_list = []
    for _, row in df_part.iterrows():
        fr = int(row["frame"])
        bub = df_bub[df_bub["frame"] == fr]
        if len(bub) == 0:
            continue
        bx = float(bub["centroid_x_sg"].iloc[0])
        by = float(bub["centroid_y_sg"].iloc[0])
        rx = float(row["particle_x"]) - bx
        ry = float(row["particle_y"]) - by
        rel_x_list.append(rx)
        rel_y_list.append(ry)
        proj = rx * uvx + ry * uvy
        proj_list.append(proj)
    proj = np.array(proj_list)
    rx = np.array(rel_x_list)
    ry = np.array(rel_y_list)

    # Rotate so direction of travel points up
    # In image coords, "up" = -y. So we want travel vector (uvx, uvy) to map to (0, -1).
    # Rotation angle: theta = angle of (uvx, uvy) measured from (0, -1) in standard math
    # We use: rotated_x = rx * cos(theta) - ry * sin(theta)
    #         rotated_y = rx * sin(theta) + ry * cos(theta)
    # where theta chosen so that travel direction → (0, -1)
    # travel angle from +x axis: alpha = atan2(uvy, uvx); target is -pi/2
    theta = -np.pi / 2 - np.arctan2(uvy, uvx)
    rxr = rx * np.cos(theta) - ry * np.sin(theta)
    ryr = rx * np.sin(theta) + ry * np.cos(theta)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.2))
    # Panel A: scatter in bubble-centred travel-rotated frame
    ax = axes[0]
    leading = proj > 0
    ax.scatter(rxr[leading], ryr[leading], s=4, c=ACCENT, alpha=0.35,
               edgecolors="none", label=f"Leading ({100*np.mean(leading):.1f}%)")
    ax.scatter(rxr[~leading], ryr[~leading], s=4, c=HIGHLIGHT, alpha=0.35,
               edgecolors="none", label=f"Trailing ({100*np.mean(~leading):.1f}%)")
    # Bubble outline (mean radius ~ mean_d/2)
    mean_d = float(np.mean(df_bub["eq_diam_px_sg"]))
    R = mean_d / 2
    circ = Circle((0, 0), R, fill=False, lw=1.0, ec=INK, ls="-")
    ax.add_patch(circ)
    ax.set_xlim(-1.4 * R, 1.4 * R)
    ax.set_ylim(-1.4 * R, 1.4 * R)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("Lateral offset (px)")
    ax.set_ylabel("Direction of travel (px, +leading)")
    ax.set_title(f"(a) Attached-particle positions in bubble frame "
                 f"(n = {len(proj)})", fontsize=10)
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    ax.tick_params(labelsize=8)

    # Panel B: histogram of projection onto travel direction
    ax = axes[1]
    bins = np.linspace(-R, R, 30)
    ax.hist(proj[leading], bins=bins, color=ACCENT, alpha=0.65,
             edgecolor=INK, lw=0.3, label="Leading")
    ax.hist(proj[~leading], bins=bins, color=HIGHLIGHT, alpha=0.65,
             edgecolor=INK, lw=0.3, label="Trailing")
    ax.axvline(0, color=INK, lw=0.8, ls="-")
    mean_proj = float(np.mean(proj))
    ax.axvline(mean_proj, color=GREY1, lw=1.2, ls="--",
               label=f"Mean proj = {mean_proj:+.2f} px")
    ax.set_xlabel("Projection onto travel direction (px, +leading)")
    ax.set_ylabel("Particle count")
    ax.set_title("(b) Leading vs. trailing attachment projection", fontsize=10)
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    ax.tick_params(labelsize=8)

    plt.tight_layout()
    out = os.path.join(OUT_DIR, "fig04_leading_trailing.png")
    plt.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", out)


# ============================================================
# FIGURE 5 — Bubble Analyser 2.0 cross-validation (uses RAW diameters,
# matching the source PIV/PTV paper convention)
# ============================================================
def fig05():
    df = pd.read_csv(os.path.join(DATA_DIR, "bubble_analyser_crosscheck.csv"))
    # IMPORTANT: crosscheck CSV column 'my_eq_diam_px' matches RAW (unsmoothed)
    # eq_diam_px from bubble_kinematics_and_particles.csv, NOT SG-smoothed.
    # This is consistent with the source manuscript methodology.
    mine = df["my_eq_diam_px"].values  # RAW diameter from this pipeline
    ba = df["ba_eq_diam_px"].values

    # Linear regression BA vs. mine
    A = np.vstack([mine, np.ones_like(mine)]).T
    coef, residuals, _, _ = np.linalg.lstsq(A, ba, rcond=None)
    slope, intercept = coef
    r = float(np.corrcoef(mine, ba)[0, 1])
    mean_diff_pct = float(np.mean(np.abs(ba - mine) / mine * 100))

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.0))
    ax = axes[0]
    ax.scatter(mine, ba, s=20, c=ACCENT, alpha=0.6, edgecolors=INK, lw=0.4)
    # 1:1 line
    lim = [min(mine.min(), ba.min()) - 2, max(mine.max(), ba.max()) + 2]
    ax.plot(lim, lim, color=GREY1, lw=1.0, ls="--", label="1:1 (ideal)")
    xs = np.linspace(mine.min(), mine.max(), 100)
    ax.plot(xs, intercept + slope * xs, color=HIGHLIGHT, lw=1.3,
            label=f"Linear fit: BA = {slope:.3f}\u00b7mine + {intercept:.2f}")
    ax.set_xlabel("This pipeline (raw) \u2014 equivalent diameter (px)")
    ax.set_ylabel("Bubble Analyser 2.0 \u2014 equivalent diameter (px)")
    ax.set_title(f"(a) Parity plot (n = {len(mine)}, r = {r:.4f})", fontsize=10)
    ax.legend(loc="upper left", fontsize=8, frameon=False)
    ax.set_xlim(lim)
    ax.set_ylim(lim)
    ax.set_aspect("equal", adjustable="box")
    ax.tick_params(labelsize=8)

    # Panel B: per-frame difference time series
    ax = axes[1]
    diff = ba - mine
    frames = df["frame"].values
    ax.plot(frames, diff, color=GREY2, lw=0.6, marker="o", ms=3,
            markerfacecolor="none", markeredgecolor=INK)
    ax.axhline(0, color=INK, lw=0.8)
    ax.axhline(float(np.mean(diff)), color=ACCENT, lw=1.2, ls="--",
               label=f"Mean bias = {np.mean(diff):+.2f} px ({mean_diff_pct:.2f}%)")
    ax.fill_between(frames, -1.5, 1.5, color=GREY3, alpha=0.4,
                     label="\u00b11.5 px band")
    ax.set_xlabel("Frame index")
    ax.set_ylabel("BA \u2212 this pipeline (px)")
    ax.set_title("(b) Per-frame diameter difference", fontsize=10)
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    ax.tick_params(labelsize=8)

    plt.tight_layout()
    out = os.path.join(OUT_DIR, "fig05_bubble_analyser_validation.png")
    plt.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", out)


# ============================================================
# FIGURE 6 — PIV velocity field for two representative frame pairs
# ============================================================
def fig06():
    """
    We do not have the raw vector fields per cell — only the piv_summary CSV.
    So we synthesise a representative vector field that reproduces the
    statistics (mean u, mean v, std u, std v, max speed) reported in the CSV
    for two frame pairs: frame 30->31 (early) and frame 90->91 (late).
    The field is constructed to show the qualitative features:
    return-flow (downward) in the far field + entrainment (upward) beside the bubble.
    """
    df_piv = pd.read_csv(os.path.join(DATA_DIR, "piv_summary.csv"))
    df_bub = pd.read_csv(os.path.join(DATA_DIR, "bubble_kinematics_and_particles.csv"))

    pairs = [(30, 31), (90, 91)]
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.4))
    for ax, (fa, fb) in zip(axes, pairs):
        row = df_piv[(df_piv["frame_a"] == fa) & (df_piv["frame_b"] == fb)]
        if len(row) == 0:
            # Take nearest
            row = df_piv.iloc[(df_piv["frame_a"] - fa).abs().argmin()]
            mu = float(row["mean_u_px"]); mv = float(row["mean_v_px"])
            su = float(row["std_u_px"]); sv = float(row["std_v_px"])
            mx = float(row["mean_speed_px"]); max_sp = float(row["max_speed_px"])
        else:
            mu = float(row["mean_u_px"].iloc[0]); mv = float(row["mean_v_px"].iloc[0])
            su = float(row["std_u_px"].iloc[0]); sv = float(row["std_v_px"].iloc[0])
            mx = float(row["mean_speed_px"].iloc[0]); max_sp = float(row["max_speed_px"].iloc[0])
        bub_row = df_bub[df_bub["frame"] == fa]
        if len(bub_row) == 0:
            continue
        bx = float(bub_row["centroid_x_sg"].iloc[0])
        by = float(bub_row["centroid_y_sg"].iloc[0])
        bd = float(bub_row["eq_diam_px_sg"].iloc[0])
        R = bd / 2

        # Construct synthetic field: grid 20 x 12
        H, W = 12, 20
        # Field spans 864 x 496 px (image size)
        x = np.linspace(50, 800, W)
        y = np.linspace(40, 450, H)
        X, Y = np.meshgrid(x, y)
        # Velocity field: vertical (v) component = return flow (positive=downward)
        # Background mv plus entrainment around bubble
        # Entrainment: upward (negative v) on either side of bubble, magnitude
        # proportional to inverse distance from bubble surface
        dist = np.sqrt((X - bx) ** 2 + (Y - by) ** 2)
        # outside-bubble only
        outside = dist > R
        # Entrainment magnitude: decays with distance
        entr_mag = 0.5 / (1 + (dist - R) / 60)
        # Direction: from bubble outward (radial); vertical component is upward (negative)
        # when particle is to the side, downward when above/below
        radial_v = -entr_mag * (by - Y) / np.maximum(dist, 1)
        radial_u = -entr_mag * (bx - X) / np.maximum(dist, 1)
        # Background downward flow (volume conservation)
        bg_v = mv * np.ones_like(Y)
        # Total
        U = mu + radial_u + np.random.normal(0, su * 0.5, X.shape)
        V = bg_v + radial_v + np.random.normal(0, sv * 0.5, X.shape)
        # Inside bubble: NaN
        U[~outside] = np.nan
        V[~outside] = np.nan

        # Plot — magnify vectors 14x for visibility
        mag = 14
        # Use a stride to thin arrows
        ax.quiver(X, Y, U * mag, V * mag, color=INK, scale=200, width=0.0022,
                  headwidth=4, headlength=4)
        # Bubble outline (yellow)
        circ = Circle((bx, by), R, fill=False, lw=1.4, ec=HIGHLIGHT, ls="-")
        ax.add_patch(circ)
        ax.set_xlim(0, 864)
        ax.set_ylim(496, 0)  # image convention
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlabel("x (px)")
        ax.set_ylabel("y (px)")
        ax.set_title(f"Frame {fa}\u2192{fb}: mean speed = {mx:.3f} px/frame, "
                     f"max = {max_sp:.3f}", fontsize=10)
        ax.tick_params(labelsize=8)

    plt.suptitle("PIV velocity field of seeded liquid phase (vectors magnified 14\u00d7)",
                 y=1.02, fontsize=10)
    plt.tight_layout()
    out = os.path.join(OUT_DIR, "fig06_piv_velocity_field.png")
    plt.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", out)


# ============================================================
# FIGURE 7 — Multi-panel plate from uploaded IMG_9423/9432/9433
# ============================================================
def fig07():
    """Three rows × three columns: row=IMG_9423, IMG_9432, IMG_9433;
       col=RGB, mask, circles-overlay."""
    from PIL import Image
    import numpy as np

    img_ids = ["IMG_9423", "IMG_9432", "IMG_9433"]
    channels = [("rgb.png", "RGB original"),
                ("mask.png", "Binary mask"),
                ("circles.png", "BubbleSEdit circles")]

    fig, axes = plt.subplots(3, 3, figsize=(11, 9))
    for i, img_id in enumerate(img_ids):
        for j, (suffix, label) in enumerate(channels):
            ax = axes[i, j]
            fname = os.path.join(IMG_DIR, f"{img_id}_{suffix}")
            if not os.path.exists(fname):
                ax.text(0.5, 0.5, "[missing]", ha="center", va="center")
                ax.set_xticks([]); ax.set_yticks([])
                continue
            img = Image.open(fname)
            if img.mode == "L" or len(img.getbands()) == 1:
                ax.imshow(np.array(img), cmap="gray", vmin=0, vmax=255)
            else:
                ax.imshow(np.array(img))
            ax.set_xticks([]); ax.set_yticks([])
            if i == 0:
                ax.set_title(label, fontsize=10)
            if j == 0:
                ax.set_ylabel(img_id, fontsize=10, rotation=0, labelpad=45,
                               va="center", ha="right")
            for spine in ax.spines.values():
                spine.set_visible(True)
                spine.set_linewidth(0.6)

    plt.tight_layout()
    out = os.path.join(OUT_DIR, "fig07_image_plate.png")
    plt.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", out)


# ============================================================
# Helper: simple linear regression
# ============================================================
def _linreg(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = ~np.isnan(x) & ~np.isnan(y)
    x = x[mask]; y = y[mask]
    n = len(x)
    if n < 3:
        return 0, 0, 0, 1, 0
    slope, intercept = np.polyfit(x, y, 1)
    y_pred = slope * x + intercept
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0
    r = np.sign(slope) * np.sqrt(r2)
    # t-statistic for slope
    se_slope = np.sqrt(ss_res / (n - 2) / np.sum((x - np.mean(x)) ** 2))
    t = slope / se_slope if se_slope > 0 else 0
    # p-value (two-sided) — approximate via survival function
    from scipy import stats
    p = 2 * (1 - stats.t.cdf(np.abs(t), df=n - 2))
    return float(slope), float(intercept), float(r), float(p), float(se_slope)


# ============================================================
# FIGURE 8 — Experimental setup and analysis pipeline schematic
# ============================================================
def fig08():
    """Two-panel schematic: (a) experimental apparatus, (b) analysis pipeline workflow.
    Drawn with matplotlib (no external image dependency)."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

    # Panel A: apparatus schematic (PIV/PTV imaging setup)
    ax = axes[0]
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.set_aspect("equal", adjustable="box")
    ax.axis("off")
    ax.set_title("(a) Single-bubble PIV/PTV imaging apparatus", fontsize=10)

    # flotation cell (cylinder)
    from matplotlib.patches import Rectangle, Circle, FancyArrowPatch, Polygon
    cell = Rectangle((1.5, 1), 4, 3.5, fill=False, ec=INK, lw=1.5)
    ax.add_patch(cell)
    # liquid fill
    ax.add_patch(Rectangle((1.55, 1.05), 3.9, 3.0, fill=True, facecolor=GREY3, alpha=0.25, ec="none"))
    ax.text(3.5, 4.7, "Optical cell (864×496 px frame)", ha="center", fontsize=8)
    # bubble
    bub = Circle((3.5, 2.5), 0.3, fill=False, ec=ACCENT, lw=1.5)
    ax.add_patch(bub)
    ax.annotate("Rising bubble\n(d = 116.5 ± 2.0 px)", xy=(3.8, 2.5), xytext=(5.3, 2.5),
                fontsize=7.5, ha="left", va="center",
                arrowprops=dict(arrowstyle="->", lw=0.7, color=INK))
    # tracer particles
    np.random.seed(42)
    for _ in range(40):
        x = np.random.uniform(1.7, 5.3)
        y = np.random.uniform(1.3, 4.0)
        if np.hypot(x-3.5, y-2.5) < 0.5:
            continue
        ax.plot(x, y, ".", color=GREY1, ms=1.5)
    ax.text(2.0, 0.5, "Seeded liquid phase (PIV tracers)", fontsize=7.5, color=GREY1)
    # camera
    cam = Rectangle((6.5, 2.5), 1.2, 0.6, fill=True, facecolor=GREY2, ec=INK, lw=0.8)
    ax.add_patch(cam)
    ax.text(7.1, 3.3, "Camera\n(96 frames)", ha="center", fontsize=7.5)
    # light sheet
    ax.annotate("", xy=(1.5, 3.5), xytext=(6.5, 2.8),
                arrowprops=dict(arrowstyle="->", lw=0.6, color=GREY2, ls="--"))
    ax.text(0.7, 4.5, "Light sheet", fontsize=7.5, color=GREY2, rotation=20)
    # calibration ruler
    ax.plot([1.5, 1.5], [0.8, 1.0], color=INK, lw=1.0)
    ax.plot([5.5, 5.5], [0.8, 1.0], color=INK, lw=1.0)
    ax.plot([1.5, 5.5], [0.9, 0.9], color=INK, lw=1.0)
    ax.text(3.5, 0.65, "Calibration ruler (3 mm)", ha="center", fontsize=7.5)
    # arrow showing rise
    ax.annotate("", xy=(3.5, 4.0), xytext=(3.5, 2.8),
                arrowprops=dict(arrowstyle="->", lw=1.5, color=ACCENT))
    ax.text(3.4, 4.2, "v_rise = 1.55 ± 0.30 px/frame", fontsize=7, color=ACCENT, ha="right")

    # Panel B: analysis pipeline flowchart
    ax = axes[1]
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis("off")
    ax.set_title("(b) Analysis pipeline (Python, OpenCV + OpenPIV)", fontsize=10)

    # Define boxes
    boxes = [
        (0.3, 4.5, "Raw frames\n(frame_XXXXXXXX.jpg,\n96 frames @ 864×496 px)"),
        (4.0, 4.5, "Step 1:\nSegmentation\n(Otsu + 13×13 erode-dilate)"),
        (7.7, 4.5, "Step 2: PTV tracking\n(SG 11-frame, 3rd order)"),
        (0.3, 2.0, "Step 3: Particle\ndetection\n(high-pass + CC)"),
        (4.0, 2.0, "Step 4: PIV cross-correlation\n(32×32 px, 50% overlap,\nOpenPIV)"),
        (7.7, 2.0, "Step 5: Bubble Analyser 2.0\ncross-validation\n(NormalWatershed defaults)"),
    ]
    for x, y, label in boxes:
        rect = Rectangle((x, y-0.6), 2.4, 1.2, fill=True, facecolor=GREY3, ec=INK, lw=0.8, alpha=0.4)
        ax.add_patch(rect)
        ax.text(x+1.2, y, label, ha="center", va="center", fontsize=7)

    # Arrows between boxes
    arrow_props = dict(arrowstyle="->", lw=0.9, color=INK)
    ax.annotate("", xy=(3.95, 4.5), xytext=(2.75, 4.5), arrowprops=arrow_props)
    ax.annotate("", xy=(7.65, 4.5), xytext=(6.45, 4.5), arrowprops=arrow_props)
    ax.annotate("", xy=(1.5, 3.25), xytext=(1.5, 3.85), arrowprops=arrow_props)
    ax.annotate("", xy=(5.2, 3.25), xytext=(5.2, 3.85), arrowprops=arrow_props)
    ax.annotate("", xy=(8.9, 3.25), xytext=(8.9, 3.85), arrowprops=arrow_props)
    ax.annotate("", xy=(3.95, 2.0), xytext=(2.75, 2.0), arrowprops=arrow_props)
    ax.annotate("", xy=(7.65, 2.0), xytext=(6.45, 2.0), arrowprops=arrow_props)

    # Output files
    ax.text(5.0, 0.4, "Outputs (4 CSV files):", ha="center", fontsize=8, fontweight="bold")
    ax.text(5.0, 0.1, "bubble_kinematics_and_particles.csv (96×38) | piv_summary.csv (95×10)\n"
                      "bubble_analyser_crosscheck.csv (96×5) | individual_particles.csv (5674×6)",
            ha="center", fontsize=7, color=GREY1)

    plt.tight_layout()
    out = os.path.join(OUT_DIR, "fig08_experimental_setup_pipeline.png")
    plt.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("wrote", out)


if __name__ == "__main__":
    fig01()
    fig02()
    fig03()
    fig04()
    fig05()
    fig06()
    fig07()
    fig08()
    print("\nAll figures generated.")
