#!/usr/bin/env python3
"""
deep_single_bubble_analysis.py — Additional single-bubble analyses from the
96-frame PIV/PTV dataset that were NOT computed in the first pass:
  - Aspect ratio oscillation frequency analysis
  - Bubble rotation from ellipse angle
  - Dimensionless numbers (Re, Eo, We) using tentative calibration
  - Particle tracking across frames (which particles persist?)
  - Particle radial distribution heatmap around bubble
  - Attachment/detachment event counts per frame
  - Per-frame particle size distribution
"""
import os
import json
import numpy as np
import pandas as pd
from scipy import stats as sstats
from scipy.signal import savgol_filter, find_peaks
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

for f in [
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf",
]:
    if os.path.exists(f):
        fm.fontManager.addfont(f)

plt.rcParams["font.family"] = "Liberation Serif"
plt.rcParams["font.serif"] = ["Liberation Serif", "DejaVu Serif"]
plt.rcParams["font.size"] = 10
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False

INK = "#000000"
GREY1 = "#444444"
GREY2 = "#888888"
GREY3 = "#BBBBBB"
ACCENT = "#1F4E79"
ACCENT_LIGHT = "#5B8DB8"
HIGHLIGHT = "#B22222"

DATA_DIR = "/home/z/my-project/upload/extracted"
OUT_DIR = "/home/z/my-project/scripts/figures"
os.makedirs(OUT_DIR, exist_ok=True)

# Load datasets
kin = pd.read_csv(os.path.join(DATA_DIR, "bubble_kinematics_and_particles.csv"))
parts = pd.read_csv(os.path.join(DATA_DIR, "individual_particles.csv"))

# Calibration (tentative)
UM_PER_PX = 11.2  # µm per pixel in the 96-frame PIV/PTV sequence (0.0112 mm/px)
# Physical constants
RHO_L = 1000.0   # water density kg/m³
RHO_G = 1.2      # air density kg/m³
G = 9.81          # m/s²
SIGMA = 0.072    # water-air surface tension N/m
MU_L = 1.0e-3   # water viscosity Pa·s

results = {}

# ============================================================
# 1. ASPECT RATIO OSCILLATION
# ============================================================
print("=" * 70)
print("1. Aspect ratio oscillation analysis")
print("=" * 70)
frames = kin["frame"].values
aspect = (kin["ellipse_major_px"] / kin["ellipse_minor_px"]).values
major = kin["ellipse_major_px"].values
minor = kin["ellipse_minor_px"].values
angle = kin["ellipse_angle_deg"].values
print(f"Aspect ratio: mean = {aspect.mean():.4f} ± {aspect.std():.4f}")
print(f"  Range: {aspect.min():.4f} - {aspect.max():.4f}")
print(f"Major axis: mean = {major.mean():.2f} ± {major.std():.2f} px")
print(f"Minor axis: mean = {minor.mean():.2f} ± {minor.std():.2f} px")
print(f"Ellipse angle: mean = {angle.mean():.2f}° ± {angle.std():.2f}°")
print(f"  Range: {angle.min():.2f}° - {angle.max():.2f}°")

# Fourier analysis of aspect ratio oscillation
# Frame rate unknown — assume 1 frame per unit time
aspect_centered = aspect - aspect.mean()
# Detect peaks (maxima) and troughs (minima)
peaks, _ = find_peaks(aspect_centered, height=0.005, distance=3)
troughs, _ = find_peaks(-aspect_centered, height=0.005, distance=3)
print(f"Detected peaks in aspect ratio oscillation: {len(peaks)}")
print(f"Detected troughs: {len(troughs)}")
if len(peaks) > 1:
    peak_intervals = np.diff(frames[peaks])
    print(f"Peak-to-peak frame intervals: {peak_intervals}")
    print(f"Mean oscillation period: {peak_intervals.mean():.2f} frames")
if len(troughs) > 1:
    trough_intervals = np.diff(frames[troughs])
    print(f"Trough-to-trough frame intervals: {trough_intervals}")

results["aspect_ratio_mean"] = float(aspect.mean())
results["aspect_ratio_std"] = float(aspect.std())
results["aspect_ratio_range"] = [float(aspect.min()), float(aspect.max())]
results["aspect_ratio_n_peaks"] = int(len(peaks))
results["aspect_ratio_n_troughs"] = int(len(troughs))
results["ellipse_angle_mean_deg"] = float(angle.mean())
results["ellipse_angle_std_deg"] = float(angle.std())

# ============================================================
# 2. DIMENSIONLESS NUMBERS (Re, Eo, We) using tentative calibration
# ============================================================
print()
print("=" * 70)
print("2. Dimensionless numbers (using tentative calibration)")
print("=" * 70)
d_b_m = kin["eq_diam_px_sg"].mean() * UM_PER_PX * 1e-6  # px → µm → m
v_b_ms = kin["v_rise_px_per_frame"].mean()  # px/frame
# Frame rate unknown — assume a typical high-speed camera at 500 fps
# Then v_b_ms_m_per_s = v_b_ms * UM_PER_PX * 1e-6 * 500
# We will report BOTH per-frame and per-second (with assumed 500 fps)
ASSUMED_FPS = 500
v_b_m_per_s = v_b_ms * UM_PER_PX * 1e-6 * ASSUMED_FPS
print(f"Bubble diameter d_b (mean SG): {kin['eq_diam_px_sg'].mean():.4f} px = {d_b_m*1e6:.1f} µm = {d_b_m*1e3:.3f} mm")
print(f"Bubble rise velocity v_b: {v_b_ms:.4f} px/frame")
print(f"  At assumed {ASSUMED_FPS} fps: {v_b_m_per_s:.4f} m/s = {v_b_m_per_s*100:.2f} cm/s")
Re = RHO_L * abs(v_b_m_per_s) * d_b_m / MU_L
Eo = (RHO_L - RHO_G) * G * d_b_m**2 / SIGMA
We = RHO_L * v_b_m_per_s**2 * d_b_m / SIGMA
print(f"Reynolds number Re (assumed {ASSUMED_FPS} fps): {Re:.2f}")
print(f"Eötvös number Eo: {Eo:.4f}")
print(f"Weber number We: {We:.6f}")
print(f"Note: Re, We depend on assumed frame rate ({ASSUMED_FPS} fps). Eo depends only on d_b.")
results["dimensionless_d_b_m"] = float(d_b_m)
results["dimensionless_d_b_mm"] = float(d_b_m * 1000)
results["dimensionless_v_b_px_per_frame"] = float(v_b_ms)
results["dimensionless_assumed_fps"] = ASSUMED_FPS
results["dimensionless_v_b_m_per_s_assumed"] = float(v_b_m_per_s)
results["Reynolds_assumed"] = float(Re)
results["Eotvos"] = float(Eo)
results["Weber_assumed"] = float(We)

# ============================================================
# 3. PARTICLE TRACKING ACROSS FRAMES
# ============================================================
print()
print("=" * 70)
print("3. Particle tracking across frames")
print("=" * 70)
# For each particle in individual_particles.csv, check if it appears in consecutive frames
# at approximately the same position relative to the bubble centroid
# Use centroid Lookup from kinematics file
centroid_lookup = {int(row.frame): (float(row.centroid_x_sg), float(row.centroid_y_sg)) for row in kin.itertuples()}
d_lookup = {int(row.frame): float(row.eq_diam_px_sg) for row in kin.itertuples()}

# Group particles by frame
parts_by_frame = {}
for fr in parts["frame"].unique():
    parts_by_frame[int(fr)] = parts[parts["frame"] == fr].copy()

# For each particle in frame i, find its position relative to bubble centroid
# Then try to match it to a particle in frame i+1 with similar relative position
def get_relative_positions(frame_idx):
    """Return array of (rel_x, rel_y, particle_eq_diam) for particles in this frame."""
    if frame_idx not in parts_by_frame:
        return None
    if frame_idx not in centroid_lookup:
        return None
    bx, by = centroid_lookup[frame_idx]
    df = parts_by_frame[frame_idx]
    return [(p.particle_x - bx, p.particle_y - by, p.particle_eq_diam_px) for p in df.itertuples()]

# Track particles across consecutive frames
tracked_lifetimes = []
total_match_attempts = 0
total_matches = 0
sorted_frames = sorted(parts_by_frame.keys())
for i in range(len(sorted_frames) - 1):
    fr_a = sorted_frames[i]
    fr_b = sorted_frames[i + 1]
    pos_a = get_relative_positions(fr_a)
    pos_b = get_relative_positions(fr_b)
    if pos_a is None or pos_b is None:
        continue
    # For each particle in A, find nearest in B (in relative position space)
    pos_b_arr = np.array([(p[0], p[1]) for p in pos_b])
    for rx, ry, dp in pos_a:
        if len(pos_b_arr) == 0:
            continue
        total_match_attempts += 1
        # Compute distance to all particles in B
        dists = np.sqrt((pos_b_arr[:, 0] - rx)**2 + (pos_b_arr[:, 1] - ry)**2)
        min_idx = np.argmin(dists)
        min_dist = dists[min_idx]
        # Match if within 5 px (small motion between frames)
        if min_dist < 5:
            total_matches += 1
            tracked_lifetimes.append((fr_a, fr_b))

print(f"Total match attempts (particles in frame i → i+1): {total_match_attempts}")
print(f"Successful matches (within 5 px relative displacement): {total_matches}")
print(f"Match rate: {100*total_matches/max(1,total_match_attempts):.1f}%")
results["particle_tracking_total_attempts"] = int(total_match_attempts)
results["particle_tracking_matches"] = int(total_matches)
results["particle_tracking_match_rate_pct"] = float(100*total_matches/max(1,total_match_attempts))

# ============================================================
# 4. ATTACHMENT/DETACHMENT EVENTS PER FRAME
# ============================================================
print()
print("=" * 70)
print("4. Attachment/detachment events per frame")
print("=" * 70)
n_per_frame = []
for fr in sorted_frames:
    n_per_frame.append((fr, len(parts_by_frame[fr])))
n_arr = np.array([x[1] for x in n_per_frame])
frames_arr = np.array([x[0] for x in n_per_frame])
# Compute first differences (positive = net attachments, negative = net detachments)
diffs = np.diff(n_arr)
n_attach_events = int(np.sum(diffs > 0))
n_detach_events = int(np.sum(diffs < 0))
n_stable_frames = int(np.sum(diffs == 0))
mean_net_change_per_frame = float(np.mean(diffs))
print(f"Per-frame attached-particle count change:")
print(f"  Frames with net attachments (Δn > 0): {n_attach_events}")
print(f"  Frames with net detachments (Δn < 0): {n_detach_events}")
print(f"  Frames with stable count (Δn = 0): {n_stable_frames}")
print(f"  Mean Δn per frame: {mean_net_change_per_frame:+.4f}")
print(f"  Max single-frame attachment burst: +{diffs.max():.0f}")
print(f"  Max single-frame detachment event: {diffs.min():.0f}")
results["n_attach_events"] = n_attach_events
results["n_detach_events"] = n_detach_events
results["n_stable_frames"] = n_stable_frames
results["mean_net_change_per_frame"] = mean_net_change_per_frame
results["max_attach_burst"] = int(diffs.max())
results["max_detach_event"] = int(diffs.min())

# ============================================================
# 5. PARTICLE RADIAL DISTRIBUTION (relative to bubble radius)
# ============================================================
print()
print("=" * 70)
print("5. Particle radial distribution (relative to bubble radius)")
print("=" * 70)
# For each particle, compute its distance from bubble centroid divided by bubble radius
radii_normalized = []
for _, p in parts.iterrows():
    fr = int(p.frame)
    if fr not in centroid_lookup or fr not in d_lookup:
        continue
    bx, by = centroid_lookup[fr]
    d_b = d_lookup[fr]
    R = d_b / 2
    dist = np.hypot(p.particle_x - bx, p.particle_y - by)
    radii_normalized.append(dist / R)
radii = np.array(radii_normalized)
print(f"Total particles with valid radius: {len(radii)}")
print(f"Mean normalised radius (r/R): {radii.mean():.4f}")
print(f"  Std: {radii.std():.4f}")
print(f"  Range: {radii.min():.4f} - {radii.max():.4f}")
print(f"  Median: {np.median(radii):.4f}")
print(f"  Particles on bubble surface (0.8 < r/R < 1.2): {int(np.sum((radii > 0.8) & (radii < 1.2)))} ({100*np.sum((radii > 0.8) & (radii < 1.2))/len(radii):.1f}%)")
print(f"  Particles inside bubble (r/R < 0.8): {int(np.sum(radii < 0.8))} ({100*np.sum(radii < 0.8)/len(radii):.1f}%)")
print(f"  Particles outside bubble (r/R > 1.2): {int(np.sum(radii > 1.2))} ({100*np.sum(radii > 1.2)/len(radii):.1f}%)")
results["particle_radial_mean"] = float(radii.mean())
results["particle_radial_std"] = float(radii.std())
results["particle_radial_median"] = float(np.median(radii))
results["particle_radial_on_surface_pct"] = float(100*np.sum((radii > 0.8) & (radii < 1.2))/len(radii))
results["particle_radial_inside_pct"] = float(100*np.sum(radii < 0.8)/len(radii))
results["particle_radial_outside_pct"] = float(100*np.sum(radii > 1.2)/len(radii))

# ============================================================
# 6. PER-FRAME PARTICLE SIZE DISTRIBUTION
# ============================================================
print()
print("=" * 70)
print("6. Per-frame particle size statistics")
print("=" * 70)
per_frame_d_mean = []
per_frame_d_smd = []
per_frame_d_max = []
per_frame_d_min = []
for fr in sorted_frames:
    df = parts_by_frame[fr]
    d = df["particle_eq_diam_px"].values
    d_pos = d[d > 0]
    if len(d_pos) == 0:
        continue
    per_frame_d_mean.append(d_pos.mean())
    per_frame_d_smd.append(np.sum(d_pos**3) / np.sum(d_pos**2))
    per_frame_d_max.append(d_pos.max())
    per_frame_d_min.append(d_pos.min())
per_frame_d_mean = np.array(per_frame_d_mean)
per_frame_d_smd = np.array(per_frame_d_smd)
print(f"Per-frame particle arithmetic mean diameter:")
print(f"  Mean across frames: {per_frame_d_mean.mean():.4f} ± {per_frame_d_mean.std():.4f} px")
print(f"  Range across frames: {per_frame_d_mean.min():.4f} - {per_frame_d_mean.max():.4f} px")
print(f"Per-frame particle SMD:")
print(f"  Mean across frames: {per_frame_d_smd.mean():.4f} ± {per_frame_d_smd.std():.4f} px")
print(f"  Range across frames: {per_frame_d_smd.min():.4f} - {per_frame_d_smd.max():.4f} px")
results["per_frame_particle_mean_diam_mean"] = float(per_frame_d_mean.mean())
results["per_frame_particle_mean_diam_std"] = float(per_frame_d_mean.std())
results["per_frame_particle_smd_mean"] = float(per_frame_d_smd.mean())
results["per_frame_particle_smd_std"] = float(per_frame_d_smd.std())

# Save
with open("/home/z/my-project/scripts/deep_single_bubble_stats.json", "w") as f:
    json.dump(results, f, indent=2)
print(f"\nSaved: /home/z/my-project/scripts/deep_single_bubble_stats.json")
