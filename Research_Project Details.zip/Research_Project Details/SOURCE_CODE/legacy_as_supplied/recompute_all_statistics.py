#!/usr/bin/env python3
"""
recompute_all_statistics.py — Recompute EVERY statistic claimed in the source
manuscripts directly from the CSV datasets. No quotation from secondary sources.

Cross-checks every number reported in:
- Single_Bubble_PIV_PTV_Analysis.docx (the empirical paper)
- Single_Bubble_Flotation_Paper_Q1.docx (the theoretical paper)

All numbers recomputed here are the authoritative values used in the
rewritten manuscript.
"""
import os
import sys
import json
import numpy as np
import pandas as pd
from scipy import stats as sstats

DATA_DIR = "/home/z/my-project/upload/extracted"

# ============================================================
# LOAD EVERYTHING
# ============================================================
kin = pd.read_csv(os.path.join(DATA_DIR, "bubble_kinematics_and_particles.csv"))
piv = pd.read_csv(os.path.join(DATA_DIR, "piv_summary.csv"))
xcheck = pd.read_csv(os.path.join(DATA_DIR, "bubble_analyser_crosscheck.csv"))
parts = pd.read_csv(os.path.join(DATA_DIR, "individual_particles.csv"))

results = {}

print("=" * 70)
print("DATASET INVENTORY")
print("=" * 70)
print(f"bubble_kinematics_and_particles.csv: {len(kin)} rows × {len(kin.columns)} cols")
print(f"  columns: {list(kin.columns)}")
print(f"  frame range: {kin.frame.min()}..{kin.frame.max()}")
print()
print(f"piv_summary.csv: {len(piv)} rows × {len(piv.columns)} cols")
print(f"  frame_a range: {piv.frame_a.min()}..{piv.frame_a.max()}")
print()
print(f"bubble_analyser_crosscheck.csv: {len(xcheck)} rows × {len(xcheck.columns)} cols")
print(f"  frame range: {xcheck.frame.min()}..{xcheck.frame.max()}")
print()
print(f"individual_particles.csv: {len(parts)} rows × {len(parts.columns)} cols")
print(f"  frame range: {parts.frame.min()}..{parts.frame.max()}")
print(f"  unique frames: {parts.frame.nunique()}")
print()

# ============================================================
# 1. BUBBLE DIAMETER (this pipeline)
# ============================================================
print("=" * 70)
print("1. BUBBLE EQUIVALENT DIAMETER (this pipeline, eq_diam_px_sg)")
print("=" * 70)
# Per the source manuscript, eq_diam_px_sg is the Savitzky-Golay smoothed
d_this = kin["eq_diam_px_sg"].values
d_this_raw = kin["eq_diam_px"].values
print(f"Raw eq_diam_px: mean = {d_this_raw.mean():.4f} px, std = {d_this_raw.std():.4f} px")
print(f"  range: {d_this_raw.min():.2f} .. {d_this_raw.max():.2f} px")
print(f"  CV: {d_this_raw.std()/d_this_raw.mean()*100:.2f}%")
print(f"Savitzky-Golay eq_diam_px_sg: mean = {d_this.mean():.4f} px, std = {d_this.std():.4f} px")
print(f"  range: {d_this.min():.2f} .. {d_this.max():.2f} px")
print(f"  CV: {d_this.std()/d_this.mean()*100:.2f}%")
results["bubble_diameter_mean_px"] = float(d_this.mean())
results["bubble_diameter_std_px"] = float(d_this.std())
results["bubble_diameter_min_px"] = float(d_this.min())
results["bubble_diameter_max_px"] = float(d_this.max())
results["bubble_diameter_cv_pct"] = float(d_this.std()/d_this.mean()*100)

# ============================================================
# 2. BUBBLE DIAMETER (Bubble Analyser 2.0 cross-validation)
# ============================================================
print()
print("=" * 70)
print("2. BUBBLE DIAMETER (Bubble Analyser 2.0 cross-validation, ba_eq_diam_px)")
print("=" * 70)
d_ba = xcheck["ba_eq_diam_px"].values
print(f"BA eq_diam_px: mean = {d_ba.mean():.4f} px, std = {d_ba.std():.4f} px")
print(f"  range: {d_ba.min():.2f} .. {d_ba.max():.2f} px")
# Correlation
r_pearson, p_pearson = sstats.pearsonr(d_this, d_ba)
slope, intercept, r_val, p_val, se = sstats.linregress(d_this, d_ba)
# Mean absolute difference
diff_abs = np.abs(d_ba - d_this)
mean_diff_abs_px = float(diff_abs.mean())
mean_diff_pct = float((diff_abs / d_this).mean() * 100)
mean_bias = float((d_ba - d_this).mean())
# R²
ss_res = np.sum((d_ba - (slope * d_this + intercept)) ** 2)
ss_tot = np.sum((d_ba - d_ba.mean()) ** 2)
r_squared = 1 - ss_res / ss_tot

print(f"Mean of BA: {d_ba.mean():.4f} px (this pipeline: {d_this.mean():.4f} px)")
print(f"Mean abs difference: {mean_diff_abs_px:.4f} px ({mean_diff_pct:.4f}%)")
print(f"Mean bias (BA - this): {mean_bias:+.4f} px")
print(f"Pearson r: {r_pearson:.6f}, p-value: {p_pearson:.4e}")
print(f"Linear regression: BA = {slope:.4f} * this + {intercept:.4f} (r = {r_val:.6f}, p = {p_val:.4e})")
print(f"R² (linear fit): {r_squared:.6f}")
print(f"Frames matched: {len(d_ba)} / {len(d_this)} (all 96 frames)")
results["bubble_analyser_mean_px"] = float(d_ba.mean())
results["bubble_analyser_std_px"] = float(d_ba.std())
results["bubble_analyser_mean_abs_diff_px"] = mean_diff_abs_px
results["bubble_analyser_mean_diff_pct"] = mean_diff_pct
results["bubble_analyser_pearson_r"] = float(r_pearson)
results["bubble_analyser_r_squared"] = float(r_squared)
results["bubble_analyser_regression_slope"] = float(slope)
results["bubble_analyser_regression_intercept"] = float(intercept)
results["bubble_analyser_n_frames_matched"] = int(len(d_ba))

# Note: above cross-check values use SG-smoothed diameters from this pipeline.
# However, the manuscript (and source PIV/PTV paper) report cross-check using RAW
# diameters from this pipeline (matching the convention used in the source
# Bubble Analyser crosscheck CSV column 'my_eq_diam_px' which equals the raw
# value, not SG-smoothed). We therefore also report the raw-diameter version:
print("\n--- Bubble Analyser crosscheck ALSO computed using RAW diameters ---")
print("(This matches the source manuscript methodology.)")
d_mine_raw_for_xcheck = xcheck["my_eq_diam_px"].values  # = raw eq_diam_px from kin
r_raw_xc, p_raw_xc = sstats.pearsonr(d_mine_raw_for_xcheck, d_ba)
slope_raw_xc, int_raw_xc, _, _, _ = sstats.linregress(d_mine_raw_for_xcheck, d_ba)
ss_res_raw = np.sum((d_ba - (slope_raw_xc * d_mine_raw_for_xcheck + int_raw_xc)) ** 2)
r2_raw_xc = 1 - ss_res_raw / np.sum((d_ba - d_ba.mean()) ** 2)
mean_diff_raw_xc = float(np.mean(np.abs(d_ba - d_mine_raw_for_xcheck)))
mean_diff_pct_raw_xc = float((np.abs(d_ba - d_mine_raw_for_xcheck) / d_mine_raw_for_xcheck).mean() * 100)
print(f"  RAW-based: r = {r_raw_xc:.6f}, R² = {r2_raw_xc:.6f}, mean diff = {mean_diff_raw_xc:.4f} px ({mean_diff_pct_raw_xc:.4f}%)")
print(f"  Regression: BA = {slope_raw_xc:.4f} * mine + {int_raw_xc:.4f}")
results["bubble_analyser_raw_pearson_r"] = float(r_raw_xc)
results["bubble_analyser_raw_r_squared"] = float(r2_raw_xc)
results["bubble_analyser_raw_regression_slope"] = float(slope_raw_xc)
results["bubble_analyser_raw_regression_intercept"] = float(int_raw_xc)
results["bubble_analyser_raw_mean_diff_pct"] = mean_diff_pct_raw_xc
results["bubble_analyser_raw_mean_abs_diff_px"] = mean_diff_raw_xc

# ============================================================
# 3. BUBBLE TRAJECTORY (centroid)
# ============================================================
print()
print("=" * 70)
print("3. BUBBLE CENTROID TRAJECTORY")
print("=" * 70)
cx = kin["centroid_x_sg"].values
cy = kin["centroid_y_sg"].values
# Net displacement
net_rise_px = cy[0] - cy[-1]  # image y increases downward, so rise = -dy
net_horiz_px = cx[-1] - cx[0]
path_length = float(np.sum(np.sqrt(np.diff(cx)**2 + np.diff(cy)**2)))
straightness = net_rise_px / path_length if path_length > 0 else 0
print(f"Start centroid: ({cx[0]:.2f}, {cy[0]:.2f}) px")
print(f"End centroid:   ({cx[-1]:.2f}, {cy[-1]:.2f}) px")
print(f"Net vertical rise: {net_rise_px:.2f} px")
print(f"Net horizontal drift: {net_horiz_px:.2f} px")
print(f"Path length (sum of frame-to-frame displacements): {path_length:.2f} px")
print(f"Straightness index (net rise / path length): {straightness:.4f}")
results["bubble_net_rise_px"] = float(net_rise_px)
results["bubble_net_horiz_px"] = float(net_horiz_px)
results["bubble_path_length_px"] = float(path_length)
results["bubble_straightness"] = float(straightness)

# ============================================================
# 4. RISE VELOCITY
# ============================================================
print()
print("=" * 70)
print("4. RISE VELOCITY (Savitzky-Golay filtered, v_rise_px_per_frame)")
print("=" * 70)
v_rise = kin["v_rise_px_per_frame"].values
v_rise_raw = kin["v_rise_px_per_frame_raw"].values
print(f"Savitzky-Golay v_rise: mean = {v_rise.mean():.4f} px/frame, std = {v_rise.std():.4f}")
print(f"  range: {v_rise.min():.4f} .. {v_rise.max():.4f}")
print(f"Raw frame-differenced v_rise: mean = {v_rise_raw.mean():.4f}, std = {v_rise_raw.std():.4f}")
# Noise floor via SG residual: difference between raw and SG
noise_residual = v_rise_raw - v_rise
print(f"Residual noise (raw - SG): std = {noise_residual.std():.4f} px/frame")
# Diameter noise floor via SG residual on diameter
d_residual = d_this_raw - d_this
print(f"Diameter measurement-noise floor (raw - SG on diameter): std = {d_residual.std():.4f} px ({d_residual.std()/d_this.mean()*100:.4f}% of mean)")
results["rise_velocity_mean_px_per_frame"] = float(v_rise.mean())
results["rise_velocity_std_px_per_frame"] = float(v_rise.std())
results["rise_velocity_raw_mean_px_per_frame"] = float(v_rise_raw.mean())
results["rise_velocity_raw_std_px_per_frame"] = float(v_rise_raw.std())
results["diameter_noise_floor_px"] = float(d_residual.std())
results["diameter_noise_floor_pct"] = float(d_residual.std()/d_this.mean()*100)

# ============================================================
# 5. BUBBLE SHAPE (aspect ratio)
# ============================================================
print()
print("=" * 70)
print("5. BUBBLE SHAPE — ASPECT RATIO (ellipse_major / ellipse_minor)")
print("=" * 70)
major = kin["ellipse_major_px"].values
minor = kin["ellipse_minor_px"].values
aspect = major / minor
print(f"Aspect ratio: mean = {aspect.mean():.4f}, std = {aspect.std():.4f}")
print(f"  range: {aspect.min():.4f} .. {aspect.max():.4f}")
results["aspect_ratio_mean"] = float(aspect.mean())
results["aspect_ratio_std"] = float(aspect.std())

# ============================================================
# 6. ATTACHED-PARTICLE DYNAMICS (per-frame count + coverage)
# ============================================================
print()
print("=" * 70)
print("6. ATTACHED-PARTICLE DYNAMICS")
print("=" * 70)
n_part = kin["n_particles_visible"].values
cov = kin["particle_coverage_pct"].values
print(f"Per-frame attached-particle count: mean = {n_part.mean():.4f}, std = {n_part.std():.4f}")
print(f"  range: {n_part.min()} .. {n_part.max()}")
print(f"  CV: {n_part.std()/n_part.mean()*100:.2f}%")
print(f"Per-frame coverage %: mean = {cov.mean():.4f}, std = {cov.std():.4f}")
# Linear regression on count vs frame
frames = kin["frame"].values
slope_n, intercept_n, r_n, p_n, se_n = sstats.linregress(frames, n_part)
slope_c, intercept_c, r_c, p_c, se_c = sstats.linregress(frames, cov)
print(f"Count vs frame: slope = {slope_n:.6f}/frame, r = {r_n:.4f}, p = {p_n:.4e}, se = {se_n:.4e}")
print(f"Coverage vs frame: slope = {slope_c:.6f}/frame, r = {r_c:.4f}, p = {p_c:.4e}")
results["particle_count_mean"] = float(n_part.mean())
results["particle_count_std"] = float(n_part.std())
results["particle_count_slope_per_frame"] = float(slope_n)
results["particle_count_r"] = float(r_n)
results["particle_count_p"] = float(p_n)
results["coverage_mean"] = float(cov.mean())
results["coverage_std"] = float(cov.std())
results["coverage_slope_per_frame"] = float(slope_c)
results["coverage_r"] = float(r_c)
results["coverage_p"] = float(p_c)

# ============================================================
# 7. POOLED PARTICLE DIAMETER (n = all individual particles)
# ============================================================
print()
print("=" * 70)
print("7. POOLED ATTACHED-PARTICLE DIAMETER")
print("=" * 70)
d_p_all = parts["particle_eq_diam_px"].values
d_p_pos = d_p_all[d_p_all > 0]
print(f"Total particle detections (n): {len(d_p_all)}")
print(f"  with positive eq_diam: {len(d_p_pos)}")
print(f"  mean: {d_p_pos.mean():.6f} px")
print(f"  std: {d_p_pos.std():.6f} px")
print(f"  median: {np.median(d_p_pos):.6f} px")
print(f"  range: {d_p_pos.min():.4f} .. {d_p_pos.max():.4f} px")
# SMD = sum(d^3) / sum(d^2)
smd_p = float(np.sum(d_p_pos**3) / np.sum(d_p_pos**2))
print(f"  SMD (Sauter Mean Diameter, sum(d^3)/sum(d^2)): {smd_p:.6f} px")
results["particle_total_detections"] = int(len(d_p_all))
results["particle_total_detections_positive"] = int(len(d_p_pos))
results["particle_mean_diam_px"] = float(d_p_pos.mean())
results["particle_std_diam_px"] = float(d_p_pos.std())
results["particle_median_diam_px"] = float(np.median(d_p_pos))
results["particle_smd_diam_px"] = smd_p

# ============================================================
# 8. BUBBLE-TO-PARTICLE RATIO (BPR)
# ============================================================
print()
print("=" * 70)
print("8. BUBBLE-TO-PARTICLE RATIO (BPR)")
print("=" * 70)
# Pooled BPR (SMD basis): mean bubble diameter / pooled particle SMD
bpr_pooled_smd = float(d_this.mean() / smd_p)
bpr_pooled_mean = float(d_this.mean() / d_p_pos.mean())
print(f"Pooled BPR (SMD basis): mean bubble diam ({d_this.mean():.4f}) / pooled particle SMD ({smd_p:.4f}) = {bpr_pooled_smd:.4f}")
print(f"Pooled BPR (arithmetic mean basis): {d_this.mean():.4f} / {d_p_pos.mean():.4f} = {bpr_pooled_mean:.4f}")

# Per-frame BPR using per-frame particle SMD
smd_per_frame = kin["particle_smd_px"].values
bpr_per_frame = np.where(smd_per_frame > 0, d_this / smd_per_frame, np.nan)
valid = ~np.isnan(bpr_per_frame)
print(f"Per-frame BPR (SMD basis): n valid = {valid.sum()}, mean = {bpr_per_frame[valid].mean():.4f}, std = {bpr_per_frame[valid].std():.4f}")
# Linear regression on per-frame BPR vs frame
if valid.sum() > 3:
    slope_bpr, int_bpr, r_bpr, p_bpr, se_bpr = sstats.linregress(
        kin.frame.values[valid], bpr_per_frame[valid])
    print(f"  BPR vs frame: slope = {slope_bpr:.6f}/frame, r = {r_bpr:.4f}, p = {p_bpr:.4f}")

results["bpr_pooled_smd"] = bpr_pooled_smd
results["bpr_pooled_mean"] = bpr_pooled_mean
results["bpr_per_frame_mean"] = float(bpr_per_frame[valid].mean())
results["bpr_per_frame_std"] = float(bpr_per_frame[valid].std())
results["bpr_per_frame_n_valid"] = int(valid.sum())
if valid.sum() > 3:
    results["bpr_per_frame_slope"] = float(slope_bpr)
    results["bpr_per_frame_r"] = float(r_bpr)
    results["bpr_per_frame_p"] = float(p_bpr)

# ============================================================
# 9. LEADING/TRAILING ATTACHMENT BIAS
# ============================================================
print()
print("=" * 70)
print("9. LEADING/TRAILING ATTACHMENT BIAS")
print("=" * 70)
# Per-frame travel direction: use mean of frame-to-frame centroid displacements
# (NOT per-frame velocity which is noisy)
dx_frame = np.diff(cx)
dy_frame = np.diff(cy)
mvx, mvy = float(np.mean(dx_frame)), float(np.mean(dy_frame))
print(f"Mean frame-to-frame centroid displacement: ({mvx:+.4f}, {mvy:+.4f}) px/frame")
norm = np.hypot(mvx, mvy)
print(f"  magnitude: {norm:.4f} px/frame")
uvx, uvy = mvx/norm, mvy/norm
print(f"  unit vector: ({uvx:+.4f}, {uvy:+.4f})")

# For each particle, find its frame's bubble centroid and project
# We need to look up centroid for each particle's frame
centroid_lookup = {int(row.frame): (float(row.centroid_x_sg), float(row.centroid_y_sg)) for row in kin.itertuples()}
projections = []
for _, p in parts.iterrows():
    fr = int(p.frame)
    if fr not in centroid_lookup:
        continue
    bx, by = centroid_lookup[fr]
    rx = p.particle_x - bx
    ry = p.particle_y - by
    proj = rx * uvx + ry * uvy
    projections.append(proj)
proj = np.array(projections)
print(f"Total particles with valid frame match: {len(proj)}")
leading_count = int(np.sum(proj > 0))
trailing_count = int(np.sum(proj < 0))
print(f"Leading (proj > 0): {leading_count} ({100*leading_count/len(proj):.2f}%)")
print(f"Trailing (proj < 0): {trailing_count} ({100*trailing_count/len(proj):.2f}%)")
mean_proj = float(proj.mean())
# One-sample t-test against zero
t_stat, p_t = sstats.ttest_1samp(proj, 0)
print(f"Mean projection: {mean_proj:+.4f} px")
print(f"One-sample t-test against 0: t = {t_stat:.4f}, p = {p_t:.4e}")
# Also: how does this compare to using the pre-computed leading_trailing_proj_px?
print(f"\nCross-check with pre-computed leading_trailing_proj_px column in individual_particles.csv:")
lt_proj = parts["leading_trailing_proj_px"].values
print(f"  Mean pre-computed projection: {lt_proj.mean():+.4f} px (n = {len(lt_proj)})")
print(f"  Std: {lt_proj.std():.4f} px")
print(f"  Mean (pre-computed) leading count: {int((parts['is_leading']==True).sum())}")
t_stat2, p_t2 = sstats.ttest_1samp(lt_proj, 0)
print(f"  One-sample t-test (pre-computed): t = {t_stat2:.4f}, p = {p_t2:.4e}")

results["leading_count"] = leading_count
results["trailing_count"] = trailing_count
results["leading_pct"] = float(100*leading_count/len(proj))
results["trailing_pct"] = float(100*trailing_count/len(proj))
results["mean_projection_px"] = mean_proj
results["t_stat_leading"] = float(t_stat)
results["p_leading"] = float(p_t)
results["n_particles_travel_projected"] = int(len(proj))

# ============================================================
# 10. PIV VELOCITY FIELD STATISTICS
# ============================================================
print()
print("=" * 70)
print("10. PIV VELOCITY FIELD STATISTICS")
print("=" * 70)
mean_u = piv["mean_u_px"].values
mean_v = piv["mean_v_px"].values
std_u = piv["std_u_px"].values
std_v = piv["std_v_px"].values
mean_speed = piv["mean_speed_px"].values
max_speed = piv["max_speed_px"].values
n_valid = piv["n_valid_vectors"].values
n_total = piv["n_total_vectors"].values

print(f"Far-field mean u (horizontal): {mean_u.mean():.4f} ± {mean_u.std():.4f} px/frame")
print(f"Far-field mean v (vertical, + = downward): {mean_v.mean():.4f} ± {mean_v.std():.4f} px/frame")
print(f"Far-field std u (RMS fluctuation): {std_u.mean():.4f} px/frame")
print(f"Far-field std v (RMS fluctuation): {std_v.mean():.4f} px/frame")
print(f"Mean speed (vector magnitude): {mean_speed.mean():.4f} ± {mean_speed.std():.4f} px/frame")
print(f"Max speed: {max_speed.mean():.4f} ± {max_speed.max():.4f} px/frame")
# Turbulent kinetic energy proxy: k = 0.5(u'^2 + v'^2)
k_proxy = 0.5 * (std_u**2 + std_v**2)
print(f"TKE proxy k = 0.5(u'² + v'²): mean = {k_proxy.mean():.6f} (px/frame)²")
# Ratio of bubble rise speed to far-field mean speed
ratio_speed = v_rise.mean() / mean_speed.mean()
print(f"Ratio bubble rise speed / far-field mean speed: {ratio_speed:.4f}×")
# Valid vectors fraction
valid_frac = n_valid / n_total
print(f"Valid PIV vectors per pair: {n_valid.mean():.1f} / {n_total.mean():.0f} ({valid_frac.mean()*100:.2f}%)")
results["piv_mean_u"] = float(mean_u.mean())
results["piv_mean_u_std"] = float(mean_u.std())
results["piv_mean_v"] = float(mean_v.mean())
results["piv_mean_v_std"] = float(mean_v.std())
results["piv_rms_u"] = float(std_u.mean())
results["piv_rms_v"] = float(std_v.mean())
results["piv_mean_speed"] = float(mean_speed.mean())
results["piv_max_speed_mean"] = float(max_speed.mean())
results["piv_tke_proxy"] = float(k_proxy.mean())
results["piv_speed_ratio"] = float(ratio_speed)
results["piv_valid_vectors_mean"] = float(n_valid.mean())
results["piv_total_vectors"] = int(n_total[0])

# ============================================================
# 11. SAVITZKY-GOLAY FIT ROBUSTNESS CHECK
# ============================================================
print()
print("=" * 70)
print("11. SAVITZKY-GOLAY FIT ROBUSTNESS CHECK")
print("=" * 70)
# Try window 7, 11, 15 with order 2, 3
from scipy.signal import savgol_filter
cx_raw = kin["centroid_x"].values  # raw centroid
cy_raw = kin["centroid_y"].values
for win in [7, 11, 15]:
    for order in [2, 3]:
        if win <= order:
            continue
        sg_cx = savgol_filter(cx_raw, win, order)
        sg_cy = savgol_filter(cy_raw, win, order)
        sg_dx = savgol_filter(cx_raw, win, order, deriv=1)
        sg_dy = savgol_filter(cy_raw, win, order, deriv=1)
        v_rise_check = -sg_dy
        print(f"  win={win}, order={order}: mean v_rise = {v_rise_check.mean():.4f} ± {v_rise_check.std():.4f} px/frame")

# ============================================================
# 12. SUMMARY — REPORT AS JSON
# ============================================================
print()
print("=" * 70)
print("SUMMARY — ALL RECOMPUTED STATISTICS")
print("=" * 70)
print(json.dumps(results, indent=2))

# Save to file
out_path = "/home/z/my-project/scripts/recomputed_stats.json"
with open(out_path, "w") as f:
    json.dump(results, f, indent=2)
print(f"\nSaved to: {out_path}")
