#!/usr/bin/env python3
"""
make_mass_and_gallery_figures.py
Functional reproduction of manuscript Figures 8, 9, 10 and 11 from the supplied data. The original plotting script for
these figures (generate_figures_part4.py, named in the imaging-procedure slides) was NOT supplied, so the layout is
rebuilt here; the plotted numbers come only from the CSV data and the stated model inputs. Not pixel-identical.
  Fig. 8   (a) per-frame assumed mass, (b) cumulative / unique-detection curve, (c) features vs model Np
  Fig. 9   six equally spaced rise stages with hull-equivalent circle and smoothed path
  Fig. 10  six early-rise stages with detected features (blue circles)
  Fig. 11  per-frame assumed mass with the six selected frames marked
"""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Circle
from PIL import Image
from scipy import stats

plt.rcParams.update({"font.family": "serif", "font.serif": ["Liberation Serif", "DejaVu Serif"], "font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
ROOT = Path(__file__).resolve().parents[2]
PUB, SRC = ROOT / "FIGURES/PUBLICATION_READY/reproduced_from_data", ROOT / "FIGURES/SOURCE_DATA"
PUB.mkdir(parents=True, exist_ok=True)
pf = pd.read_csv(ROOT / "DATA/PROCESSED_DATA/per_frame_processed.csv")
par = pd.read_csv(ROOT / "DATA/PROCESSED_DATA/supplied_csv/individual_particles.csv")
S = json.load(open(ROOT / "DATA/DERIVED_DATA/manuscript_statistics.json"))
FR = ROOT / "DATA/RAW_DATA/system_C_single_bubble_frames"
m_ug = pf.assumed_mass_ng.values / 1e3; fr = pf.frame.values


def save(fig, n):
    fig.savefig(PUB / f"{n}.png", dpi=300, bbox_inches="tight"); fig.savefig(PUB / f"{n}.pdf", bbox_inches="tight"); plt.close(fig)


# ---- Fig 8
q = 1 - S["persist_pct"] / 100
U = np.cumsum(np.r_[m_ug[0], q * m_ug[1:]])
sl, ic, r, _, _ = stats.linregress(fr, m_ug)
fig, ax = plt.subplots(1, 3, figsize=(11, 3.2))
ax[0].plot(fr, m_ug, "-", color="0.3", lw=1); ax[0].plot(fr, sl * fr + ic, "r--", lw=1, label=f"slope {sl*1e3:.1f} ng/frame, r = {r:.2f}"); ax[0].axhline(m_ug.mean(), color="C0", lw=.8, label=f"mean {m_ug.mean():.2f} ug")
ax[0].set_xlabel("Frame"); ax[0].set_ylabel("Assumed mass per frame (ug)"); ax[0].legend(frameon=False, fontsize=7)
ax[1].plot(fr, np.cumsum(m_ug), label="cumulative (frame sum)"); ax[1].plot(fr, U, "--", label=f"unique-detection estimate U(f), q={q:.3f}")
ax[1].set_xlabel("Frame"); ax[1].set_ylabel("Mass (ug)"); ax[1].legend(frameon=False, fontsize=7)
ax[2].bar(["Mean feature\ncount", "Model Np\n(Es 0.95)", "Model Np\n(Es 0.80)"], [S["count_mean"], S["Np_Es_95"], S["Np_Es_80"]], color=["0.4", "C0", "C0"])
ax[2].set_yscale("log"); ax[2].set_ylabel("Particles per bubble (-)")
for a, t in zip(ax, "abc"):
    a.text(-0.15, 1.05, t, transform=a.transAxes, weight="bold")
fig.suptitle("Fig. 8 (functional reproduction)  Assumed mineral load and illustrative model comparison", y=1.04, fontsize=10); save(fig, "Fig8_reproduced")
pd.DataFrame(dict(frame=fr, assumed_mass_ug=m_ug, unique_estimate_ug=U)).to_csv(SRC / "Fig8_11_source_data.csv", index=False)


# ---- gallery helpers
def panel(a, f, features=False, path=False):
    row = pf[pf.frame == f].iloc[0]; im = np.array(Image.open(FR / f"frame_{f:08d}.jpg").convert("L"))
    cx, cy, R = row.cx_sg_px, row.cy_sg_px, row.d_sg_px / 2; pad = R * 1.5
    a.imshow(im, cmap="gray", vmin=0, vmax=255); a.set_xlim(cx - pad, cx + pad); a.set_ylim(cy + pad, cy - pad); a.axis("off")
    a.add_patch(Circle((cx, cy), R, fill=False, ec="red", lw=1))
    if features:
        for p in par[par.frame == f].itertuples():
            a.add_patch(Circle((p.particle_x, p.particle_y), max(p.particle_eq_diam_px / 2 + 1.2, 2), fill=False, ec="dodgerblue", lw=.5))
    a.set_title(f"F{f}  d={row.d_sg_px:.1f} px  n={int(row.n_features)}", fontsize=8)


for name, frames_, feat, title in (("Fig9_reproduced", (25, 44, 63, 83, 102, 120), False, "Fig. 9 (functional reproduction)  Six equally spaced rise stages"),
                                   ("Fig10_reproduced", (36, 39, 45, 49, 55, 60), True, "Fig. 10 (functional reproduction)  Detected features at six early-rise stages")):
    fig, axs = plt.subplots(1, 6, figsize=(12, 2.4))
    for a, f in zip(axs, frames_):
        panel(a, f, feat)
    fig.suptitle(title, y=1.08, fontsize=10); save(fig, name)

# ---- Fig 11
fig, ax = plt.subplots(figsize=(6.5, 3))
ax.plot(fr, m_ug, color="0.3", lw=1)
for f in (36, 39, 45, 49, 55, 60):
    ax.axvline(f, color="red", ls=":", lw=.8); ax.text(f, ax.get_ylim()[1] * .97, f"F{f}", rotation=90, ha="right", va="top", fontsize=7, color="red")
ax.axhline(m_ug.mean(), color="C0", lw=.8); ax.set_xlabel("Frame"); ax.set_ylabel("Assumed mass per frame (ug)")
ax.set_title("Fig. 11 (functional reproduction)  Per-frame assumed mass, selected frames marked", fontsize=9); save(fig, "Fig11_reproduced")
print("wrote reproduced Figs 8-11")
