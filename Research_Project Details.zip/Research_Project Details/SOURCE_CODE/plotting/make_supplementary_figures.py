#!/usr/bin/env python3
"""
make_supplementary_figures.py  (NEW figures for the Supplementary Information)
Run after compute_manuscript_statistics.py and sensitivity_fps_scale.py.
  Fig. S1  frame-rate / scale sensitivity of Re, Ec and the measured-to-model particle count ratio
  Fig. S2  robustness of the headline kinematic statistics to the Savitzky-Golay window and order
  Fig. S3  evidence on the spatial scale: the burned-in '3 mm' bar in frame 73 is clipped by the image edge
Outputs: FIGURES/PUBLICATION_READY/Fig_S*.png|pdf  and  FIGURES/SOURCE_DATA/Fig_S*_source_data.csv
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image
from scipy.signal import savgol_filter

plt.rcParams.update({"font.family": "serif", "font.serif": ["Liberation Serif", "DejaVu Serif"], "font.size": 9,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.unicode_minus": False})
ROOT = Path(__file__).resolve().parents[2]
PUB, SRC = ROOT / "FIGURES" / "PUBLICATION_READY", ROOT / "FIGURES" / "SOURCE_DATA"
PUB.mkdir(parents=True, exist_ok=True); SRC.mkdir(parents=True, exist_ok=True)


def save(fig, name):
    fig.savefig(PUB / f"{name}.png", dpi=300, bbox_inches="tight"); fig.savefig(PUB / f"{name}.pdf", bbox_inches="tight"); plt.close(fig)


# ---------------------------------------------------------------- S1
sens = pd.read_csv(ROOT / "DATA/DERIVED_DATA/sensitivity_fps_scale.csv")
sens.to_csv(SRC / "Fig_S1_source_data.csv", index=False)
fig, ax = plt.subplots(1, 3, figsize=(10, 3.2))
for um, mk in ((11.2, "o-"), (16.04, "s--")):
    s = sens[sens.um_per_px == um]
    ax[0].plot(s.fps, s.Re, mk, label=f"{um} um/px"); ax[1].plot(s.fps, s.Ec * 1e3, mk); ax[2].plot(s.fps, s.feature_count_over_Np, mk)
ax[0].set_ylabel("Reynolds number Re"); ax[1].set_ylabel("Ec (x10$^{-3}$)"); ax[2].set_ylabel("Mean feature count / model Np")
ax[0].axhline(48.6, color="0.6", lw=.6)
for a, t in zip(ax, "abc"):
    a.set_xlabel("Assumed frame rate (fps)"); a.set_xscale("log"); a.set_xticks([500, 1000, 2000]); a.set_xticklabels(["500", "1000", "2000"]); a.text(-0.2, 1.05, t, transform=a.transAxes, weight="bold")
ax[0].legend(frameon=False); fig.suptitle("Fig. S1  Sensitivity to the unverified frame rate and spatial scale", y=1.03, fontsize=10)
save(fig, "Fig_S1_sensitivity_fps_scale")

# ---------------------------------------------------------------- S2
k = pd.read_csv(ROOT / "DATA/PROCESSED_DATA/supplied_csv/bubble_kinematics_and_particles.csv")
rows = []
for w in (7, 9, 11, 15, 21):
    for o in (2, 3):
        v = -savgol_filter(k.centroid_y.values, w, o, deriv=1, mode="interp"); d = savgol_filter(k.eq_diam_px.values, w, o, mode="interp")
        rows.append(dict(window=w, order=o, v_mean=v.mean(), v_sd=v.std(), d_mean=d.mean(), d_sd=d.std(), noise_floor=(k.eq_diam_px.values - d).std()))
rb = pd.DataFrame(rows); rb.to_csv(SRC / "Fig_S2_source_data.csv", index=False)
fig, ax = plt.subplots(1, 3, figsize=(10, 3.0))
for o, mk in ((2, "o-"), (3, "s--")):
    s = rb[rb.order == o]
    ax[0].plot(s.window, s.v_mean, mk, label=f"order {o}"); ax[1].plot(s.window, s.v_sd, mk); ax[2].plot(s.window, s.d_sd, mk)
for a, yl, t in zip(ax, ("Mean rise velocity (px/frame)", "SD of rise velocity (px/frame)", "SD of smoothed diameter (px)"), "abc"):
    a.set_xlabel("Savitzky-Golay window (frames)"); a.set_ylabel(yl); a.text(-0.2, 1.05, t, transform=a.transAxes, weight="bold")
ax[0].legend(frameon=False); fig.suptitle("Fig. S2  Robustness to the smoothing parameters (manuscript uses window 11, order 3)", y=1.03, fontsize=10)
save(fig, "Fig_S2_savgol_robustness")

# ---------------------------------------------------------------- S3
im = np.array(Image.open(ROOT / "DATA/RAW_DATA/system_C_single_bubble_frames/frame_00000073.jpg").convert("L")); h, w = im.shape
fig, ax = plt.subplots(1, 2, figsize=(10, 3.2), gridspec_kw={"width_ratios": [1.6, 1]})
ax[0].imshow(im[h - 60:h, w - 340:w], cmap="gray", extent=[w - 340, w, h, h - 60], aspect="equal")
bar = np.where(im[h - 2, :] > 120)[0]; bar = bar[bar > w - 330]
ax[0].annotate("", xy=(bar.min(), h - 14), xytext=(bar.max(), h - 14), arrowprops=dict(arrowstyle="<->", color="tab:red"))
ax[0].text(bar.mean(), h - 20, f"{bar.max() - bar.min() + 1} px visible", color="tab:red", ha="center", fontsize=8)
ax[0].set_title("Frame 73, lower-right corner (burned-in '3 mm' bar)", fontsize=9); ax[0].set_xlabel("x (px)"); ax[0].set_ylabel("y (px)")
rows = []
for L in (187, 268):
    rows.append(dict(bar_length_px=L, um_per_px=3000 / L, note="visible length (bar touches right edge)" if L == 187 else "length implied by 11.2 um/px (would extend past x=863)"))
sc = pd.DataFrame(rows); sc.to_csv(SRC / "Fig_S3_source_data.csv", index=False)
ax[1].axis("off"); ax[1].table(cellText=[[f"{r.bar_length_px}", f"{r.um_per_px:.2f}"] for r in sc.itertuples()], colLabels=["Bar length (px)", "um/px (3 mm bar)"], loc="center", cellLoc="center")
ax[1].set_title("Scale implied by a 3 mm bar", fontsize=9)
fig.suptitle("Fig. S3  The scale bar is clipped, so the scale cannot be read from the frame", y=1.04, fontsize=10)
save(fig, "Fig_S3_scale_bar_evidence")
print("wrote Fig_S1..S3")
