#!/usr/bin/env bash
# Runs the authors' analysis/plot scripts (path constants only adapted) on the supplied data.
# Usage (repo root):  bash SOURCE_CODE/legacy_adapted/run_all_legacy_adapted.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
export BUBBLE_DATA_DIR="$ROOT/DATA/PROCESSED_DATA/legacy_schema"
export BUBBLE_OUT_DIR="$ROOT/DATA/DERIVED_DATA/legacy_regenerated"
export BUBBLE_IMG_DIR="$BUBBLE_OUT_DIR/_img_staging"   # rgb (raw) + mask (processed) side by side; raw folder stays untouched
mkdir -p "$BUBBLE_OUT_DIR" "$BUBBLE_IMG_DIR"
cp "$ROOT"/DATA/RAW_DATA/system_C_high_resolution_micrographs/*_rgb.png "$BUBBLE_IMG_DIR/"
cp "$ROOT"/DATA/PROCESSED_DATA/micrograph_masks/*_mask.png "$BUBBLE_IMG_DIR/"
python3 "$ROOT/SOURCE_CODE/calculations/compute_manuscript_statistics.py"   # creates legacy_schema CSVs
cd "$ROOT/SOURCE_CODE/legacy_adapted"
for s in recompute_all_statistics deep_single_bubble_analysis mineral_calculations_from_images multi_bubble_analysis generate_figures; do
  echo "== $s"; python3 "$s.py" > "$BUBBLE_OUT_DIR/$s.log" 2>&1 && echo ok || { echo FAILED; tail -5 "$BUBBLE_OUT_DIR/$s.log"; }
done
