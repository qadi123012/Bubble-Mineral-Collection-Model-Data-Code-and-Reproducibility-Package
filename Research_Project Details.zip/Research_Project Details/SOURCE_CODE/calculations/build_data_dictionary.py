#!/usr/bin/env python3
"""Builds DATA/DATA_DICTIONARY.xlsx: one row per column of every dataset in DATA/ (type, unit, definition, origin, manuscript use)."""
from pathlib import Path
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
ROOT = Path(__file__).resolve().parents[2]
K = {  # bubble_kinematics_and_particles.csv
 "frame": ("int", "-", "Frame index of the exported sequence (frames 25-120 analysed; 0-24 not analysed)", "S3.3"),
 "found": ("bool", "-", "Bubble segmentation succeeded", "S3.4"),
 "area_px": ("float", "px^2", "Area of the convex-hull contour of the bubble", "S4.2"),
 "eq_diam_px": ("float", "px", "Equivalent diameter 2*sqrt(area/pi), RAW per frame", "S4.2, Fig 3"),
 "ellipse_major_px": ("float", "px", "Major axis of cv2.fitEllipse on the hull", "S4.2"),
 "ellipse_minor_px": ("float", "px", "Minor axis of cv2.fitEllipse on the hull", "S4.2"),
 "ellipse_angle_deg": ("float", "deg", "Ellipse orientation (OpenCV convention)", "-"),
 "centroid_x": ("float", "px", "Hull centroid x (image coordinates), RAW", "S4.3"),
 "centroid_y": ("float", "px", "Hull centroid y (image y increases downward), RAW", "S4.3"),
 "tail_severed_px": ("float", "px^2", "Area removed by the tail-severing step", "S3.4"),
 "t_frame": ("int", "frame", "Frame offset from frame 25", "-"),
 "vx_px_per_frame": ("float", "px/frame", "Frame-differenced centroid velocity x (first row NaN)", "-"),
 "vy_px_per_frame": ("float", "px/frame", "Frame-differenced centroid velocity y", "-"),
 "v_rise_px_per_frame": ("float", "px/frame", "Frame-differenced rise velocity (-vy), RAW. In legacy_schema/ this column is replaced by the Savitzky-Golay derivative", "S4.3"),
 "speed_px_per_frame": ("float", "px/frame", "Magnitude of frame-differenced centroid velocity", "-"),
 "path_length_px": ("float", "px", "Cumulative raw path length", "S4.3"),
 "net_rise_px": ("float", "px", "Raw centroid_y[0] - centroid_y[t]", "S4.3"),
 "net_horiz_px": ("float", "px", "Raw centroid_x[t] - centroid_x[0]", "S4.3"),
 "aspect_ratio": ("float", "-", "ellipse_major / ellipse_minor", "S4.2"),
 "n_particles_visible": ("int", "-", "Number of surface features detected in the eroded bubble mask (an image proxy for attached particles)", "S4.4"),
 "particle_area_px": ("int", "px^2", "Total area of accepted features", "S4.4"),
 "bubble_inner_area_px": ("int", "px^2", "Area of the 15-px-eroded bubble mask", "S4.4"),
 "particle_coverage_pct": ("float", "%", "100 * particle_area_px / bubble_inner_area_px", "S4.4"),
 "particle_mean_diam_px": ("float", "px", "Mean feature diameter in the frame", "S4.4"),
 "particle_smd_px": ("float", "px", "Sauter mean diameter of features in the frame", "S4.4"),
 "particle_n": ("int", "-", "Feature count used for the per-frame size statistics", "-"),
 "bubble_to_particle_ratio_mean": ("float", "-", "eq_diam_px / particle_mean_diam_px (raw diameter)", "S4.4"),
 "bubble_to_particle_ratio_smd": ("float", "-", "eq_diam_px / particle_smd_px (raw diameter)", "S4.4"),
 "eq_diam_px_sg": ("float", "px", "[legacy_schema only] Savitzky-Golay(11,3,interp) of eq_diam_px", "S4.2"),
 "centroid_x_sg": ("float", "px", "[legacy_schema only] Savitzky-Golay of centroid_x", "S4.3"),
 "centroid_y_sg": ("float", "px", "[legacy_schema only] Savitzky-Golay of centroid_y", "S4.3"),
 "v_rise_px_per_frame_raw": ("float", "px/frame", "[legacy_schema only] frame-differenced rise velocity", "-"),
}
P = {"frame": ("int", "-", "Frame of detection", ""), "particle_x": ("float", "px", "Feature centroid x", "S4.6"), "particle_y": ("float", "px", "Feature centroid y", "S4.6"),
     "particle_area_px": ("int", "px^2", "Feature area (2-200)", "S4.4"), "particle_eq_diam_px": ("float", "px", "2*sqrt(area/pi)", "S4.4"),
     "leading_trailing_proj_px": ("float", "px", "Offset from bubble centroid projected on the mean travel direction (frame-differenced direction; manuscript uses the smoothed direction)", "S4.6"),
     "is_leading": ("bool", "-", "projection > 0", "S4.6")}
V = {"frame_a": ("int", "-", "First frame of the PIV pair", ""), "frame_b": ("int", "-", "Second frame", ""), "n_valid_vectors": ("int", "-", "Vectors passing S/N > 1.25 and outside the bubble mask", "S4.5"),
     "n_total_vectors": ("int", "-", "Interrogation windows per pair (1590)", "S4.5"), "mean_u_px": ("float", "px/frame", "Mean horizontal displacement of valid vectors", "S4.5"),
     "mean_v_px": ("float", "px/frame", "Mean vertical displacement (+ downward)", "S4.5"), "std_u_px": ("float", "px/frame", "SD (n) of u over valid vectors", "S4.5"),
     "std_v_px": ("float", "px/frame", "SD (n) of v", "S4.5"), "mean_speed_px": ("float", "px/frame", "Mean vector magnitude", "S4.5"), "max_speed_px": ("float", "px/frame", "Maximum vector magnitude", "S4.5")}
X = {"frame": ("int", "-", "Frame", ""), "ba_found": ("bool", "-", "Bubble Analyser found the bubble", "S4.7"), "ba_area_px": ("int", "px^2", "Area of the Bubble Analyser label", "S4.7"),
     "ba_eq_diam_px": ("float", "px", "Equivalent diameter from Bubble Analyser 2.0 NormalWatershed (defaults)", "S4.7"), "my_eq_diam_px": ("float", "px", "This pipeline's RAW eq_diam_px", "S4.7")}
Q = {"frame": ("int", "-", "", ""), "d_raw_px": ("float", "px", "= eq_diam_px", "Fig 3"), "d_sg_px": ("float", "px", "Savitzky-Golay smoothed diameter", "S4.2"), "cx_sg_px": ("float", "px", "", "S4.3"),
     "cy_sg_px": ("float", "px", "", "S4.3"), "v_rise_sg_px_per_frame": ("float", "px/frame", "SG derivative", "S4.3"), "aspect_ratio": ("float", "-", "", "S4.2"),
     "n_features": ("int", "-", "", "S4.4"), "coverage_pct": ("float", "%", "", "S4.4"), "assumed_mass_ng": ("float", "ng", "Sum over features of (pi/6)(d*11.2um)^3*3000 kg/m3. ASSUMPTION-DEPENDENT", "S4.9"),
     "bpr_smd": ("float", "-", "d_sg_px / particle_smd_px", "S4.4")}
sets = [("supplied_csv/bubble_kinematics_and_particles.csv", "PROCESSED", "Per-frame bubble tracking + feature statistics (author-supplied; regenerated bit-for-bit by regenerate_csvs_from_frames.py)", K),
        ("supplied_csv/individual_particles.csv", "PROCESSED", "One row per detected surface feature (5,673)", P), ("supplied_csv/piv_summary.csv", "PROCESSED", "One row per frame pair (95)", V),
        ("supplied_csv/bubble_analyser_crosscheck.csv", "PROCESSED", "Cross-check with Bubble Analyser 2.0 (96)", X),
        ("per_frame_processed.csv", "DERIVED", "Per-frame derived table created by compute_manuscript_statistics.py", Q)]
wb = Workbook(); ws = wb.active; ws.title = "Datasets"
H = Font(name="Arial", bold=True, color="FFFFFF"); F = PatternFill("solid", fgColor="1F3864"); B = Font(name="Arial", size=10)
def hdr(w, cols, widths):
    for j, (c, wd) in enumerate(zip(cols, widths), 1):
        x = w.cell(row=1, column=j, value=c); x.font, x.fill = H, F; w.column_dimensions[chr(64 + j)].width = wd
hdr(ws, ["File (under DATA/PROCESSED_DATA/ unless noted)", "Category", "Description", "Rows", "Columns"], [52, 12, 100, 8, 9])
rows = [("RAW_DATA/system_C_single_bubble_frames/frame_XXXXXXXX.jpg", "RAW", "121 exported video frames, 864x496 px, 8-bit RGB JPEG (frames 0-120). Burned-in readout 'up/s' and '3 mm' bar. Original video NOT supplied.", 121, 3),
        ("RAW_DATA/system_C_high_resolution_micrographs/IMG_94xx_rgb.png", "RAW", "Four 2400x1600 px micrographs (9423, 9432, 9433, 9434). IMG_9431 (cited in manuscript) was not supplied. No physical scale.", 4, 3),
        ("PROCESSED_DATA/micrograph_masks/IMG_94xx_mask.png", "PROCESSED", "Labelled bubble masks (deep-learning/BubMask or regenerated); not used for any manuscript number", 4, 1),
        ("DERIVED_DATA/manuscript_statistics.json", "DERIVED", "216 statistics recomputed by compute_manuscript_statistics.py", 216, 2),
        ("DERIVED_DATA/sensitivity_fps_scale.csv", "DERIVED", "NEW: fps x scale sensitivity of the model chain", 6, 16),
        ("DERIVED_DATA/implied_induction_times.csv", "DERIVED", "NEW: t_i implied by Ea at t_c = 100 ms", 3, 3),
        ("DERIVED_DATA/legacy_supplied_stale/*.json", "DERIVED (STALE)", "Author JSON files; computed at 500 fps (Re = 11.3) and with unit/provenance errors; DO NOT cite (see AUDIT/CORRECTION_LOG.md)", 5, 0),
        ("DERIVED_DATA/legacy_regenerated/", "DERIVED", "Outputs of the authors' scripts re-run here (JSON equal to the supplied ones except IMG_9431 omission)", 0, 0),
        ("DERIVED_DATA/bubmask_deep_learning_outputs/", "DERIVED", "BubMask deep-learning bubble-size outputs for IMG_9423-9434; unit labels in the xlsx say mm but values are um-scale; NOT used in the manuscript", 4, 0)]
for i, r in enumerate(rows, 2):
    for j, v in enumerate(r, 1):
        c = ws.cell(row=i, column=j, value=v); c.font = B; c.alignment = Alignment(wrap_text=True, vertical="top")
for fn, cat, desc, cols in sets:
    df = pd.read_csv(ROOT / "DATA/PROCESSED_DATA" / fn)
    for j, v in enumerate((fn, cat, desc, len(df), len(df.columns)), 1):
        ws.cell(row=ws.max_row + 1, column=j, value=v).font = B
    w = wb.create_sheet(fn.split("/")[-1][:28]); hdr(w, ["Column", "Type", "Unit", "Definition", "Manuscript use"], [30, 8, 10, 100, 16])
    for c in df.columns:
        t, u, d, m = cols.get(c, ("?", "?", "", ""))
        for j, v in enumerate((c, t, u, d, m), 1):
            x = w.cell(row=w.max_row + 1 if w.max_row > 1 or w.cell(row=2, column=1).value else 2, column=j, value=v); x.font = B; x.alignment = Alignment(wrap_text=True, vertical="top")
out = ROOT / "DATA/DATA_DICTIONARY.xlsx"; wb.save(out)
missing = [(fn, c) for fn, _, _, cols in sets for c in pd.read_csv(ROOT / "DATA/PROCESSED_DATA" / fn).columns if c not in cols]
print("saved", out, "| undocumented columns:", missing)
