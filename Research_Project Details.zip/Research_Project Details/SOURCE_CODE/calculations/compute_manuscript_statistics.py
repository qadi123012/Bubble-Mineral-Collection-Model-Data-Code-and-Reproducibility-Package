#!/usr/bin/env python3
"""
compute_manuscript_statistics.py
================================
Recompute EVERY quantitative statistic reported for system C (96-frame single-bubble sequence) directly from
the four CSV datasets, using only relative paths and the parameters in
COMPUTATIONAL_MODELS/CONFIGURATION/parameters.json.

Inputs  : DATA/PROCESSED_DATA/supplied_csv/{bubble_kinematics_and_particles,individual_particles,piv_summary,
          bubble_analyser_crosscheck}.csv
Outputs : DATA/PROCESSED_DATA/legacy_schema/*.csv   (the 4 CSVs + Savitzky-Golay columns, legacy column names)
          DATA/PROCESSED_DATA/per_frame_processed.csv (one row per frame, all derived per-frame quantities)
          DATA/DERIVED_DATA/manuscript_statistics.json (flat dict, one key per statistic)

Conventions (documented because the manuscript does not state them):
  * "sd" = POPULATION standard deviation (ddof = 0), the convention of the legacy scripts; sample SD (ddof = 1)
    is stored alongside for the key quantities as "<name>_sd1".
  * Savitzky-Golay filter: window 11, order 3, mode 'interp' (recovered, see parameters.json).
  * Image y increases downward; rise = -dy.

Run:  python SOURCE_CODE/calculations/compute_manuscript_statistics.py
"""
import json
import math
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats as sstats
from scipy.signal import find_peaks, savgol_filter

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "COMPUTATIONAL_MODELS" / "single_bubble_collection_model"))
import collection_model as cm  # noqa: E402

CFG = json.load(open(ROOT / "COMPUTATIONAL_MODELS" / "CONFIGURATION" / "parameters.json"))
IN = ROOT / "DATA" / "PROCESSED_DATA" / "supplied_csv"
LEG = ROOT / "DATA" / "PROCESSED_DATA" / "legacy_schema"
LEG.mkdir(parents=True, exist_ok=True)
OUT = ROOT / "DATA" / "DERIVED_DATA"
OUT.mkdir(parents=True, exist_ok=True)

UM = CFG["optics"]["um_per_px"]
FPS = CFG["optics"]["fps"]
SGW, SGO = CFG["smoothing"]["window_length"], CFG["smoothing"]["polyorder"]
FL = CFG["fluid_assumed_pure_water_23C"]
RHO_P = CFG["collection_model"]["rho_p_kg_m3"]

S = {}  # statistics


def put(k, v):
    S[k] = float(v) if isinstance(v, (np.floating, float, np.integer, int)) and not isinstance(v, bool) else v


def sg(a, deriv=0):
    return savgol_filter(np.asarray(a, float), SGW, SGO, deriv=deriv, mode="interp")


def sd0(a):
    return float(np.std(a, ddof=0))


def sd1(a):
    return float(np.std(a, ddof=1))


# ------------------------------------------------------------------ load
kin = pd.read_csv(IN / "bubble_kinematics_and_particles.csv")
par = pd.read_csv(IN / "individual_particles.csv")
piv = pd.read_csv(IN / "piv_summary.csv")
xch = pd.read_csv(IN / "bubble_analyser_crosscheck.csv")
assert len(kin) == 96 and len(par) == 5673 and len(piv) == 95 and len(xch) == 96, "unexpected dataset sizes"

# ------------------------------------------------------------------ legacy-schema CSVs (adds *_sg columns)
leg = kin.copy()
leg["eq_diam_px_sg"] = sg(kin.eq_diam_px)
leg["centroid_x_sg"] = sg(kin.centroid_x)
leg["centroid_y_sg"] = sg(kin.centroid_y)
leg["v_rise_px_per_frame_raw"] = kin["v_rise_px_per_frame"]       # frame-differenced (first row NaN)
leg["v_rise_px_per_frame"] = -sg(kin.centroid_y, 1)               # SG derivative = manuscript's "filtered rise velocity"
leg.to_csv(LEG / "bubble_kinematics_and_particles.csv", index=False)
for f in ("individual_particles.csv", "piv_summary.csv", "bubble_analyser_crosscheck.csv"):
    shutil.copy(IN / f, LEG / f)

frames = kin.frame.values
d_raw, d_sg = kin.eq_diam_px.values, leg.eq_diam_px_sg.values
cx, cy = leg.centroid_x_sg.values, leg.centroid_y_sg.values

# ------------------------------------------------------------------ 1. bubble diameter
put("d_raw_mean_px", d_raw.mean()); put("d_raw_sd_px", sd0(d_raw)); put("d_raw_sd1_px", sd1(d_raw))
put("d_raw_min_px", d_raw.min()); put("d_raw_max_px", d_raw.max())
put("d_sg_mean_px", d_sg.mean()); put("d_sg_sd_px", sd0(d_sg)); put("d_sg_min_px", d_sg.min()); put("d_sg_max_px", d_sg.max())
put("d_sg_cv_pct", 100 * sd0(d_sg) / d_sg.mean())
resid = d_raw - d_sg
put("d_noise_floor_px", sd0(resid)); put("d_noise_floor_pct", 100 * sd0(resid) / d_sg.mean())
put("d_sg_peak_to_peak_px", d_sg.max() - d_sg.min()); put("d_raw_peak_to_peak_px", d_raw.max() - d_raw.min())
put("d_sg_p2p_over_noise", (d_sg.max() - d_sg.min()) / sd0(resid)); put("d_raw_p2p_over_noise", (d_raw.max() - d_raw.min()) / sd0(resid))
put("d_mean_mm", d_sg.mean() * UM / 1e3); put("d_min_mm", d_sg.min() * UM / 1e3); put("d_max_mm", d_sg.max() * UM / 1e3)
put("d_sd_mm_frame_to_frame", sd0(d_sg) * UM / 1e3)
put("d_combined_unc_mm", math.hypot(CFG["optics"]["scale_relative_uncertainty"] * d_sg.mean() * UM / 1e3, sd0(d_sg) * UM / 1e3))

# ------------------------------------------------------------------ 2. Bubble Analyser cross-check
ba, mine = xch.ba_eq_diam_px.values, xch.my_eq_diam_px.values
put("ba_frames_found", int(xch.ba_found.sum()))
put("ba_mean_px", ba.mean()); put("ba_sd_px", sd0(ba)); put("ba_sd1_px", sd1(ba))
put("ba_bias_signed_px", (ba - mine).mean()); put("ba_mean_abs_diff_px", np.abs(ba - mine).mean())
put("ba_mean_abs_diff_pct", 100 * (np.abs(ba - mine) / mine).mean()); put("ba_all_negative", bool(np.all(ba < mine)))
r, _ = sstats.pearsonr(mine, ba); sl, ic, *_ = sstats.linregress(mine, ba)
put("ba_pearson_r", r); put("ba_r2", r * r); put("ba_slope", sl); put("ba_intercept_px", ic)
put("ba_slope_from_summary_stats", r * sd0(ba) / sd0(mine))            # reproducibility claim in the manuscript
put("ba_slope_from_manuscript_printed_sds", 0.975 * 2.1 / 2.42)         # what the printed SDs (2.1, 2.42) would give

# ------------------------------------------------------------------ 3. trajectory
rise, horiz = cy[0] - cy[-1], cx[-1] - cx[0]
path = float(np.hypot(np.diff(cx), np.diff(cy)).sum()); net = math.hypot(rise, horiz)
put("net_rise_px", rise); put("net_horiz_px", horiz); put("path_px", path); put("net_disp_px", net)
put("verticality_ratio", rise / path); put("straightness_index", net / path)
put("drift_angle_deg", math.degrees(math.atan(horiz / rise)))
put("net_rise_mm", rise * UM / 1e3); put("path_mm", path * UM / 1e3); put("net_disp_mm", net * UM / 1e3)
put("window_ms", (len(kin) - 1) / FPS * 1e3)
put("fov_x_mm", CFG["optics"]["image_width_px"] * UM / 1e3); put("fov_y_mm", CFG["optics"]["image_height_px"] * UM / 1e3)

# ------------------------------------------------------------------ 4. rise velocity
v = leg.v_rise_px_per_frame.values
put("v_px_frame_mean", v.mean()); put("v_px_frame_sd", sd0(v)); put("v_px_frame_min", v.min()); put("v_px_frame_max", v.max())
put("v_raw_px_frame_mean", np.nanmean(leg.v_rise_px_per_frame_raw.values))
put("v_mm_s_mean", v.mean() * UM * 1e-3 * FPS); put("v_mm_s_sd", sd0(v) * UM * 1e-3 * FPS)

# ------------------------------------------------------------------ 5. shape + oscillation
asp = (kin.ellipse_major_px / kin.ellipse_minor_px).values
put("aspect_mean", asp.mean()); put("aspect_sd", sd0(asp)); put("aspect_sd1", sd1(asp)); put("aspect_min", asp.min()); put("aspect_max", asp.max())
put("major_mean_px", kin.ellipse_major_px.mean()); put("major_sd_px", sd0(kin.ellipse_major_px))
put("minor_mean_px", kin.ellipse_minor_px.mean()); put("minor_sd_px", sd0(kin.ellipse_minor_px))
c = asp - asp.mean()
pk, _ = find_peaks(c, height=0.005, distance=3); tr, _ = find_peaks(-c, height=0.005, distance=3)
put("aspect_peaks_legacy_raw", len(pk)); put("aspect_troughs_legacy_raw", len(tr))
asg = sg(asp); cs = asg - asg.mean()
pk2, _ = find_peaks(cs); tr2, _ = find_peaks(-cs)
put("aspect_peaks_sg", len(pk2)); put("aspect_troughs_sg", len(tr2))
ext = np.sort(np.r_[pk2, tr2]); iv = np.diff(ext)
put("aspect_extreme_spacing_min_sg", iv.min()); put("aspect_extreme_spacing_max_sg", iv.max()); put("aspect_extreme_spacing_mean_sg", iv.mean())
# objective alternative: Hann-windowed periodogram of the linearly detrended aspect-ratio series
n = len(asp); t = np.arange(n)
det = asp - np.polyval(np.polyfit(t, asp, 1), t)
spec = np.abs(np.fft.rfft(det * np.hanning(n))) ** 2; freq = np.fft.rfftfreq(n, d=1.0)
k0 = 1 + int(np.argmax(spec[1:])); put("aspect_fft_dominant_period_frames", 1.0 / freq[k0])
put("aspect_fft_dominant_period_ms", 1.0 / freq[k0] / FPS * 1e3)

# ------------------------------------------------------------------ 6. dimensionless groups (manuscript scenario)
d_m, v_ms = d_sg.mean() * UM * 1e-6, v.mean() * UM * 1e-6 * FPS
sc = cm.Scenario(d_b=d_m, v_b=v_ms, rho_l=FL["rho_l_kg_m3"], rho_g=FL["rho_g_kg_m3"], mu_l=FL["mu_l_Pa_s"], sigma=FL["sigma_N_m"],
                 d_p=CFG["collection_model"]["d_p_um"] * 1e-6, rho_p=RHO_P, e_a=CFG["collection_model"]["E_a"], e_s=CFG["collection_model"]["E_s"],
                 h_c=rise * UM * 1e-6, solids_kg_m3=CFG["collection_model"]["solids_kg_m3"])
ev = sc.evaluate()
for k, val in ev.items():
    put(f"model_{k}", val)
put("v_m_s", v_ms); put("d_m", d_m)
put("Re_unc_pct_scale", 200 * CFG["optics"]["scale_relative_uncertainty"]); put("We_unc_pct_scale", 300 * CFG["optics"]["scale_relative_uncertainty"])
put("Re_unc_pct_velocity", 100 * sd0(v) / v.mean())
put("Cd_implied", cm.implied_drag_coefficient(FL["rho_l_kg_m3"], FL["rho_g_kg_m3"], v_ms, d_m))
put("v_rigid_sphere_m_s", cm.schiller_naumann_terminal_velocity(FL["rho_l_kg_m3"], FL["rho_g_kg_m3"], FL["mu_l_Pa_s"], d_m))
re_d = ev["Re"]; put("Cd_rigid_at_Re", 24 / re_d * (1 + 0.15 * re_d ** 0.687))
put("lamb_f2_Hz", cm.lamb_bubble_frequency_hz(FL["sigma_N_m"], FL["rho_l_kg_m3"], d_m / 2))
for es in (0.80, 0.95):
    e = ev["Ec"] * ev["Ea"] * es
    put(f"Ecoll_Es_{int(es*100)}", e); put(f"Np_Es_{int(es*100)}", cm.particles_per_bubble(e, d_m, sc.d_p, sc.h_c, ev["Cp_per_m3"]))

# ------------------------------------------------------------------ 7. PIV
su, sv = piv.std_u_px.values, piv.std_v_px.values
put("piv_u_mean", piv.mean_u_px.mean()); put("piv_u_sd", sd0(piv.mean_u_px)); put("piv_v_mean", piv.mean_v_px.mean()); put("piv_v_sd", sd0(piv.mean_v_px))
put("piv_rms_u", su.mean()); put("piv_rms_v", sv.mean())
put("piv_tke_from_mean_rms", 0.5 * (su.mean() ** 2 + sv.mean() ** 2)); put("piv_tke_mean_of_pairs", (0.5 * (su ** 2 + sv ** 2)).mean())
put("piv_speed_mean", piv.mean_speed_px.mean()); put("piv_speed_sd", sd0(piv.mean_speed_px)); put("piv_speed_ratio", v.mean() / piv.mean_speed_px.mean())
put("piv_valid_vectors_mean", piv.n_valid_vectors.mean()); put("piv_total_vectors", piv.n_total_vectors.iloc[0])

# ------------------------------------------------------------------ 8. features: counts, coverage, size, BPR
cnt, cov = kin.n_particles_visible.values, kin.particle_coverage_pct.values
put("count_mean", cnt.mean()); put("count_sd", sd0(cnt)); put("count_sd1", sd1(cnt)); put("count_min", cnt.min()); put("count_max", cnt.max()); put("count_cv_pct", 100 * sd0(cnt) / cnt.mean())
put("coverage_mean", cov.mean()); put("coverage_sd", sd0(cov))
for nm, y in (("count", cnt), ("coverage", cov)):
    s_, i_, r_, p_, _ = sstats.linregress(frames, y); put(f"{nm}_slope", s_); put(f"{nm}_r", r_); put(f"{nm}_p_nominal", p_)
dp = par.particle_eq_diam_px.values
smd = float((dp ** 3).sum() / (dp ** 2).sum())
put("n_features", len(dp)); put("feat_mean_px", dp.mean()); put("feat_sd_px", sd0(dp)); put("feat_median_px", np.median(dp)); put("feat_min_px", dp.min()); put("feat_max_px", dp.max()); put("feat_smd_px", smd)
put("feat_min_from_filter_px", 2 * math.sqrt(2 / math.pi)); put("feat_max_from_filter_px", 2 * math.sqrt(200 / math.pi))
put("bpr_pooled_smd", d_sg.mean() / smd); put("bpr_pooled_mean", d_sg.mean() / dp.mean())
bpr_f = d_sg / kin.particle_smd_px.values
put("bpr_frame_mean", bpr_f.mean()); put("bpr_frame_sd", sd0(bpr_f))
s_, i_, r_, p_, _ = sstats.linregress(frames, bpr_f); put("bpr_frame_slope", s_); put("bpr_frame_r", r_)

# ------------------------------------------------------------------ 9. leading / trailing
mvx, mvy = np.diff(cx).mean(), np.diff(cy).mean(); nrm = math.hypot(mvx, mvy); ux, uy = mvx / nrm, mvy / nrm
cxm = dict(zip(frames, cx)); cym = dict(zip(frames, cy)); dm = dict(zip(frames, d_sg))
proj = np.array([(r.particle_x - cxm[int(r.frame)]) * ux + (r.particle_y - cym[int(r.frame)]) * uy for r in par.itertuples()])
put("lead_n", int((proj > 0).sum())); put("trail_n", int((proj < 0).sum())); put("lead_pct", 100 * (proj > 0).mean()); put("trail_pct", 100 * (proj < 0).mean()); put("proj_mean_px", proj.mean())
put("lead_n_csv_column", int(par.is_leading.sum()))
rad = np.array([math.hypot(r.particle_x - cxm[int(r.frame)], r.particle_y - cym[int(r.frame)]) / (dm[int(r.frame)] / 2) for r in par.itertuples()])
put("radial_mean", rad.mean()); put("radial_median", np.median(rad)); put("radial_pct_gt_0p8", 100 * (rad > 0.8).mean()); put("radial_pct_lt_0p8", 100 * (rad < 0.8).mean())
put("radial_pct_gt_1p2", 100 * (rad > 1.2).mean())

# ------------------------------------------------------------------ 10. detection dynamics and persistence
by = {int(f): g for f, g in par.groupby("frame")}
sf = sorted(by); n_arr = np.array([len(by[f]) for f in sf]); dn = np.diff(n_arr)
put("dn_increase", int((dn > 0).sum())); put("dn_decrease", int((dn < 0).sum())); put("dn_stable", int((dn == 0).sum())); put("dn_max", dn.max()); put("dn_min", dn.min())
rel = {f: np.c_[by[f].particle_x.values - cxm[f], by[f].particle_y.values - cym[f]] for f in sf}
att = mat = 0
for a, b in zip(sf[:-1], sf[1:]):
    for p in rel[a]:
        att += 1
        if np.min(np.hypot(*(rel[b] - p).T)) < 5:
            mat += 1
put("persist_attempts", att); put("persist_matches", mat); put("persist_pct", 100 * mat / att)

# ------------------------------------------------------------------ 11. illustrative mineral load (ASSUMPTION-DEPENDENT)
m_ng = (math.pi / 6) * (dp * UM * 1e-6) ** 3 * RHO_P * 1e12
put("feat_dmean_um", dp.mean() * UM); put("feat_dsmd_um", smd * UM)
put("feat_mass_mean_ng", m_ng.mean()); put("feat_mass_median_ng", np.median(m_ng)); put("feat_mass_min_ng", m_ng.min()); put("feat_mass_max_ng", m_ng.max())
ss = np.sort(m_ng)[::-1]; q = int(round(0.25 * len(ss))); put("feat_mass_top25pct_share_pct", 100 * ss[:q].sum() / ss.sum())
put("feat_mass_total_ug", m_ng.sum() / 1e3)
pm = pd.Series(m_ng, index=par.index).groupby(par.frame).sum().reindex(frames, fill_value=0.0)
put("frame_mass_mean_ng", pm.mean()); put("frame_mass_sd_ng", sd0(pm)); put("frame_mass_min_ng", pm.min()); put("frame_mass_max_ng", pm.max())
s_, i_, r_, p_, _ = sstats.linregress(frames, pm.values); put("frame_mass_slope_ng", s_); put("frame_mass_r", r_); put("frame_mass_p_nominal", p_)
qn = 1 - mat / att
put("unique_mass_U_ug_q_from_data", (pm.loc[25] + qn * pm.loc[26:120].sum()) / 1e3)
put("unique_mass_U_ug_q_0p148", (pm.loc[25] + 0.148 * pm.loc[26:120].sum()) / 1e3)
for f in (36, 39, 45, 49, 55, 60):
    put(f"frame_mass_f{f}_ug", pm.loc[f] / 1e3)
bub_vol_mm3 = math.pi / 6 * (d_m * 1e3) ** 3; put("bubble_volume_mm3", bub_vol_mm3); put("displaced_liquid_mg", bub_vol_mm3 * FL["rho_l_kg_m3"] * 1e-3)
put("load_over_displaced_pct", 100 * pm.mean() * 1e-6 / (bub_vol_mm3 * FL["rho_l_kg_m3"] * 1e-3))
put("neutral_buoyancy_factor", RHO_P / (RHO_P - FL["rho_l_kg_m3"]))
put("rise_per_frame_um_from_mean_v", v.mean() * UM); put("rise_per_frame_um_from_net_rise", rise * UM / (len(frames) - 1))
put("mass_flux_ug_per_mm", pm.mean() * 1e-3 / (v.mean() * UM * 1e-3))                       # manuscript convention (mean SG velocity)
put("mass_flux_ug_per_mm_from_net_rise", pm.mean() * 1e-3 / (rise * UM / (len(frames) - 1) * 1e-3))
put("count_to_Np_ratio", cnt.mean() / ev["Np"]); put("count_to_Np_ratio_Es80", cnt.mean() / S["Np_Es_80"]); put("count_to_Np_ratio_Es95", cnt.mean() / S["Np_Es_95"])

# ------------------------------------------------------------------ 12. figure-10/11 stage values
def stage(fr):
    i = int(np.where(frames == fr)[0][0]); return i
for fr in (36, 60):
    i = stage(fr); put(f"stage_f{fr}_d_sg_px", d_sg[i]); put(f"stage_f{fr}_y_sg_px", cy[i])
sel = (frames >= 36) & (frames <= 60)
six = np.isin(frames, (36, 39, 45, 49, 55, 60))
put("six_stage_count_min", cnt[six].min()); put("six_stage_count_max", cnt[six].max()); put("six_stage_cov_min", cov[six].min()); put("six_stage_cov_max", cov[six].max())
put("f36_60_count_min", cnt[sel].min()); put("f36_60_count_max", cnt[sel].max()); put("f36_60_cov_min", cov[sel].min()); put("f36_60_cov_max", cov[sel].max())
for fr in (25, 44, 63, 83, 102, 120, 36, 39, 45, 49, 55, 60):
    put(f"rise_pct_f{fr}", 100 * (cy[0] - cy[stage(fr)]) / rise)

# ------------------------------------------------------------------ per-frame table
pf = pd.DataFrame(dict(frame=frames, d_raw_px=d_raw, d_sg_px=d_sg, cx_sg_px=cx, cy_sg_px=cy, v_rise_sg_px_per_frame=v, aspect_ratio=asp,
                       n_features=cnt, coverage_pct=cov, assumed_mass_ng=pm.values, bpr_smd=bpr_f))
pf.to_csv(ROOT / "DATA" / "PROCESSED_DATA" / "per_frame_processed.csv", index=False)
json.dump(S, open(OUT / "manuscript_statistics.json", "w"), indent=1)
print(f"wrote {len(S)} statistics -> {OUT / 'manuscript_statistics.json'}")
