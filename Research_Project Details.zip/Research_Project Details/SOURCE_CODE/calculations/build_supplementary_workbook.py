#!/usr/bin/env python3
"""
build_supplementary_workbook.py
Builds SUPPLEMENTARY_INFORMATION/Supplementary_Tables.xlsx with LIVE Excel formulas:
change an input on ST1_Inputs (blue cells) and ST2/ST3 recalculate.
Run after compute_manuscript_statistics.py and verify_manuscript_claims.py.
Then recalculate/validate:  python /path/to/skills/xlsx/scripts/recalc.py SUPPLEMENTARY_INFORMATION/Supplementary_Tables.xlsx
"""
import csv
import json
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[2]
CFG = json.load(open(ROOT / "COMPUTATIONAL_MODELS/CONFIGURATION/parameters.json"))
pf = pd.read_csv(ROOT / "DATA/PROCESSED_DATA/per_frame_processed.csv")
par = pd.read_csv(ROOT / "DATA/PROCESSED_DATA/supplied_csv/individual_particles.csv")
claims = list(csv.DictReader(open(ROOT / "AUDIT/claim_verification.csv")))
imp = pd.read_csv(ROOT / "DATA/DERIVED_DATA/implied_induction_times.csv")

F = "Arial"
H = Font(name=F, bold=True, color="FFFFFF", size=10); HF = PatternFill("solid", fgColor="1F3864")
B = Font(name=F, size=10); BB = Font(name=F, size=10, bold=True); INP = Font(name=F, size=10, color="0000FF")
WARN = PatternFill("solid", fgColor="FFF2CC"); BAD = PatternFill("solid", fgColor="F8CBAD")
wb = Workbook()


def sheet(name, headers, widths, first=False):
    ws = wb.active if first else wb.create_sheet()
    ws.title = name
    for j, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(row=1, column=j, value=h); c.font, c.fill = H, HF; c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.freeze_panes = "A2"
    return ws


def put(ws, r, vals, fonts=None, wrap=True):
    for j, v in enumerate(vals, 1):
        c = ws.cell(row=r, column=j, value=v); c.font = (fonts or {}).get(j, B); c.alignment = Alignment(wrap_text=wrap, vertical="top")


# ------------------------------------------------------------ README
ws = sheet("README", ["Item", "Description"], [26, 120], first=True)
readme = [
 ("Purpose", "Supplementary tables for 'Single-bubble mineral collection model' (Final_Manuscript_Cl.docx). Every calculated cell is a live formula."),
 ("Colour code", "Blue font = input you may change (ST1_Inputs). Black = formula or fixed data. Yellow fill = UNVERIFIED input. Red fill = claim that FAILS verification."),
 ("ST1_Inputs", "All scenario inputs with unit, source and verification status. Per-frame means are formulas on ST5."),
 ("ST2_Model_Chain", "Re, Eo, We, Mo, Ec, Ecoll, Cp, Np, measured/model ratio, implied Cd: manuscript Eqs. (1),(2),(9) and Section 4.7-4.9. Compared with printed values."),
 ("ST3_Sensitivity", "Same chain for fps x um/px scenarios (NEW analysis). Shows which numbers depend on the two unverified inputs."),
 ("ST4_Claim_Check", "109 manuscript claims vs. values recomputed from the CSV data (status is a formula)."),
 ("ST5_Per_frame", "96 analysed frames (frames 25-120): smoothed kinematics, counts, coverage and assumed mineral mass (SUMIF over ST6)."),
 ("ST6_Features", "5,673 detected surface features: diameter (px), diameter (um, formula) and assumed mass (ng, formula (pi/6)d^3 rho_p)."),
 ("ST7_Pipeline", "Image-analysis parameters read from analysis_pipeline.py (including the high-pass threshold the manuscript calls 'not recorded')."),
 ("ST8_Induction", "Induction times implied by the Ea values at t_c = 100 ms (inverse of Eq. 4). NEW analysis."),
 ("Important", "Frame rate (500 vs 2000 fps) and spatial scale (11.2 vs 16.04 um/px) are UNVERIFIED. All SI-unit results inherit that uncertainty. See AUDIT/."),
 ("Provenance", "Source data: DATA/PROCESSED_DATA/supplied_csv/*.csv (author-supplied, reproduced bit-for-bit from raw frames by SOURCE_CODE/data_processing/regenerate_csvs_from_frames.py)."),
]
for i, (a, b) in enumerate(readme, 2):
    put(ws, i, (a, b), {1: BB})

# ------------------------------------------------------------ ST5 per-frame (built first; ST1 references it)
w5 = sheet("ST5_Per_frame", ["Frame", "d_raw (px)", "d_smoothed (px)", "cx smoothed (px)", "cy smoothed (px)", "v_rise SG (px/frame)", "Aspect ratio (-)",
                             "Features (-)", "Coverage (%)", "d_smoothed (mm)", "v_rise (mm/s)", "Assumed mineral mass (ng)", "BPR (SMD basis)"],
           [8, 11, 13, 13, 13, 14, 11, 10, 11, 12, 12, 16, 12])
N = len(pf)
for i, r in enumerate(pf.itertuples(), 2):
    put(w5, i, (int(r.frame), r.d_raw_px, r.d_sg_px, r.cx_sg_px, r.cy_sg_px, r.v_rise_sg_px_per_frame, r.aspect_ratio, int(r.n_features), r.coverage_pct,
                f"=C{i}*ST1_Inputs!$B$4/1000", f"=F{i}*ST1_Inputs!$B$4*ST1_Inputs!$B$5/1000", f"=SUMIF(ST6_Features!$A$2:$A${len(par)+1},A{i},ST6_Features!$D$2:$D${len(par)+1})", r.bpr_smd), wrap=False)
LAST = N + 1

# ------------------------------------------------------------ ST6 features
w6 = sheet("ST6_Features", ["Frame", "Feature eq. diameter (px)", "Feature diameter (um)", "Assumed mass (ng)"], [8, 18, 18, 18])
for i, r in enumerate(par.itertuples(), 2):
    put(w6, i, (int(r.frame), r.particle_eq_diam_px, f"=B{i}*ST1_Inputs!$B$4", f"=PI()/6*(C{i}*0.000001)^3*ST1_Inputs!$B$13*1000000000000"), wrap=False)
w6.cell(row=1, column=6, value="Note: mass assumes every feature is a magnesite sphere (rho_p) of the measured projected-area-equivalent diameter. ASSUMPTION, not a measurement.").font = BB

# ------------------------------------------------------------ ST1 inputs
w1 = sheet("ST1_Inputs", ["Quantity", "Value", "Unit", "Source / verification status"], [44, 16, 12, 110])
inputs = [
 ("PER-FRAME MEANS (formulas on ST5)", None, None, None),
 ("Spatial scale", CFG["optics"]["um_per_px"], "um/px", CFG["optics"]["um_per_px_status"]),
 ("Frame rate", CFG["optics"]["fps"], "fps", "UNVERIFIED. " + CFG["optics"]["fps_status"]),
 ("Mean smoothed bubble diameter", f"=AVERAGE(ST5_Per_frame!C2:C{LAST})", "px", "Computed from data (Savitzky-Golay 11/3)."),
 ("Mean rise velocity (SG)", f"=AVERAGE(ST5_Per_frame!F2:F{LAST})", "px/frame", "Computed from data."),
 ("Net rise (first - last smoothed cy)", f"=ST5_Per_frame!E2-ST5_Per_frame!E{LAST}", "px", "Computed from data."),
 ("Mean features per frame", f"=AVERAGE(ST5_Per_frame!H2:H{LAST})", "-", "Computed from data."),
 ("FLUID AND MATERIAL INPUTS", None, None, None),
 ("Liquid density rho_L", CFG["fluid_assumed_pure_water_23C"]["rho_l_kg_m3"], "kg/m3", "ASSUMED pure water 23 C; liquid properties undocumented."),
 ("Liquid viscosity mu_L", CFG["fluid_assumed_pure_water_23C"]["mu_l_Pa_s"], "Pa s", "ASSUMED pure water 23 C."),
 ("Surface tension sigma", CFG["fluid_assumed_pure_water_23C"]["sigma_N_m"], "N/m", "ASSUMED pure water."),
 ("Gas density rho_g", CFG["fluid_assumed_pure_water_23C"]["rho_g_kg_m3"], "kg/m3", "Air."),
 ("Particle density rho_p (magnesite)", CFG["collection_model"]["rho_p_kg_m3"], "kg/m3", "Manuscript Table 2."),
 ("Particle diameter d_p", CFG["collection_model"]["d_p_um"], "um", "Manuscript (system A/B); NOT measured in system C."),
 ("Attachment efficiency Ea", CFG["collection_model"]["E_a"], "-", "UNVERIFIED. " + CFG["collection_model"]["E_a_status"]),
 ("Stability efficiency Es", CFG["collection_model"]["E_s"], "-", "ASSUMED scenario value (not measured)."),
 ("Solids mass concentration", CFG["collection_model"]["solids_kg_m3"], "kg/m3", "UNVERIFIED for system C. " + CFG["collection_model"]["solids_status"]),
 ("Gravity g", 9.81, "m/s2", "Constant."),
 ("Relative scale uncertainty", CFG["optics"]["scale_relative_uncertainty"], "-", "Manuscript +/-4% (not re-derived)."),
]
# row layout: row2 = header-like label; rows 3.. entries. Fixed addresses used by formulas: B4 scale, B5 fps, B13 rho_p
r = 2
addr = {}
for lab, val, unit, src in inputs:
    if val is None:
        c = w1.cell(row=r, column=1, value=lab); c.font = BB; c.fill = PatternFill("solid", fgColor="D9E1F2")
        for j in (2, 3, 4):
            w1.cell(row=r, column=j).fill = PatternFill("solid", fgColor="D9E1F2")
    else:
        isf = isinstance(val, str) and val.startswith("=")
        put(w1, r, (lab, val, unit, src), {2: B if isf else INP}, wrap=True)
        if "UNVERIFIED" in (src or ""):
            for j in (1, 2, 3, 4):
                w1.cell(row=r, column=j).fill = WARN
        addr[lab] = f"ST1_Inputs!$B${r}"
    r += 1
# sanity: enforce intended fixed addresses
assert addr["Spatial scale"].endswith("$B$3") or True
SC, FP = addr["Spatial scale"], addr["Frame rate"]
# Fix references in ST5/ST6 to the real rows
for ws_ in (w5, w6):
    for row in ws_.iter_rows():
        for c in row:
            if isinstance(c.value, str) and c.value.startswith("="):
                c.value = c.value.replace("ST1_Inputs!$B$4", SC).replace("ST1_Inputs!$B$5", FP).replace("ST1_Inputs!$B$13", addr["Particle density rho_p (magnesite)"])
A = addr
D, V, RISE, CNT = A["Mean smoothed bubble diameter"], A["Mean rise velocity (SG)"], A["Net rise (first - last smoothed cy)"], A["Mean features per frame"]
RL, MU, SG_, RG, RP, DP, EA, ES, SOL, GG = (A["Liquid density rho_L"], A["Liquid viscosity mu_L"], A["Surface tension sigma"], A["Gas density rho_g"], A["Particle density rho_p (magnesite)"],
                                              A["Particle diameter d_p"], A["Attachment efficiency Ea"], A["Stability efficiency Es"], A["Solids mass concentration"], A["Gravity g"])

# ------------------------------------------------------------ ST2 chain
w2 = sheet("ST2_Model_Chain", ["Quantity", "Symbol", "Value (formula)", "Unit", "Manuscript value", "Relative difference", "Equation / location"], [38, 10, 18, 12, 16, 14, 52])
rows = [
 ("Bubble diameter", "d_b", f"={D}*{SC}*0.000001", "m", 1.304e-3, "S4.2"),
 ("Rise velocity", "V_b", f"={V}*{SC}*0.000001*{FP}", "m/s", 0.0348, "S4.7 (depends on fps and scale)"),
 ("Reynolds number", "Re", f"={RL}*C3*C2/{MU}", "-", 48.6, "Re = rho_L V d / mu_L"),
 ("Eotvos number", "Eo", f"=({RL}-{RG})*{GG}*C2^2/{SG_}", "-", 0.231, "Eo = (rho_L-rho_g) g d^2 / sigma"),
 ("Weber number", "We", f"={RL}*C3^2*C2/{SG_}", "-", 0.0219, "We = rho_L V^2 d / sigma"),
 ("Morton number", "Mo", f"={GG}*{MU}^4*({RL}-{RG})/({RL}^2*{SG_}^3)", "-", 2.0e-11, "Mo = g mu^4 (rho_L-rho_g) / (rho_L^2 sigma^3)"),
 ("Collision efficiency", "Ec", f"=(1.5+4/15*C4^0.7215)*({DP}*0.000001/C2)^2", "-", 2.9e-3, "Eq. (2) Yoon-Luttrell"),
 ("Total efficiency", "Ecoll", f"=C8*{EA}*{ES}", "-", 1.92e-3, "Eq. (1)"),
 ("Particle number concentration", "Cp", f"={SOL}/({RP}*PI()*({DP}*0.000001)^3/6)", "1/m3", 261e9, "10 kg/m3 monodisperse 29 um magnesite"),
 ("Collection-zone height (= net rise)", "h_c", f"={RISE}*{SC}*0.000001", "m", 1.646e-3, "S4.9 (scenario)"),
 ("Max particles per bubble (Ecoll=1)", "Np_max", f"=PI()*((C2+{DP}*0.000001)/2)^2*C11*C10", "-", 599.6, "Eq. (9) with Ecoll = 1"),
 ("Particles per bubble (model)", "Np", f"=C9*C12", "-", 1.15, "Eq. (9)"),
 ("Mean detected features (image)", "N_feat", f"={CNT}", "-", 59.09, "S4.4 (surface features, not confirmed particles)"),
 ("Measured / model", "-", "=C14/C13", "-", 51, "S4.9 ('about 51 times')"),
 ("Implied drag coefficient", "Cd", f"=4/3*({RL}-{RG})*{GG}*C2/({RL}*C3^2)", "-", 14, "S4.8"),
]
for i, (q, s, f, u, m, loc) in enumerate(rows, 2):
    put(w2, i, (q, s, f, u, m, f"=(C{i}-E{i})/E{i}", loc))
    w2.cell(row=i, column=6).number_format = "0.0%"
    w2.cell(row=i, column=3).number_format = "0.000E+00" if q in ("Bubble diameter", "Morton number", "Collision efficiency", "Total efficiency", "Particle number concentration", "Collection-zone height (= net rise)", "Rise velocity") else "0.0000"
put(w2, len(rows) + 3, ("All SI results above inherit the unverified frame rate and scale (ST1 yellow cells). Cp uses the system B slurry concentration, not the (unknown) system C suspension.",), {1: BB})

# ------------------------------------------------------------ ST3 sensitivity
w3 = sheet("ST3_Sensitivity", ["um/px", "fps", "d_b (mm)", "V_b (mm/s)", "Re", "Ec", "Ecoll", "Np (model)", "Features / Np", "Implied Cd"], [10, 8, 12, 12, 10, 12, 12, 12, 14, 12])
i = 2
for um in (11.2, 16.04):
    for fps in (500, 1000, 2000):
        put(w3, i, (um, fps, f"={D}*A{i}/1000", f"={V}*A{i}*B{i}/1000", f"={RL}*(D{i}/1000)*(C{i}/1000)/{MU}",
                    f"=(1.5+4/15*E{i}^0.7215)*({DP}*0.000001/(C{i}/1000))^2",
                    f"=F{i}*{EA}*{ES}",
                    f"=G{i}*PI()*((C{i}/1000+{DP}*0.000001)/2)^2*({RISE}*A{i}*0.000001)*({SOL}/({RP}*PI()*({DP}*0.000001)^3/6))",
                    f"={CNT}/H{i}", f"=4/3*({RL}-{RG})*{GG}*(C{i}/1000)/({RL}*(D{i}/1000)^2)"), {1: INP, 2: INP})
        i += 1
put(w3, i + 1, ("500 fps: legacy scripts / 'only assumed'. 2000 fps: manuscript 'documented'. 16.04 um/px = 3 mm / 187 visible px (upper bound; bar is clipped). Np uses Ecoll from Ec at the scenario's Re.",), {1: BB})

# ------------------------------------------------------------ ST4 claims
w4 = sheet("ST4_Claim_Check", ["ID", "Manuscript location", "Quantity", "Claimed", "Recomputed", "Tolerance", "Status (formula)", "Unit", "Note"], [7, 12, 46, 12, 14, 12, 16, 12, 70])
for i, c in enumerate(claims, 2):
    put(w4, i, (c["id"], c["manuscript_location"], c["quantity"], float(c["claimed"]), float(c["recomputed"]), float(c["tolerance"]),
                f'=IF(ABS(E{i}-D{i})<=F{i}+0.000000000001,"PASS","FAIL")', c["unit"], c["note"]), wrap=False)
    if c["status"] == "FAIL":
        for j in range(1, 10):
            w4.cell(row=i, column=j).fill = BAD
    if c["status"] == "PASS*":
        w4.cell(row=i, column=7).value = f'=IF(ABS(E{i}-D{i})<=F{i}+0.000000000001,"PASS (definition-dependent)","FAIL")'
n = len(claims) + 3
put(w4, n, ("", "", "Summary", "", "", "", "", "", ""), {3: BB})
put(w4, n + 1, ("", "", "PASS", f'=COUNTIF(G2:G{len(claims)+1},"PASS*")', "", "", "", "", "includes definition-dependent passes"))
put(w4, n + 2, ("", "", "FAIL", f'=COUNTIF(G2:G{len(claims)+1},"FAIL")', "", "", "", "", "see AUDIT/CORRECTION_LOG"))

# ------------------------------------------------------------ ST7 pipeline
w7 = sheet("ST7_Pipeline", ["Stage", "Parameter", "Value", "Source"], [26, 44, 22, 60])
pl = [("Bubble segmentation", "Gaussian blur kernel", "5x5", "analysis_pipeline.segment_in_roi"), ("", "Threshold", "Otsu (inside ROI)", ""), ("", "Closing / opening", "ellipse 5x5 / square 3x3", ""),
      ("", "Tail-severing erosion/dilation", "ellipse 13x13", "manuscript S3.4"), ("", "Contour used", "convex hull of largest component", ""), ("", "ROI margin", "max(90 px, 2.2 x previous radius)", ""),
      ("", "Overlay masking", "bottom 45 px, left 230 px and right 270 px", "mask_overlay"),
      ("Feature detection", "Mask erosion", "15 px ellipse", "detect_particles"), ("", "High-pass: Gaussian sigma", "9 px", ""),
      ("", "High-pass threshold", "18 gray levels (8-bit)", "MANUSCRIPT SAYS 'NOT RECORDED'; THE CODE RECORDS IT"), ("", "Accepted blob area", "2 to 200 px^2 (d = 1.60 to 15.96 px)", ""),
      ("PIV (OpenPIV)", "Window / overlap / search area", "32 / 16 / 32 px", "run_piv"), ("", "Signal-to-noise", "peak2peak, threshold 1.25", ""), ("", "Bubble exclusion", "contours of both frames dilated by 41 px ellipse", ""),
      ("", "dt", "1 frame", ""), ("Smoothing", "Savitzky-Golay", "window 11, order 3, mode interp", "RECOVERED by search (recover_savgol_parameters.py)"),
      ("Cross-check", "Bubble Analyser 2.0 NormalWatershed", "defaults: high 0.95, mid 0.7, low 0.05, element 5, connectivity 4, px2mm 1", "crossvalidate_with_bubble_analyser")]
for i, row in enumerate(pl, 2):
    put(w7, i, row)

# ------------------------------------------------------------ ST8
w8 = sheet("ST8_Induction", ["Ea (-)", "Contact time t_c (ms)", "Implied induction time t_i (ms)", "Check: Ea from t_i (Eq. 4)"], [10, 20, 28, 26])
for i, r in enumerate(imp.itertuples(), 2):
    put(w8, i, (r.Ea, r.contact_time_ms, r.implied_t_i_ms, f"=SIN(2*ATAN(EXP(-C{i}/B{i})))^2"))
put(w8, 6, ("NEW analysis: inverse of Eq. (4). Ea=0.22/0.78/0.95 are the manuscript's BPATE values (raw BPATE data not supplied). A t_i of 22 ms at saturation exceeds the quoted t_i0 = 8.2 ms, i.e. W_B > 0 even above the HMC.",), {1: BB})

out = ROOT / "SUPPLEMENTARY_INFORMATION/Supplementary_Tables.xlsx"
wb.save(out)
print("saved", out)
