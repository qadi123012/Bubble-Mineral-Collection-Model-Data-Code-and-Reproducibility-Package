#!/usr/bin/env python3
"""
sensitivity_fps_scale.py  (NEW ANALYSIS, not in the manuscript)
==============================================================
Every physical (SI) number derived from system C depends on two quantities that could NOT be verified from the
supplied records: the frame rate (fps) and the spatial scale (um/px). This script propagates both through the
collection-model chain so that the reader can see which conclusions are robust and which are not.

Scenarios: fps in {500, 1000, 2000}  x  um/px in {11.2, 16.04}.
  500 fps   : value used by the legacy scripts and described as 'only assumed' in the imaging-procedure slides
  2000 fps  : value printed in the manuscript ('documented')
  11.2 um/px: value used throughout the manuscript
  16.04 um/px: 3 mm / 187 px, from the burned-in scale bar IF the visible 187 px were the whole bar (it touches
               the image edge, so this is an upper bound of um/px; see FIGURES/Supplementary S3)

Output: DATA/DERIVED_DATA/sensitivity_fps_scale.csv and implied_induction_times.csv
"""
import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "COMPUTATIONAL_MODELS" / "single_bubble_collection_model"))
import collection_model as cm  # noqa: E402

CFG = json.load(open(ROOT / "COMPUTATIONAL_MODELS" / "CONFIGURATION" / "parameters.json"))
pf = pd.read_csv(ROOT / "DATA" / "PROCESSED_DATA" / "per_frame_processed.csv")
FL = CFG["fluid_assumed_pure_water_23C"]
D_PX, V_PX = pf.d_sg_px.mean(), pf.v_rise_sg_px_per_frame.mean()
RISE_PX = pf.cy_sg_px.iloc[0] - pf.cy_sg_px.iloc[-1]
MASS_AT_11P2_NG = pf.assumed_mass_ng.mean()

rows = []
for um in (11.2, 16.04):
    for fps in (500, 1000, 2000):
        d, v = D_PX * um * 1e-6, V_PX * um * 1e-6 * fps
        sc = cm.Scenario(d_b=d, v_b=v, rho_l=FL["rho_l_kg_m3"], rho_g=FL["rho_g_kg_m3"], mu_l=FL["mu_l_Pa_s"], sigma=FL["sigma_N_m"],
                         h_c=RISE_PX * um * 1e-6)
        r = sc.evaluate()
        rows.append(dict(um_per_px=um, fps=fps, d_b_mm=d * 1e3, v_b_mm_s=v * 1e3, Re=r["Re"], Eo=r["Eo"], We=r["We"], Ec=r["Ec"], Ecoll=r["Ecoll"],
                         Np_model=r["Np"], Np_max=r["Np_max"], feature_count_over_Np=pf.n_features.mean() / r["Np"],
                         Cd_implied=cm.implied_drag_coefficient(FL["rho_l_kg_m3"], FL["rho_g_kg_m3"], v, d),
                         v_rigid_sphere_mm_s=1e3 * cm.schiller_naumann_terminal_velocity(FL["rho_l_kg_m3"], FL["rho_g_kg_m3"], FL["mu_l_Pa_s"], d),
                         v_over_v_rigid=v / cm.schiller_naumann_terminal_velocity(FL["rho_l_kg_m3"], FL["rho_g_kg_m3"], FL["mu_l_Pa_s"], d),
                         assumed_mass_per_frame_ug=MASS_AT_11P2_NG * (um / 11.2) ** 3 * 1e-3))
df = pd.DataFrame(rows)
df.to_csv(ROOT / "DATA" / "DERIVED_DATA" / "sensitivity_fps_scale.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print(df.round(4).to_string(index=False))

# implied induction times for the Ea values quoted in the manuscript (Eq. 4 inverted); t_c = 100 ms
imp = pd.DataFrame([dict(Ea=e, contact_time_ms=100.0, implied_t_i_ms=cm.implied_induction_time(e, 100.0)) for e in (0.22, 0.78, 0.95)])
imp.to_csv(ROOT / "DATA" / "DERIVED_DATA" / "implied_induction_times.csv", index=False)
print(imp.round(2).to_string(index=False))
