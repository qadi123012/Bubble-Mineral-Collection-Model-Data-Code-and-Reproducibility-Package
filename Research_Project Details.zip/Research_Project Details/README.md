# Single-bubble mineral collection model: reproducibility package

Supplementary data, code, calculations and audit for *Final_Manuscript_Cl.docx* (single rising bubble in a magnesite suspension, "system C", with an Ec x Ea x Es collection model).

> **Read first.** Every SI-unit result (velocity, Re, Ec, Np, masses) depends on the frame rate and spatial scale of the single-bubble recording. Both are **unverified and contradicted by the authors' own materials** (500 vs 2000 fps; 11.2 vs 16.04 um/px). Eight printed numbers do not reproduce. See `AUDIT/FINAL_SCIENTIFIC_DATA_AND_REPRODUCIBILITY_AUDIT.pdf` and `AUDIT/CORRECTION_LOG.md` before submission. The manuscript file has not been altered.

## Contents
| Folder | Content |
|---|---|
| `MANUSCRIPT/` | the manuscript audited (Cl version) |
| `SUPPLEMENTARY_INFORMATION/` | Supplementary Information (PDF, DOCX, MD), `Supplementary_Tables.xlsx` (live formulas), supplementary figures S1-S3 |
| `DATA/RAW_DATA/` | 121 raw frames (system C), 4 raw micrographs |
| `DATA/PROCESSED_DATA/` | author CSVs (`supplied_csv`), CSVs + smoothing (`legacy_schema`), `per_frame_processed.csv`, micrograph masks |
| `DATA/DERIVED_DATA/` | recomputed statistics, sensitivity tables, regenerated author outputs, **stale author JSON kept only for the record** |
| `DATA/DATA_DICTIONARY.xlsx` | every column: type, unit, definition, manuscript use |
| `COMPUTATIONAL_MODELS/` | `single_bubble_collection_model/` (Eqs. 1-12, unit tests), `CONFIGURATION/parameters.json` |
| `SOURCE_CODE/` | `data_processing` (author pipeline, unmodified), `calculations`, `plotting`, `validation`, `legacy_as_supplied` (author scripts, untouched), `legacy_adapted` (same scripts, path constants only) |
| `FIGURES/` | PNG/PDF figures and plotted source data |
| `AUDIT/` | audit report, correction log, missing information, traceability table, claim verification, test log |
| `DOCUMENTATION/` | installation, execution, methodology, validation, troubleshooting |
| `ENVIRONMENT/` | pinned requirements, conda file, tested versions |

## Quick start
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r ENVIRONMENT/requirements.txt
bash run_all.sh --with-regeneration
```
Expected: `7 tests passed`; `109 claims checked: {'PASS': 100, 'PASS*': 1, 'FAIL': 8}`; `ALL IDENTICAL`.

## What is reproduced
The authors' image pipeline re-run on the raw frames reproduces all four CSV files (difference <= 6e-14). All system C statistics (216) are recomputed; 109 manuscript claims are checked. The collection model reproduces the printed Re, Ec, Ecoll, Np and related numbers at 2000 fps and 11.2 um/px.

## What is not reproduced (and why)
Systems A and B (zeta potential, BPATE, bubble sizing, flotation): no data supplied. The model is **not validated** (no measured K, recovery or particle count independent of the image proxy). Details: `AUDIT/MISSING_INFORMATION.md`.

## Data availability statement (draft; edit before use)
The raw frames and micrographs, processed and derived datasets and all code used for the single-bubble analysis are in this repository. Raw data for the zeta-potential, BPATE, bubble-size and flotation experiments (systems A and B) are not included because they were not available when this package was prepared.

## Licence, citation, contact
Not included: no licence, author or contact information was supplied. **Choose a licence (e.g. MIT for code, CC BY 4.0 for data) and add `LICENSE` and `CITATION.cff` before publishing.**
