"""Unit tests (verification of the implementation against numbers printed in the manuscript).

Run from COMPUTATIONAL_MODELS/single_bubble_collection_model :
    python tests/test_collection_model.py          (no extra dependencies)
    python -m pytest -q                            (if pytest is installed)

Reference values are those printed in the manuscript (Sections 2.4, 4.8, 4.9). They are valid ONLY under the
manuscript's scenario inputs (0.0112 mm/px, 2000 fps, water at 23 C). See VALIDATION_GUIDE.md.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import collection_model as cm  # noqa: E402

D_B = 116.4535084947219 * 11.2e-6          # m  (documented analysis scale)
V_B = 1.5526859504076451 * 11.2e-6 * 2000  # m/s (documented 2000 fps)


def close(a, b, rel):
    assert abs(a - b) <= rel * abs(b), (a, b)


def test_dimensionless_groups():
    r = cm.Scenario(d_b=D_B, v_b=V_B).evaluate()
    close(r["Re"], 48.6, 0.005)
    close(r["Eo"], 0.231, 0.005)
    close(r["We"], 0.0219, 0.005)
    close(r["Mo"], 1.99e-11, 0.005)


def test_collection_chain_matches_manuscript():
    r = cm.Scenario(d_b=D_B, v_b=V_B).evaluate()
    close(r["Ec"], 2.9e-3, 0.01)
    close(r["Ecoll"], 1.92e-3, 0.01)
    close(r["Cp_per_m3"], 261e9, 0.005)      # 261 mm^-3
    close(r["Np_max"], 599.6, 0.005)
    close(r["Np"], 1.15, 0.01)


def test_es_range_in_section_2_4():
    ec = cm.Scenario(d_b=D_B, v_b=V_B).evaluate()["Ec"]
    close(ec * 0.78 * 0.80, 1.81e-3, 0.01)
    close(ec * 0.78 * 0.95, 2.15e-3, 0.01)


def test_attachment_roundtrip():
    for ti in (5.0, 22.0, 51.0, 139.0):
        assert abs(cm.implied_induction_time(cm.attachment_efficiency(ti, 100.0), 100.0) - ti) < 1e-6


def test_eq10_consistency():
    e, jg, d = 2e-3, 0.02, 3.1e-4
    close(cm.rate_constant_single_size(e, jg, d), 0.25 * e * (6 * jg / d), 1e-12)
    close(cm.rate_constant_total([e], [1.0], [d], jg), cm.rate_constant_single_size(e, jg, d), 1e-12)


def test_weights_sum_to_one():
    n, d = [5, 3, 2], [2e-4, 3e-4, 6e-4]
    close(sum(cm.surface_area_weights(n, d)), 1.0, 1e-12)
    close(sum(cm.volume_fractions(n, d)), 1.0, 1e-12)


def test_rigid_sphere_drag_and_lamb():
    close(cm.schiller_naumann_terminal_velocity(997.5, 1.2, 0.932e-3, D_B), 0.146, 0.01)  # manuscript: ~0.15 m/s
    close(cm.implied_drag_coefficient(997.5, 1.2, V_B, D_B), 14.1, 0.01)                  # manuscript: ~14
    close(cm.lamb_bubble_frequency_hz(0.072, 997.5, D_B / 2), 281.0, 0.01)                # manuscript: ~281 Hz


if __name__ == "__main__":
    n = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            n += 1
            print("PASS", name)
    print(f"{n} tests passed")
