"""
collection_model.py
===================
Executable implementation of the single-bubble mineral collection model of the manuscript
(Section 2, Equations 1-12). Pure Python standard library, no other dependencies.

STATUS OF EACH COMPONENT (see DOCUMENTATION/VALIDATION_GUIDE.md)
  Ec  (Eq. 2)  verification: implemented from the published correlation, checked by unit tests.
  Ea  (Eq. 4)  forward function only. t_i is an INPUT. The BPATE calibration (t_i0, alpha) cannot be
               re-fitted here because the raw BPATE records and the W_B(zeta_p) form are not supplied.
  Es  (Eq. 8)  force-balance functions provided; the manuscript itself adopts Es = 0.85 as a SCENARIO value.
  Np  (Eq. 9), K (Eq. 10), K_total (Eq. 11), R(t) (Eq. 12): implemented; NOT validated against any
               measured K or recovery (none exists in the supplied materials).

All SI units unless a name says otherwise. Symbols follow the manuscript.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Sequence

G = 9.81  # m s^-2


# ----------------------------------------------------------------------------- dimensionless groups
def reynolds(rho_l: float, v: float, d: float, mu: float) -> float:
    """Re = rho_L * |V| * d / mu_L"""
    return rho_l * abs(v) * d / mu


def eotvos(rho_l: float, rho_g: float, d: float, sigma: float, g: float = G) -> float:
    """Eo = (rho_L - rho_g) g d^2 / sigma"""
    return (rho_l - rho_g) * g * d ** 2 / sigma


def weber(rho_l: float, v: float, d: float, sigma: float) -> float:
    """We = rho_L V^2 d / sigma"""
    return rho_l * v ** 2 * d / sigma


def morton(rho_l: float, rho_g: float, mu: float, sigma: float, g: float = G) -> float:
    """Mo = g mu^4 (rho_L - rho_g) / (rho_L^2 sigma^3)"""
    return g * mu ** 4 * (rho_l - rho_g) / (rho_l ** 2 * sigma ** 3)


def implied_drag_coefficient(rho_l, rho_g, v, d, g: float = G) -> float:
    """Cd implied by a steady rise: Cd = (4/3) (rho_L - rho_g) g d / (rho_L V^2)."""
    return (4.0 / 3.0) * (rho_l - rho_g) * g * d / (rho_l * v ** 2)


def schiller_naumann_terminal_velocity(rho_l, rho_g, mu, d, g: float = G) -> float:
    """Terminal velocity of a RIGID sphere of density rho_g (Schiller-Naumann drag), by bisection."""
    def resid(v):
        re = rho_l * v * d / mu
        cd = 24.0 / re * (1.0 + 0.15 * re ** 0.687)
        return 0.75 * cd * rho_l * v ** 2 / (d * (rho_l - rho_g) * g) - 1.0
    lo, hi = 1e-4, 5.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if resid(lo) * resid(mid) <= 0:
            hi = mid
        else:
            lo = mid
    return 0.5 * (lo + hi)


def lamb_bubble_frequency_hz(sigma, rho_l, radius, mode: int = 2) -> float:
    """Lamb frequency of a gas bubble in liquid (rho_g << rho_L): omega^2 = (l-1)(l+1)(l+2) sigma/(rho_L R^3)."""
    w2 = (mode - 1) * (mode + 1) * (mode + 2) * sigma / (rho_l * radius ** 3)
    return math.sqrt(w2) / (2.0 * math.pi)


# ----------------------------------------------------------------------------- Eq. (2) collision
def collision_efficiency_yoon_luttrell(re_b: float, dp: float, db: float, exponent: float = 0.7215) -> float:
    """Eq. (2): Ec = (3/2 + (4/15) Re_b^0.7215) (dp/db)^2  (Yoon & Luttrell, referenced to the swept
    cylinder of radius (db+dp)/2 as stated in Section 2.2 of the manuscript).
    NOTE: the fractions 3/2 and 4/15 are lost in the manuscript's equation rendering (printed '32 + 4Re^0.7215');
    they are the standard Yoon-Luttrell coefficients and reproduce the manuscript's Ec = 2.9e-3."""
    return (1.5 + (4.0 / 15.0) * re_b ** exponent) * (dp / db) ** 2


def stokes_rise_velocity(rho_l, rho_g, mu, db, g: float = G) -> float:
    """Stokes rise velocity of a rigid sphere (valid for small d_b only; Section 2.2)."""
    return g * db ** 2 * (rho_l - rho_g) / (18.0 * mu)


def surface_area_weights(n_i: Sequence[float], d_i: Sequence[float]):
    """Eq. (3): w_i = n_i d_i^2 / sum_j n_j d_j^2."""
    den = sum(n * d ** 2 for n, d in zip(n_i, d_i))
    return [n * d ** 2 / den for n, d in zip(n_i, d_i)]


def volume_fractions(n_i: Sequence[float], d_i: Sequence[float]):
    """phi_i = n_i d_i^3 / sum_j n_j d_j^3 (below Eq. 11)."""
    den = sum(n * d ** 3 for n, d in zip(n_i, d_i))
    return [n * d ** 3 / den for n, d in zip(n_i, d_i)]


# ----------------------------------------------------------------------------- Eq. (4) attachment
def attachment_efficiency(t_i: float, t_c: float) -> float:
    """Eq. (4): Ea = sin^2[ 2 arctan( exp(-t_i / t_c) ) ]  (t_i, t_c in the same units)."""
    return math.sin(2.0 * math.atan(math.exp(-t_i / t_c))) ** 2


def implied_induction_time(ea: float, t_c: float) -> float:
    """Inverse of Eq. (4): the t_i that reproduces a measured Ea at contact time t_c.
    NEW ANALYSIS (not in the manuscript): shows what the BPATE values imply for t_i."""
    if not 0.0 < ea < 1.0:
        raise ValueError("Ea must lie in (0, 1)")
    theta = math.asin(math.sqrt(ea))          # 2*arctan(exp(-x)) = theta
    x = -math.log(math.tan(theta / 2.0))
    return x * t_c


def induction_time_surrogate(t_i0: float, alpha: float, w_b_over_kT: float) -> float:
    """Eq. (7): t_i = t_i0 exp(alpha W_B / kT). W_B form NOT supplied -> W_B/kT is an input."""
    return t_i0 * math.exp(alpha * w_b_over_kT)


# ----------------------------------------------------------------------------- Eq. (8) stability
def capillary_adhesion_force(sigma, r_p, theta_rad) -> float:
    """F_att = 2 pi sigma r_p (1 - cos(theta))   (manuscript Section 2.4)."""
    return 2.0 * math.pi * sigma * r_p * (1.0 - math.cos(theta_rad))


def detachment_force(r_p, rho_p, rho_l, eps, cd=1.0, beta=1.0, g: float = G) -> float:
    """F_det = F_g + F_h with F_g = (4/3) pi r^3 (rho_p-rho_L) g, F_h = 0.5 Cd rho_L v_rel^2 pi r^2,
    v_rel = beta (eps r)^(2/3)  (as stated in the manuscript; coefficients are order-unity assumptions)."""
    f_g = (4.0 / 3.0) * math.pi * r_p ** 3 * (rho_p - rho_l) * g
    v_rel = beta * (eps * r_p) ** (2.0 / 3.0)
    f_h = 0.5 * cd * rho_l * v_rel ** 2 * math.pi * r_p ** 2
    return f_g + f_h


def stability_efficiency(f_det: float, f_att: float) -> float:
    """Eq. (8): Es = exp(-F_det / F_att)."""
    return math.exp(-f_det / f_att)


# ----------------------------------------------------------------------------- Eq. (1),(9)-(12)
def total_efficiency(ec: float, ea: float, es: float) -> float:
    """Eq. (1): Ecoll = Ec * Ea * Es."""
    return ec * ea * es


def particle_number_concentration(solids_mass_conc_kg_m3: float, dp: float, rho_p: float) -> float:
    """C_p (m^-3) for monodisperse spheres: c / ( rho_p pi dp^3 / 6 )."""
    return solids_mass_conc_kg_m3 / (rho_p * math.pi * dp ** 3 / 6.0)


def particles_per_bubble(e_coll: float, db: float, dp: float, h_c: float, c_p: float) -> float:
    """Eq. (9): Np = Ecoll * pi ((db+dp)/2)^2 * h_c * C_p."""
    return e_coll * math.pi * ((db + dp) / 2.0) ** 2 * h_c * c_p


def rate_constant_single_size(e_coll: float, j_g: float, d_b: float) -> float:
    """Eq. (10): K = (3/2) Ecoll Jg/db = (1/4) Ecoll Sb  (Sb = 6 Jg / db)."""
    return 1.5 * e_coll * j_g / d_b


def rate_constant_total(e_coll_i: Sequence[float], n_i: Sequence[float], d_i: Sequence[float], j_g: float) -> float:
    """Eq. (11): K_total = sum_i (1/4) Ecoll_i Sb_i,  Sb_i = 6 Jg phi_i / d_i, phi_i volume fractions."""
    phi = volume_fractions(n_i, d_i)
    return sum(0.25 * e * 6.0 * j_g * p / d for e, p, d in zip(e_coll_i, phi, d_i))


def recovery(t: float, k_total: float, r_inf: float) -> float:
    """Eq. (12): R(t) = Rinf (1 - exp(-K t)). Rinf is NOT provided by this framework."""
    return r_inf * (1.0 - math.exp(-k_total * t))


# ----------------------------------------------------------------------------- scenario container
@dataclass
class Scenario:
    """Inputs of the illustrative single-bubble calculation of manuscript Section 4.9."""
    d_b: float            # m, bubble equivalent diameter
    v_b: float            # m/s, measured rise velocity (depends on fps and um/px!)
    d_p: float = 29e-6    # m, system A/B particle size (manuscript)
    rho_l: float = 997.5
    rho_g: float = 1.2
    mu_l: float = 0.932e-3
    sigma: float = 0.072
    rho_p: float = 3000.0
    e_a: float = 0.78     # BPATE at 100 ms above HMC (system A) - raw data not supplied
    e_s: float = 0.85     # scenario assumption (Section 2.4)
    h_c: float = 1.6455e-3  # m, observed net rise used as collection-zone height (scenario)
    solids_kg_m3: float = 10.0  # 30 g in 3 L, system B

    def evaluate(self) -> dict:
        re = reynolds(self.rho_l, self.v_b, self.d_b, self.mu_l)
        ec = collision_efficiency_yoon_luttrell(re, self.d_p, self.d_b)
        ecoll = total_efficiency(ec, self.e_a, self.e_s)
        cp = particle_number_concentration(self.solids_kg_m3, self.d_p, self.rho_p)
        np_ = particles_per_bubble(ecoll, self.d_b, self.d_p, self.h_c, cp)
        np_max = particles_per_bubble(1.0, self.d_b, self.d_p, self.h_c, cp)
        return dict(Re=re, Eo=eotvos(self.rho_l, self.rho_g, self.d_b, self.sigma),
                    We=weber(self.rho_l, self.v_b, self.d_b, self.sigma),
                    Mo=morton(self.rho_l, self.rho_g, self.mu_l, self.sigma),
                    Ec=ec, Ea=self.e_a, Es=self.e_s, Ecoll=ecoll, Cp_per_m3=cp, Np=np_, Np_max=np_max)
