# Verification, validation, calibration, sensitivity and uncertainty: what is and is not established

| Concept | What was done here | Status |
|---|---|---|
| **Verification** (are the equations solved correctly?) | 7 unit tests reproduce the manuscript's Re, Eo, We, Mo, Ec, Ecoll, Cp, Np, Np range, implied Cd, rigid-sphere velocity and Lamb frequency; Eq. (10) = Eq. (11) for one size class; Eq. (4) round-trip | PASSED |
| **Reproducibility of the data pipeline** | Original code re-run on raw frames: 4 CSVs identical to <= 6e-14 | PASSED |
| **Reproducibility of statistics** | 109 manuscript claims recomputed: 100 pass, 1 definition-dependent, 8 fail (CL-03 to CL-10) | See correction log |
| **Validation** (does the model describe the real system?) | **Not possible.** No measured K, recovery, Np or collection efficiency is available to compare with a prior prediction. The feature count (59.1) exceeds the model Np (1.16) by 51x; the features are an image proxy (no controls), and Ec is applied outside the verified range of the correlation | NOT VALIDATED (the manuscript says the same) |
| **Calibration** | Ea (BPATE) and t_i0, alpha: calibrated by the authors; raw data missing, so not re-fitted | UNVERIFIABLE |
| **Sensitivity** | fps x scale grid (ST3, Fig. S1); Savitzky-Golay window/order (Fig. S2); Es range 0.80-0.95 (C98-C101). Not done: detection-threshold and erosion sweep (needs authors' decision; code is parameterised in `analysis_pipeline.detect_particles`) | PARTIAL |
| **Uncertainty** | Scale +/-4% propagated (Re +/-8%, We +/-12%) is arithmetic only; the scale itself is unverified. Frame-to-frame SD is not a measurement uncertainty. One bubble, so no between-bubble uncertainty exists | LIMITED |
