# Installation guide

**Requirements.** Python 3.10 or newer (tested with 3.12.3 on Ubuntu 24.04). About 1 GB of disk (the package is ~40 MB; figures and workbooks add a few MB). Optional: `git` + internet for the Bubble Analyser cross-check; `pandoc` and LibreOffice only to rebuild the Word/PDF documents.

```bash
# 1. get the repository (or unzip Research_Project.zip)
git clone <your-repository-url> Research_Project && cd Research_Project

# 2. create an isolated environment
python3 -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install --upgrade pip
pip install -r ENVIRONMENT/requirements.txt

# conda alternative
conda env create -f ENVIRONMENT/environment.yml && conda activate bubble-collection
```

**Fonts.** Figures use Liberation Serif (`sudo apt install fonts-liberation`); matplotlib falls back to DejaVu Serif automatically.

**Check the installation:**
```bash
python COMPUTATIONAL_MODELS/single_bubble_collection_model/tests/test_collection_model.py   # expect: 7 tests passed
```
