# Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `ModuleNotFoundError: openpiv` | OpenPIV missing | `pip install OpenPIV==0.26.1` |
| `AttributeError ... pyprocess` or changed PIV signature | A different OpenPIV version | install the tested 0.26.1 |
| `cv2` import error on a headless server | GUI build of OpenCV | `pip install opencv-python-headless` |
| Figures use DejaVu instead of Liberation Serif | font absent | `apt install fonts-liberation` (cosmetic only) |
| `FileNotFoundError: ...legacy_schema...` | statistics script not yet run | `python SOURCE_CODE/calculations/compute_manuscript_statistics.py` first (run_all.sh does it) |
| Bubble Analyser step fails | no internet / git | run without `--with-bubble-analyser` (the supplied cross-check CSV is still used for all statistics) |
| Regenerated CSV differs at 1e-14 | floating-point differences between BLAS builds | expected; tolerance in the script is 1e-9 |
| Workbook formulas show no values in a viewer | file never recalculated | open in Excel/LibreOffice (recalculates) or run the xlsx skill's `recalc.py` |
| `multi_bubble_analysis` warns IMG_9431 skipped | file not supplied | expected (M-07) |
| Statistics differ in the 4th decimal from the manuscript | SD (n) vs (n-1) | the package uses SD (n); both are stored (`*_sd1`) |
