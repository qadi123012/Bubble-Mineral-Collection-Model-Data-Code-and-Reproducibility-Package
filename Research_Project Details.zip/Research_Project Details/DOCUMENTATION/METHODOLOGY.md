# Methodology (as implemented; see manuscript Section 3 and Supplementary Information)

**Data.** System C: 121 exported frames (864 x 496, 8-bit); frames 25-120 (96 frames, 95 intervals) contain the single rising bubble. Systems A (zeta, BPATE) and B (bubble sizing, flotation) are described in the manuscript but **no data were supplied**.

**Pipeline** (`analysis_pipeline.py`, unmodified author code): (1) per-frame bubble segmentation inside a moving ROI (blur 5x5, Otsu, closing/opening, 13x13 tail severing, convex hull, ellipse fit); (2) centroid kinematics; (3) surface-feature detection (15 px erosion, high-pass with Gaussian sigma 9 px, threshold 18 gray levels, area 2-200 px^2); (4) OpenPIV (32 px window, 16 px overlap, 32 px search area, peak2peak S/N > 1.25, bubble region excluded); (5) Bubble Analyser 2.0 NormalWatershed cross-check at default parameters; (6) leading/trailing classification on the mean travel direction.

**Statistics.** Savitzky-Golay filter (window 11, order 3, `interp`) for diameter, centroid and rise velocity (parameters recovered by exact match to the authors' published statistics). SD = population SD (n). Regressions are descriptive (frames are strongly autocorrelated; nominal p-values are not interpreted).

**Physical conversions.** length = px x 11.2 um/px; velocity = px/frame x 11.2 um/px x 2000 fps; mass of a feature = (pi/6)(d)^3 rho_p with rho_p = 3000 kg/m3 (assumes every feature is a magnesite sphere). **Both the scale and the frame rate are unverified (CL-01, CL-02).**

**Model.** Ecoll = Ec x Ea x Es (Eq. 1). Ec from the Yoon-Luttrell correlation (Eq. 2), Ea from the sliding-contact expression (Eq. 4), Es = 0.85 (assumed), Np from Eq. (9), K from Eq. (10)-(11), R(t) from Eq. (12). Section 4.9 of the manuscript is an illustration, not a validation.

**New analyses (not in the manuscript, clearly labelled):** frame-rate and scale sensitivity; implied induction times; periodogram of the aspect ratio; recovery of the smoothing parameters; bit-level regeneration of the CSVs from raw frames.
