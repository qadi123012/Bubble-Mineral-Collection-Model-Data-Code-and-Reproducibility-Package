# Model and workflow execution guide

All commands are run from the repository root. Paths are relative; nothing is hard-coded.

## Step 1 Software and Step 2 Installation
See INSTALLATION_GUIDE.md.

## Step 3 Project setup
Do not move folders. `DATA/RAW_DATA` holds the frames and micrographs, `DATA/PROCESSED_DATA/supplied_csv` the four author CSVs.

## Step 4 Inputs
| File | Content |
|---|---|
| `COMPUTATIONAL_MODELS/CONFIGURATION/parameters.json` | every scenario input (scale, fps, fluid, particle, Ea, Es, smoothing, detection, PIV) with its verification status |
| `DATA/PROCESSED_DATA/supplied_csv/*.csv` | per-frame, per-feature and PIV data |
| `DATA/RAW_DATA/.../frame_XXXXXXXX.jpg` | raw frames (needed only to regenerate the CSVs and for gallery figures) |

## Step 5 Configuration
To test another frame rate or scale, edit `optics.fps` / `optics.um_per_px` in `parameters.json` (or use the blue cells in `Supplementary_Tables.xlsx`, sheet ST1_Inputs, which recalculate live). `sensitivity_fps_scale.py` already tabulates 500/1000/2000 fps x 11.2/16.04 um/px.

## Step 6 Execution
```bash
bash run_all.sh                       # everything below, ~1 min
bash run_all.sh --with-regeneration   # additionally re-run the image pipeline from the raw frames (~30 s)
```
Individually:
```bash
python SOURCE_CODE/calculations/compute_manuscript_statistics.py     # 216 statistics
python SOURCE_CODE/validation/verify_manuscript_claims.py            # 109 claims -> AUDIT/claim_verification.csv
python SOURCE_CODE/calculations/sensitivity_fps_scale.py             # fps x scale table
python SOURCE_CODE/data_processing/regenerate_csvs_from_frames.py [--with-bubble-analyser]
python SOURCE_CODE/plotting/make_supplementary_figures.py            # Fig. S1-S3
python SOURCE_CODE/plotting/make_mass_and_gallery_figures.py         # Figs. 8-11 (functional reproduction)
bash   SOURCE_CODE/legacy_adapted/run_all_legacy_adapted.sh          # authors' scripts, Figs. 3-7 equivalents
```
Single-bubble model as a library:
```python
import sys; sys.path.insert(0, "COMPUTATIONAL_MODELS/single_bubble_collection_model")
import collection_model as cm
r = cm.Scenario(d_b=1.304e-3, v_b=0.0348).evaluate()   # Re, Eo, We, Mo, Ec, Ecoll, Np ...
```

## Step 7 Outputs
| Output | Meaning |
|---|---|
| `DATA/PROCESSED_DATA/legacy_schema/` | the four CSVs with Savitzky-Golay columns added (input of the authors' scripts) |
| `DATA/PROCESSED_DATA/per_frame_processed.csv` | one row per frame, all derived quantities |
| `DATA/DERIVED_DATA/manuscript_statistics.json` | every recomputed statistic |
| `DATA/DERIVED_DATA/sensitivity_fps_scale.csv`, `implied_induction_times.csv` | new analyses |
| `DATA/DERIVED_DATA/legacy_regenerated/` | JSON + figures from the authors' scripts |
| `AUDIT/claim_verification.csv` | claim-by-claim PASS/FAIL |
| `FIGURES/PUBLICATION_READY/` | PNG + PDF figures; `FIGURES/SOURCE_DATA/` the plotted numbers |

## Step 8 Post-processing
`build_supplementary_workbook.py` (workbook with live formulas; recalculate with LibreOffice or Excel), `build_data_dictionary.py`, `build_audit_tables.py`.

## Step 9 Verification
Expected console results: `7 tests passed`; `109 claims checked: {'PASS': 100, 'PASS*': 1, 'FAIL': 8}`; `ALL IDENTICAL` for the regeneration. The 8 FAILs are the documented manuscript discrepancies (AUDIT/CORRECTION_LOG.md), not code errors.

## Step 10 Troubleshooting
See TROUBLESHOOTING.md.
