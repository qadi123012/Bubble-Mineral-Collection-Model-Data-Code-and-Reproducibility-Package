---
title: "Supplementary Information"
subtitle: "Single-bubble mineral collection model: data, calculations and reproducibility material"
---

# 1. Scope and provenance

This document accompanies *Final_Manuscript_Cl.docx*. It documents the data, calculations and code behind the single-bubble (system C) results and the collection model. Systems A (zeta potential, BPATE) and B (bubble size distributions, flotation kinetics) are described in the manuscript but **no data for them were supplied**; nothing about them has been re-derived here (Section 6). All values below were recomputed from the supplied files by the code in the repository; the commands are in DOCUMENTATION/MODEL_EXECUTION_GUIDE.md.

**Two inputs are unverified and control every SI-unit result:** the frame rate (manuscript: 2000 fps; author slides and scripts: 500 fps, "only assumed") and the spatial scale (manuscript: 11.2 um/px; the burned-in 3 mm bar is clipped by the image edge, 187 px visible = 16.04 um/px if unclipped). Sensitivity results are given in Table S5 and Fig. S1.

# 2. Supplementary tables

## Table S1. System C datasets

| Dataset | Rows | Origin | Role |
|---|---|---|---|
| frame_00000000-00000120.jpg | 121 | Raw, 864 x 496, 8-bit | Source images; frames 25-120 analysed |
| bubble_kinematics_and_particles.csv | 96 | Author CSV, regenerated from frames (max diff 6e-14) | Bubble size, position, shape, feature counts |
| individual_particles.csv | 5,673 | Author CSV, regenerated | Position and diameter of each detected feature |
| piv_summary.csv | 95 | Author CSV, regenerated | Far-field PIV statistics per frame pair |
| bubble_analyser_crosscheck.csv | 96 | Author CSV, regenerated with Bubble Analyser commit 63b22f3 (max diff 1.4e-14) | Independent diameter |
| IMG_9423, 9432, 9433, 9434 (RGB, 2400 x 1600) | 4 | Raw micrographs | No physical scale; not used for any reported number |


## Table S2. Image-analysis parameters (read from the code)

| Stage | Parameter | Value |
|---|---|---|
| Segmentation | Blur / threshold / morphology | Gaussian 5x5 / Otsu / close 5x5 ellipse, open 3x3 |
| Segmentation | Tail severing; contour | 13x13 ellipse erode-keep-largest-dilate; convex hull; ellipse fit |
| Segmentation | ROI margin | max(90 px, 2.2 x previous radius) |
| Feature detection | Mask erosion; high-pass sigma | 15 px; 9 px |
| Feature detection | High-pass threshold | **18 gray levels** (the manuscript states 'not recorded') |
| Feature detection | Accepted area | 2-200 px^2 (d = 1.60-15.96 px) |
| PIV | Window / overlap / search / S-N | 32 / 16 / 32 px / peak2peak > 1.25; bubble contours dilated 41 px excluded |
| Smoothing | Savitzky-Golay | window 11, order 3 (recovered; matches published statistics to 5e-14) |


## Table S3. Model inputs and verification status

| Input | Value | Unit | Status |
|---|---|---|---|
| Spatial scale | 11.2 | um/px | UNVERIFIED (clipped bar) |
| Frame rate | 2000 | fps | CONFLICTING (500 vs 2000) |
| rho_L, mu_L, sigma | 997.5; 0.932e-3; 0.072 | kg/m3; Pa s; N/m | Assumed pure water 23 C |
| d_p | 29 | um | From systems A/B; not measured in system C |
| rho_p | 3000 | kg/m3 | Magnesite |
| Ea | 0.78 | - | System A BPATE; raw data missing |
| Es | 0.85 (0.80-0.95) | - | Assumed scenario |
| Solids concentration | 10 | kg/m3 | System B slurry, not system C |


## Table S4. Model chain at the manuscript's scenario (2000 fps, 11.2 um/px)

| Quantity | Recomputed | Manuscript |
|---|---|---|
| d_b (mm) | 1.304 | 1.304 |
| V_b (mm/s) | 34.8 | 34.8 |
| Re | 48.6 | 48.6 |
| Eo | 0.231 | 0.231 |
| We | 0.0219 | 0.0219 |
| Mo | 1.99e-11 | 2.0e-11 |
| Ec | 2.91e-03 | 2.9e-3 |
| Ecoll | 1.93e-03 | 1.92e-3 |
| Np max | 599.7 | 599.6 |
| Np (model) | 1.158 | 1.15 |
| Mean detected features / Np | 51.0 | about 51 |
| Implied Cd / rigid-sphere Cd | 14.1 / 1.56 | 14 / 1.6 |


## Table S5. Sensitivity to the unverified frame rate and scale (new analysis)

| um/px | fps | d_b (mm) | V_b (mm/s) | Re | Ec (x1e-3) | Np model | Features / Np | V_b / V_rigid |
|---|---|---|---|---|---|---|---|---|
| 11.20 | 500 | 1.304 | 8.7 | 12.1 | 1.54 | 0.61 | 96.5 | 0.060 |
| 11.20 | 1000 | 1.304 | 17.4 | 24.3 | 2.06 | 0.82 | 72.2 | 0.119 |
| 11.20 | 2000 | 1.304 | 34.8 | 48.6 | 2.91 | 1.16 | 51.0 | 0.238 |
| 16.04 | 500 | 1.868 | 12.5 | 24.9 | 1.02 | 1.17 | 50.5 | 0.062 |
| 16.04 | 1000 | 1.868 | 24.9 | 49.8 | 1.44 | 1.66 | 35.6 | 0.125 |
| 16.04 | 2000 | 1.868 | 49.8 | 99.6 | 2.14 | 2.47 | 24.0 | 0.250 |


The qualitative conclusion that the feature count greatly exceeds the model estimate holds in all six scenarios (24 to 97 times). The quantitative factor (51) and the rise-velocity anomaly (V_b about 4 to 17 times below the rigid-sphere velocity) depend on the two unverified inputs.

## Table S6. Manuscript claims that do not reproduce (8 of 109; 100 pass, 1 definition-dependent)

| ID | Location | Quantity | Printed | Recomputed | Note |
|---|---|---|---|---|---|
| C07 | S4.7/S3.2 | raw pipeline diameter SD (as printed) | 2.42 | 2.00419 | Printed 2.42; data give 2.00 (SD n) / 2.01 (SD n-1). |
| C08 | S4.7/S3.2 | Bubble Analyser diameter SD (as printed) | 2.1 | 1.74997 | Printed 2.1; data give 1.75. |
| C27 | S4.3 | net vertical rise in mm | 1.646 | 1.64547 | 1.6455 mm exactly: rounds to 1.645 or 1.646 depending on input rounding. |
| C36 | S4.2 | aspect ratio SD (as printed) | 0.056 | 0.0592469 | Printed 0.056; data give 0.0592 (n) / 0.0596 (n-1). |
| C43 | S4.2 | number of aspect-ratio peaks | 3 | 4 | Not reproducible: legacy script gives 5, SG-smoothed gives 4. |
| C45 | S4.2/S4.7 | mean spacing of successive extremes | 11.5 | 8.625 | Not reproducible (SG-smoothed gives 8.6; FFT dominant period 48 frames). |
| C85 | S4.9 | share of mass in top 25% of features (as printed) | 75 | 90.8622 | Printed ~75%; data give 90.9%. |
| C90 | S4.9 | estimated unique mass U(f) at frame 120 | 171 | 174.145 | Data give 174.1 ug. |


Full list: AUDIT/claim_verification.csv and Supplementary_Tables.xlsx (ST4). Proposed corrections: AUDIT/CORRECTION_LOG.md.

## Table S7. Induction times implied by Eq. (4) (new analysis)

| Ea | t_c (ms) | Implied t_i (ms) |
|---|---|---|
| 0.22 | 100 | 139.0 |
| 0.78 | 100 | 50.9 |
| 0.95 | 100 | 22.7 |


At saturation (Ea = 0.95) the implied t_i of 22.7 ms exceeds t_i0 = 8.2 ms, so the fitted surrogate requires a non-zero barrier term even above the hemimicelle concentration.

# 3. Supplementary figures

![Fig. S1. Sensitivity of Re, Ec and the feature-to-model ratio to the assumed frame rate and scale.](../FIGURES/PUBLICATION_READY/Fig_S1_sensitivity_fps_scale.png){width=100%}

![Fig. S2. Robustness of the headline kinematic statistics to the Savitzky-Golay window and order.](../FIGURES/PUBLICATION_READY/Fig_S2_savgol_robustness.png){width=100%}

![Fig. S3. The burned-in 3 mm scale bar is cut by the image edge (frame 73).](../FIGURES/PUBLICATION_READY/Fig_S3_scale_bar_evidence.png){width=100%}

Functional reproductions of manuscript Figs. 3 to 11 are in FIGURES/PUBLICATION_READY/ (regenerated_from_authors_scripts and reproduced_from_data). Figs. 8 to 11 were rebuilt because the authors' plotting script for them was not supplied.

# 4. Supplementary equations, derivations and variables

**Eq. (4) inverted.** From Ea = sin^2[2 arctan(exp(-t_i/t_c))]: theta = arcsin(sqrt(Ea)), t_i = -t_c ln tan(theta/2). Used for Table S7.

**Eq. (10) and (11).** K = (3/2) Ecoll Jg/d_b = (1/4) Ecoll S_b with S_b = 6 Jg/d_b. For one size class Eq. (11) reduces to Eq. (10) (unit-tested).

**Feature mass.** m = (pi/6) d^3 rho_p, d = d_px x scale. Mass scales with scale cubed (x2.94 for 16.04 vs 11.2 um/px).

**Uncertainty propagation.** A relative scale uncertainty u gives 2u on Re and Eo (both scale squared at fixed fps) and 3u on We; arithmetic only.

**Implied drag coefficient.** Cd = (4/3)(rho_L - rho_g) g d / (rho_L V^2) = 14.1; Schiller-Naumann rigid sphere: V = 0.146 m/s, Cd = 1.56 at the measured Re.

**Lamb frequency (n = 2, bubble in liquid).** f2 = (1/2pi) sqrt(12 sigma/(rho_L R^3)) = 281 Hz for R = d_b/2 = 0.652 mm. A Hann-windowed periodogram of the detrended aspect ratio gives a dominant period of 48 frames (two cycles in 96 frames; low confidence).

| Symbol | Meaning | SI unit |
|---|---|---|
| d_b, d_p | bubble, particle diameter | m |
| V_b | bubble rise velocity | m/s |
| Re, Eo, We, Mo | Reynolds, Eotvos, Weber, Morton numbers | - |
| Ec, Ea, Es, Ecoll | collision, attachment, stability, total efficiency | - |
| t_i, t_c | induction, contact time | s |
| C_p | particle number concentration | m^-3 |
| h_c | collection-zone height (observed net rise) | m |
| N_p | particles collected per bubble | - |
| K, K_total | flotation rate constant | s^-1 |
| J_g, S_b | superficial gas velocity; bubble surface area flux | m/s; s^-1 |
| rho, mu, sigma | density, viscosity, surface tension | kg/m3; Pa s; N/m |


# 5. Limits of verification

The collection model is **verified** (implementation reproduces the printed numbers) but **not validated** (no measured K, recovery, collection efficiency or particle count independent of the image proxy exists). Ea comes from a calibration whose raw records are not available. See DOCUMENTATION/VALIDATION_GUIDE.md.

# 6. Not available

The missing-information list is in AUDIT/MISSING_INFORMATION.md (M-01 to M-12): frame-rate and scale primary records, original video, systems A and B raw data, suspension composition, IMG_9431, the Fig. 8-11 plotting script, controls and a free-rise measurement.
