# Reproducibility checklist (status at packaging)

- [x] Raw frames included (121 JPG) and original video referenced as missing (M-03)
- [x] Processed CSVs reproduced from raw frames with the unmodified author code (<= 6e-14)
- [x] All reported system C statistics recomputed (216) and compared with the manuscript (109 claims)
- [x] Smoothing parameters recovered and documented
- [x] Executable model with unit tests (7 pass)
- [x] Single configuration file for every scenario input, with verification status
- [x] Environment pinned (ENVIRONMENT/) and tested from a clean virtual environment (AUDIT/TEST_LOG.md)
- [x] One-command workflow (`run_all.sh`)
- [x] Sensitivity to the two unverified inputs quantified
- [ ] Frame rate verified from a primary record (M-01)
- [ ] Spatial scale verified from a primary record (M-02)
- [ ] Systems A and B raw data deposited (M-04, M-05)
- [ ] Detection-threshold / erosion sensitivity sweep (M-10)
- [ ] Controls (particle-free, tracer-only, free-rise) (M-12)
- [ ] Licence and citation metadata (M-11)
- [ ] Manuscript corrections CL-03 to CL-20 applied by the authors
